# app.py
from flask import Flask, render_template, request, abort, url_for
from sqlalchemy import func, extract, or_
from datetime import datetime, timedelta

# ===== 멘토링 보고서 업로드용 =====
import os
from werkzeug.utils import secure_filename

# ★ 여기! 상대 임포트 금지
from lms_app.models import (
    db, User, Course, Enrollment, Assignment, Submission,
    assignment_progress_for_user, average_score_for_user,
    recent_activities_for_user, upcoming_items_for_user
)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root1234@localhost:3306/lms_db?charset=utf8mb4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

DEMO_USER_ID = 1

# ===== 업로드 폴더/설정 (멘토링 보고서 업로드용) =====
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))  # lms-main
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_DIR
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024  # 32MB
ALLOWED_EXT = {'pdf', 'ppt', 'pptx', 'doc', 'docx', 'xlsx', 'csv', 'txt', 'md', 'zip', 'png', 'jpg', 'jpeg'}

def _allowed(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


# --------- 공용 헬퍼 ---------
@app.context_processor
def inject_helpers():
    def active_exact(endpoint_or_path='/'):
        p = request.path
        if endpoint_or_path.startswith('/'):
            return p == endpoint_or_path
        try:
            return p == url_for(endpoint_or_path)
        except Exception:
            return False
    def active_prefix(path_prefix):
        return request.path.startswith(path_prefix)
    return dict(active_exact=active_exact, active_prefix=active_prefix)


# ---------------------------------------
# 1) 대시보드
# ---------------------------------------
@app.route('/')
def dashboard():
    user = db.session.get(User, DEMO_USER_ID)
    if not user:
        return "초기 데이터가 없습니다. MariaDB에서 init_db.sql을 먼저 실행하세요.", 500

    course_count = db.session.query(Enrollment).filter_by(user_id=DEMO_USER_ID).count()
    progress_pct, submitted_cnt, total_cnt = assignment_progress_for_user(DEMO_USER_ID)
    avg_score = average_score_for_user(DEMO_USER_ID)

    bars = []
    courses = (
        db.session.query(Course)
        .join(Enrollment, Enrollment.course_id == Course.id)
        .filter(Enrollment.user_id == DEMO_USER_ID)
        .all()
    )
    for c in courses:
        total_c = db.session.query(Assignment).filter_by(course_id=c.id).count()
        submitted_c = (
            db.session.query(Submission)
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .filter(
                Submission.user_id == DEMO_USER_ID,
                Assignment.course_id == c.id,
                Submission.submitted_at.isnot(None),
            )
            .count()
        )
        pct = int((submitted_c / total_c) * 100) if total_c else 0
        bars.append({'course': c, 'pct': pct})

    upcoming = upcoming_items_for_user(DEMO_USER_ID, within_days=21)
    recent = recent_activities_for_user(DEMO_USER_ID, limit=5)

    return render_template(
        'dashboard.html',
        user=user,
        course_count=course_count,
        progress_pct=progress_pct,
        submitted_cnt=submitted_cnt,
        total_cnt=total_cnt,
        avg_score=avg_score,
        bars=bars,
        upcoming=upcoming,
        recent=recent,
    )


# ---------------------------------------
# 2) 강좌 목록
# ---------------------------------------
@app.route('/courses')
def courses():
    rows = (
        db.session.query(Course)
        .join(Enrollment, Enrollment.course_id == Course.id)
        .filter(Enrollment.user_id == DEMO_USER_ID)
        .all()
    )
    cards = []
    for c in rows:
        total = db.session.query(Assignment).filter_by(course_id=c.id).count()
        submitted = (
            db.session.query(Submission)
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .filter(
                Submission.user_id == DEMO_USER_ID,
                Assignment.course_id == c.id,
                Submission.submitted_at.isnot(None),
            ).count()
        )
        pct = int((submitted / total) * 100) if total else 0
        cards.append({'course': c, 'total': total, 'submitted': submitted, 'progress': pct})
    return render_template('courses.html', courses=cards)


# ---------------------------------------
# 3) 강좌 상세
# ---------------------------------------
@app.route('/course/<int:course_id>')
def course_detail(course_id):
    tab = request.args.get('tab', 'materials')
    course = db.session.get(Course, course_id)
    if not course:
        abort(404, description="강좌를 찾을 수 없습니다.")

    total = db.session.query(Assignment).filter_by(course_id=course.id).count()
    submitted = (
        db.session.query(Submission)
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .filter(
            Submission.user_id == DEMO_USER_ID,
            Assignment.course_id == course.id,
            Submission.submitted_at.isnot(None),
        ).count()
    )
    progress_pct = int((submitted / total) * 100) if total else 0

    assignments = (
        db.session.query(Assignment)
        .filter_by(course_id=course.id)
        .order_by(func.isnull(Assignment.due_at), Assignment.due_at.asc())
        .all()
    )

    sub_map = {
        s.assignment_id: s
        for s in (
            db.session.query(Submission)
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .filter(Submission.user_id == DEMO_USER_ID, Assignment.course_id == course.id)
            .all()
        )
    }

    materials = [
        {"week": 1, "title": "1주차: HTML 기초", "duration": "45분", "status": "완료"},
        {"week": 2, "title": "2주차: CSS 스타일링", "duration": "50분", "status": "완료"},
        {"week": 3, "title": "3주차: JavaScript 기초", "duration": "60분", "status": "진행중"},
        {"week": None, "title": "실습 자료 - HTML 템플릿", "size": "2.5MB", "download": True},
    ]
    notices = [
        {"title": "중간고사 안내", "date": "2025-03-05", "pin": True},
        {"title": "실습 자료 업데이트", "date": "2025-02-28", "pin": False},
    ]
    discussion = [
        {"title": "1주차 과제 질문 스레드", "comments": 12, "updated": "2시간 전"},
        {"title": "프로젝트 팀 편성", "comments": 8, "updated": "1일 전"},
    ]

    return render_template(
        'course_detail.html',
        course=course,
        tab=tab,
        progress_pct=progress_pct,
        assignments=assignments,
        sub_map=sub_map,
        materials=materials,
        notices=notices,
        discussion=discussion,
    )


# ---------------------------------------
# 4) 분석 및 리포트 (실데이터 집계)
# ---------------------------------------
@app.route('/analytics')
def analytics_page():
    # ---------- KPI ----------
    student_count = db.session.scalar(db.select(func.count(User.id))) or 0
    active_courses = db.session.scalar(
        db.select(func.count(func.distinct(Enrollment.course_id)))
    ) or 0

    # 강좌별 과제 수 / 수강생 수
    course_assign_cnt = {
        cid: cnt for cid, cnt in
        db.session.execute(
            db.select(Assignment.course_id, func.count(Assignment.id)).group_by(Assignment.course_id)
        ).all()
    }
    enrolled_by_course = {
        cid: cnt for cid, cnt in
        db.session.execute(
            db.select(Enrollment.course_id, func.count(Enrollment.user_id)).group_by(Enrollment.course_id)
        ).all()
    }

    # 전체 기대 제출 수 및 전체 제출 수
    expected_submissions = sum(
        (course_assign_cnt.get(cid, 0) * enrolled_by_course.get(cid, 0))
        for cid in set([*course_assign_cnt.keys(), *enrolled_by_course.keys()])
    )
    submitted_total = db.session.scalar(
        db.select(func.count(Submission.id)).where(Submission.submitted_at.isnot(None))
    ) or 0
    avg_progress_global = int(round(100 * submitted_total / expected_submissions)) if expected_submissions else 0

    # 완료율(전체) — 수강쌍 중 모든 과제를 제출 완료한 비율
    courses_with_hw = [cid for cid, n in course_assign_cnt.items() if n > 0]
    finished_pairs = 0
    total_pairs = 0
    if courses_with_hw:
        rows = db.session.execute(
            db.select(Submission.user_id, Assignment.course_id, func.count(Submission.id))
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .where(Submission.submitted_at.isnot(None), Assignment.course_id.in_(courses_with_hw))
            .group_by(Submission.user_id, Assignment.course_id)
        ).all()
        submap = {(u, c): n for (u, c, n) in rows}
        enrolls = db.session.execute(
            db.select(Enrollment.user_id, Enrollment.course_id).where(Enrollment.course_id.in_(courses_with_hw))
        ).all()
        total_pairs = len(enrolls)
        for u, c in enrolls:
            need = course_assign_cnt.get(c, 0)
            if need and submap.get((u, c), 0) >= need:
                finished_pairs += 1
    completion_rate = int(round(100 * finished_pairs / total_pairs)) if total_pairs else 0

    # ---------- 차트용 데이터 ----------
    # 강좌별 성과 (수강생 수 vs 완료 학생 수)
    course_perf = []
    course_rows = db.session.execute(db.select(Course.id, Course.title)).all()

    # (user,course)별 제출수
    subrows = db.session.execute(
        db.select(Submission.user_id, Assignment.course_id, func.count(Submission.id))
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .where(Submission.submitted_at.isnot(None))
        .group_by(Submission.user_id, Assignment.course_id)
    ).all()
    submap_all = {}
    for u, c, n in subrows:
        submap_all.setdefault(c, {})[u] = n

    for cid, title in course_rows:
        enrolled_cnt = enrolled_by_course.get(cid, 0)
        need = course_assign_cnt.get(cid, 0)
        completed_cnt = 0
        if need and enrolled_cnt:
            user_ids = [u for (u,) in db.session.execute(
                db.select(Enrollment.user_id).where(Enrollment.course_id == cid)
            ).all()]
            for u in user_ids:
                if submap_all.get(cid, {}).get(u, 0) >= need:
                    completed_cnt += 1
        course_perf.append({"title": title, "enrolled": enrolled_cnt, "completed": completed_cnt})

    # 최근 5개월 트렌드
    end = datetime.utcnow().replace(day=1)
    start = (end - timedelta(days=31*4)).replace(day=1)
    monthly = {
        (int(y), int(m)): cnt
        for (y, m, cnt) in db.session.execute(
            db.select(extract('year', Submission.submitted_at),
                      extract('month', Submission.submitted_at),
                      func.count(Submission.id))
            .where(Submission.submitted_at.isnot(None),
                   Submission.submitted_at >= start,
                   Submission.submitted_at < end + timedelta(days=40))
            .group_by(extract('year', Submission.submitted_at),
                      extract('month', Submission.submitted_at))
        ).all()
    }
    trend = []
    cur = start
    for _ in range(5):
        key = (cur.year, cur.month)
        sub_cnt = int(monthly.get(key, 0))
        month_label = f"{cur.month}월"
        avg_pct = int(round(100 * sub_cnt / expected_submissions)) if expected_submissions else 0
        trend.append({"month": month_label, "avg_progress": avg_pct, "submissions": sub_cnt})
        cur = cur.replace(year=cur.year + 1, month=1) if cur.month == 12 else cur.replace(month=cur.month + 1)

    metrics = {
        "student_count": student_count,
        "student_growth": "+0%",
        "active_courses": active_courses,
        "new_courses": "+0%",
        "avg_progress": trend[-1]["avg_progress"] if trend else avg_progress_global,
        "progress_growth": "+0%",
        "completion_rate": completion_rate,
        "completion_growth": "+0%",
    }

    # ---------- 새 섹션 1: 강좌별 상세 분석 ----------
    # 과목별 평균 점수
    avg_score_by_course = {
        cid: (float(avg) if avg is not None else None)
        for cid, avg in db.session.execute(
            db.select(Assignment.course_id, func.avg(Submission.score))
            .join(Submission, Submission.assignment_id == Assignment.id)
            .where(Submission.score.isnot(None))
            .group_by(Assignment.course_id)
        ).all()
    }

    course_details = []
    for cid, title in course_rows:
        students = enrolled_by_course.get(cid, 0)
        avg_sc = avg_score_by_course.get(cid, None)

        need = course_assign_cnt.get(cid, 0)
        completed_cnt = 0
        if need and students:
            user_ids = [u for (u,) in db.session.execute(
                db.select(Enrollment.user_id).where(Enrollment.course_id == cid)
            ).all()]
            for u in user_ids:
                if submap_all.get(cid, {}).get(u, 0) >= need:
                    completed_cnt += 1
        completion = int(round(100 * completed_cnt / students)) if students else 0

        course_details.append({
            "title": title,
            "students": students,
            "avg_score": (round(avg_sc, 0) if avg_sc is not None else None),
            "completion": completion,
        })

    # ---------- 새 섹션 2: 위험군 학생 조기 경고 ----------
    expected_by_user = {
        uid: cnt for uid, cnt in db.session.execute(
            db.select(Enrollment.user_id, func.count(Assignment.id))
            .join(Assignment, Assignment.course_id == Enrollment.course_id)
            .group_by(Enrollment.user_id)
        ).all()
    }
    submitted_by_user = {
        uid: cnt for uid, cnt in db.session.execute(
            db.select(Submission.user_id, func.count(Submission.id))
            .where(Submission.submitted_at.isnot(None))
            .group_by(Submission.user_id)
        ).all()
    }
    avg_by_user = {
        uid: float(avg) for uid, avg in db.session.execute(
            db.select(Submission.user_id, func.avg(Submission.score))
            .where(Submission.score.isnot(None))
            .group_by(Submission.user_id)
        ).all()
    }

    try:
        student_rows = db.session.execute(
            db.select(User.id, User.name, User.email).where(User.role == 'student')
        ).all()
    except Exception:
        student_rows = db.session.execute(
            db.select(User.id, User.name, User.email)
            .join(Enrollment, Enrollment.user_id == User.id)
            .group_by(User.id, User.name, User.email)
        ).all()

    risk_students = []
    for uid, name, email in student_rows:
        expected = expected_by_user.get(uid, 0)
        submitted = submitted_by_user.get(uid, 0)
        progress = int(round(100 * submitted / expected)) if expected else 0
        sub_rate = progress
        avg_sc = avg_by_user.get(uid, None)

        badges = []
        if progress < 40:
            badges.append("낮은 진도율")
        if expected and (submitted / expected) < 0.5:
            badges.append("낮은 과제 제출률")
        if avg_sc is not None and avg_sc < 60:
            badges.append("낮은 평균 점수")

        if badges:
            risk_students.append({
                "name": name,
                "email": email,
                "progress": progress,
                "submission_rate": sub_rate,
                "avg_score": int(round(avg_sc)) if avg_sc is not None else None,
                "badges": badges
            })

    def _risk_key(s):
        avg = s["avg_score"] if s["avg_score"] is not None else 999
        return (s["progress"], avg)
    risk_students.sort(key=_risk_key)
    risk_students = risk_students[:3]

    return render_template(
        "analytics.html",
        metrics=metrics,
        course_perf=course_perf,
        trend=trend,
        course_details=course_details,
        risk_students=risk_students
    )


# ---------------------------------------
# 4.5) 멘토링 및 프로젝트 관리 (탭 기반)
# ---------------------------------------
@app.route('/mentoring', methods=['GET', 'POST'])
def mentoring_page():
    """
    탭: activities | reports | team | solo | projects | tasks | competitions | github
    """
    tab = request.args.get('tab', 'activities')
    msg = None
    err = None

    # 데모 데이터
    mentoring_sessions = [
        {"title": "1회차 멘토링(오리엔테이션)", "mentor": "김멘토", "date": "2025-03-10", "status": "완료"},
        {"title": "2회차 포트폴리오 리뷰", "mentor": "박멘토", "date": "2025-03-17", "status": "예정"},
        {"title": "3회차 모의면접", "mentor": "이멘토", "date": "2025-03-24", "status": "예정"},
    ]
    team_members = [
        {"name": "홍길동", "role": "student", "email": "hong@example.com"},
        {"name": "김교수", "role": "instructor", "email": "profkim@example.com"},
    ]
    projects = [
        {"name": "AI 캡스톤", "owner": "홍길동 외 3", "progress": 65},
        {"name": "웹 서비스 리디자인", "owner": "김교수", "progress": 30},
    ]
    tasks = [
        {"title": "프로젝트 기획서 제출", "due": "2025-03-15", "assignee": "팀 전체", "status": "진행중"},
        {"title": "중간발표 준비", "due": "2025-04-05", "assignee": "홍길동", "status": "대기"},
    ]
    competitions = [
        {"title": "K-데이터 공모전", "deadline": "2025-04-30", "status": "모집중"},
        {"title": "오픈소스 해커톤", "deadline": "2025-05-12", "status": "예정"},
    ]

    # 업로드된 보고서 리스트
    report_files = []
    for fn in sorted(os.listdir(app.config['UPLOAD_FOLDER'])):
        fpath = os.path.join(app.config['UPLOAD_FOLDER'], fn)
        if os.path.isfile(fpath):
            report_files.append({"name": fn, "size": os.path.getsize(fpath)})

    # POST 처리
    if request.method == 'POST':
        if tab == 'reports':
            f = request.files.get('file')
            if not f or f.filename.strip() == '':
                err = "업로드할 파일을 선택해 주세요."
            elif not _allowed(f.filename):
                err = f"허용되지 않는 확장자입니다. ({', '.join(sorted(ALLOWED_EXT))})"
            else:
                safe = secure_filename(f.filename)
                save_to = os.path.join(app.config['UPLOAD_FOLDER'], safe)
                f.save(save_to)
                msg = f"업로드 완료: {safe}"
                # 리스트 갱신
                report_files = []
                for fn in sorted(os.listdir(app.config['UPLOAD_FOLDER'])):
                    fpath = os.path.join(app.config['UPLOAD_FOLDER'], fn)
                    if os.path.isfile(fpath):
                        report_files.append({"name": fn, "size": os.path.getsize(fpath)})

        elif tab == 'github':
            repo_url = (request.form.get('repo_url') or '').strip()
            if not repo_url.startswith('http'):
                err = "유효한 GitHub 저장소 URL을 입력해 주세요. (예: https://github.com/org/repo)"
            else:
                msg = f"GitHub 저장소가 등록되었습니다: {repo_url}"

    return render_template(
        'mentoring.html',
        tab=tab,
        msg=msg,
        err=err,
        mentoring_sessions=mentoring_sessions,
        team_members=team_members,
        projects=projects,
        tasks=tasks,
        competitions=competitions,
        report_files=report_files,
    )


# ---------------------------------------
# 5) 기타 메뉴(임시)
# ---------------------------------------
@app.route('/users')
def users_page():
    # 검색/필터 파라미터
    q = (request.args.get('q') or '').strip()
    role = request.args.get('role', 'all')  # all | student | instructor | admin

    # 기본 쿼리
    query = db.session.query(User)

    # 역할 필터
    if role in ('student', 'instructor', 'admin'):
        query = query.filter(User.role == role)

    # 검색 (이름/핸들/이메일/전화)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(User.name.like(like),
                                 User.username.like(like),
                                 User.email.like(like),
                                 User.phone.like(like)))

    # 정렬: 최근 가입순
    users = query.order_by(User.created_at.desc()).all()

    # 상단 KPI
    total_cnt = db.session.scalar(db.select(func.count(User.id))) or 0
    student_cnt = db.session.scalar(db.select(func.count(User.id)).where(User.role == 'student')) or 0
    instructor_cnt = db.session.scalar(db.select(func.count(User.id)).where(User.role == 'instructor')) or 0
    admin_cnt = db.session.scalar(db.select(func.count(User.id)).where(User.role == 'admin')) or 0

    return render_template(
        'users.html',
        users=users,
        total_cnt=total_cnt,
        student_cnt=student_cnt,
        instructor_cnt=instructor_cnt,
        admin_cnt=admin_cnt,
        q=q,
        role=role,
    )


@app.route('/messages')
def messages_page():
    return render_template('placeholder.html', title='메시지', desc='강의/과제 관련 메시지함 (준비 중)')


@app.route('/schedule')
def schedule_page():
    return render_template('placeholder.html', title='일정', desc='강의/마감/캘린더 (준비 중)')


@app.route('/assignments_page')
def assignments_page():
    return render_template('placeholder.html', title='과제', desc='과제 목록/제출 관리 (준비 중)')


@app.route('/grades')
def grades_page():
    return render_template('placeholder.html', title='성적', desc='성적/평가 현황 (준비 중)')


@app.route('/profile')
def profile_page():
    return render_template('placeholder.html', title='프로필', desc='내 프로필/설정 (준비 중)')


@app.route('/settings')
def settings_page():
    return render_template('placeholder.html', title='설정', desc='환경설정 (준비 중)')


if __name__ == '__main__':
    with app.app_context():
        app.run(debug=True, port=5004, use_reloader=False)
