# helpers/roles.py
from __future__ import annotations
from typing import Optional, TYPE_CHECKING
from flask import g, abort
from extensions import db

if TYPE_CHECKING:
    from models import Course, User

# 현재 로그인 사용자
def _current_user() -> Optional["User"]:
    return getattr(g, "user", None)

# 교수/관리자 판별
def is_prof_like(user: Optional["User"] = None) -> bool:
    u = user or _current_user()
    return getattr(u, "role", "") in ("professor", "instructor", "admin")

# 강좌 소유자 후보 필드(스키마 차이 흡수)  ⬅️ professor_id 제거됨
_OWNER_CANDIDATES = (
    "instructor_user_id",
    "owner_user_id",
    "teacher_id",
    "created_by",
)

def get_course_owner_id(course: "Course") -> Optional[int]:
    for name in _OWNER_CANDIDATES:
        if hasattr(course, name):
            return getattr(course, name)
    return None

def is_course_owner_or_admin(course: "Course", user: Optional["User"] = None) -> bool:
    u = user or _current_user()
    if not u:
        return False
    if getattr(u, "role", "") == "admin":
        return True
    return get_course_owner_id(course) == getattr(u, "id", None)

def ensure_course_owner_or_403(course_id: int) -> "Course":
    from models import Course
    course = db.session.get(Course, course_id)
    if not course:
        abort(404)
    user = _current_user()
    if not user or not is_course_owner_or_admin(course, user):
        abort(403)
    return course

def ensure_enrolled_or_403(course_id: int, user_id: Optional[int] = None) -> None:
    from models import Enrollment
    uid = user_id or getattr(_current_user(), "id", None)
    if not uid:
        abort(403)
    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=course_id).first()
    if not ok:
        abort(403)
