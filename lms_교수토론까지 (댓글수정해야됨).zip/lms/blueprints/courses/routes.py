# blueprints/courses/routes.py
from flask import Blueprint, render_template, request, g
from sqlalchemy import func, or_
from helpers.auth import login_required
from models import db, Course, Enrollment, Assignment, Submission

bp = Blueprint("courses", __name__, url_prefix="/courses")

@bp.get("/", endpoint="home")
@login_required
def index():
    uid = g.user.id
    role = (getattr(g.user, "role", "") or "student").lower()
    is_prof_like = role in ("professor", "instructor", "admin")

    q_raw = (request.args.get("q") or "").strip()
    q = q_raw.lower()

    if is_prof_like:
        # 기본: 전체(관리자) 또는 담당 강좌(교수/강사)
        base_q = db.session.query(Course.id, Course.title)

        if role != "admin":
            # 스키마에 따라 존재할 수 있는 소유자 컬럼만 사용 (professor_id 제거)
            owner_fields = ("instructor_user_id", "owner_user_id", "teacher_id", "created_by")
            filters = []
            for f in owner_fields:
                col = getattr(Course, f, None)
                if col is not None:
                    filters.append(col == uid)

            if filters:
                base_q = base_q.filter(or_(*filters))
            else:
                # 소유자 컬럼이 없으면 Enrollment의 역할 기반으로 대체
                j = base_q.join(Enrollment, Enrollment.course_id == Course.id)
                if hasattr(Enrollment, "role"):
                    base_q = j.filter(
                        Enrollment.user_id == uid,
                        Enrollment.role.in_(["instructor", "teacher", "ta"])
                    )
                else:
                    base_q = j.filter(Enrollment.user_id == uid)

        if q:
            base_q = base_q.filter(func.lower(Course.title).like(f"%{q}%"))

        rows = base_q.all()
        if not rows:
            return render_template("pro/courses.html", courses=[], q=q_raw)

        course_ids = [cid for cid, _ in rows]

        total_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Assignment.course_id, func.count(Assignment.id))
                .where(Assignment.course_id.in_(course_ids))
                .group_by(Assignment.course_id)
            ).all()
        }

        submitted_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Assignment.course_id, func.count(Submission.id))
                .join(Assignment, Assignment.id == Submission.assignment_id)
                .where(
                    Assignment.course_id.in_(course_ids),
                    Submission.submitted_at.isnot(None),
                )
                .group_by(Assignment.course_id)
            ).all()
        }

        roster_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Enrollment.course_id, func.count(Enrollment.user_id))
                .where(Enrollment.course_id.in_(course_ids))
                .group_by(Enrollment.course_id)
            ).all()
        }

        cards = []
        for cid, title in rows:
            cards.append({
                "course": {"id": cid, "title": title},
                "assignments": int(total_by_course.get(cid, 0)),
                "submitted_all": int(submitted_by_course.get(cid, 0)),
                "enrolled": int(roster_by_course.get(cid, 0)),
            })
        return render_template("pro/courses.html", courses=cards, q=q_raw)

    # ===== 학생 뷰 =====
    base_q = (
        db.session.query(Course.id, Course.title)
        .join(Enrollment, Enrollment.course_id == Course.id)
        .filter(Enrollment.user_id == uid)
    )
    if q:
        base_q = base_q.filter(func.lower(Course.title).like(f"%{q}%"))
    rows = base_q.all()

    if not rows:
        return render_template("courses.html", courses=[], q=q_raw)

    course_ids = [cid for cid, _ in rows]

    total_by_course = {
        cid: cnt
        for cid, cnt in db.session.execute(
            db.select(Assignment.course_id, func.count(Assignment.id))
            .where(Assignment.course_id.in_(course_ids))
            .group_by(Assignment.course_id)
        ).all()
    }
    submitted_by_course = {
        cid: cnt
        for cid, cnt in db.session.execute(
            db.select(Assignment.course_id, func.count(Submission.id))
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .where(
                Assignment.course_id.in_(course_ids),
                Submission.user_id == uid,
                Submission.submitted_at.isnot(None),
            )
            .group_by(Assignment.course_id)
        ).all()
    }

    cards = []
    for cid, title in rows:
        total = int(total_by_course.get(cid, 0))
        submitted = int(submitted_by_course.get(cid, 0))
        pct = int((submitted / total) * 100) if total else 0
        cards.append({
            "course": {"id": cid, "title": title},
            "total": total,
            "submitted": submitted,
            "progress": pct,
        })
    return render_template("courses.html", courses=cards, q=q_raw)
