# blueprints/auth/routes.py — 로그인/로그아웃/데모계정 (역할별 기본 진입 포함 최종)
from __future__ import annotations
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from sqlalchemy import func
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db
from models import User
from helpers.auth import _login, _logout

bp = Blueprint("auth", __name__)

# ─────────────────────────────────────────────────────────────────────────────
# 내부 유틸: 역할별 기본 홈, 안전한 next 계산
# ─────────────────────────────────────────────────────────────────────────────
def _role_home(user: User) -> str:
    """사용자 역할에 따른 기본 진입 경로."""
    if getattr(user, "role", None) == "instructor":
        return url_for("courses.home")
    # 필요시 관리자/기타 역할도 분기 가능
    return url_for("dashboard.home")

def _safe_next(nxt: str | None, fallback: str) -> str:
    """
    내부 경로만 허용. 스킴/도메인 없는 절대경로('/')로 시작, 단 '//' (프로토콜 상대) 금지.
    """
    if not nxt:
        return fallback
    if nxt.startswith("//"):
        return fallback
    if not nxt.startswith("/"):
        return fallback
    return nxt

# ─────────────────────────────────────────────────────────────────────────────
# 로그인 페이지
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/login", endpoint="home")  # ✅ 엔드포인트: auth.home
def login():
    uid = session.get("uid")
    if uid:
        # 이미 로그인 상태면 역할별 홈으로 보냄
        user = db.session.get(User, uid)
        if user:
            return redirect(_role_home(user))
        # 세션에 uid는 있는데 사용자가 없으면 세션 정리 고려 (여기선 단순히 로그인 화면)
    return render_template("auth_login.html")

# ─────────────────────────────────────────────────────────────────────────────
# 로그인 처리
# ─────────────────────────────────────────────────────────────────────────────
@bp.post("/login", endpoint="login_post")  # ✅ 엔드포인트 명시
def login_post():
    email = (request.form.get("email") or "").strip().lower()
    password = (request.form.get("password") or "").strip()

    user = db.session.query(User).filter(func.lower(User.email) == email).first()
    if not user:
        flash("이메일 또는 비밀번호가 올바르지 않습니다.", "error")
        return redirect(url_for("auth.home"))

    ok = False
    if hasattr(user, "password_hash") and user.password_hash:
        ok = check_password_hash(user.password_hash, password)
    elif hasattr(user, "password"):
        ok = (user.password == password)

    if not ok:
        flash("이메일 또는 비밀번호가 올바르지 않습니다.", "error")
        return redirect(url_for("auth.home"))

    _login(user.id)

    # 역할별 기본 진입 경로 (교수 → 강좌 홈)
    default_after_login = _role_home(user)

    # 간단한 오픈 리다이렉트 방지: 내부 경로만 허용
    nxt = _safe_next(request.args.get("next"), fallback=default_after_login)
    return redirect(nxt)

# ─────────────────────────────────────────────────────────────────────────────
# 로그아웃: GET/POST 분리
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/logout", endpoint="logout_get")
def logout_get():
    _logout()
    flash("로그아웃되었습니다.", "success")
    return redirect(url_for("auth.home"))

@bp.post("/logout", endpoint="logout_post")
def logout_post():
    _logout()
    flash("로그아웃되었습니다.", "success")
    return redirect(url_for("auth.home"))

# ─────────────────────────────────────────────────────────────────────────────
# 데모 계정 초기화
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/init_demo", endpoint="init_demo")
def init_demo():
    """관리자/교수/학생 3계정 자동 생성 (이미 있으면 건너뜀)"""
    created = []
    demo_users = [
        ("관리자", "admin@example.com", "admin", "admin123"),
        ("김교수", "prof@example.com", "instructor", "prof123"),
        ("홍학생", "student@example.com", "student", "student123"),
    ]
    for name, email, role, pw in demo_users:
        u = db.session.query(User).filter(func.lower(User.email) == email.lower()).first()
        if not u:
            u = User(
                name=name,
                email=email,
                role=role,
                username=email.split("@")[0],
                created_at=datetime.utcnow(),
            )
            if hasattr(User, "password_hash"):
                u.password_hash = generate_password_hash(pw)
            elif hasattr(User, "password"):
                u.password = pw
            db.session.add(u)
            created.append(email)
    if created:
        db.session.commit()

    flash(f"데모 계정 준비 완료: {', '.join(created) if created else '이미 존재함'}", "success")
    return redirect(url_for("auth.home"))