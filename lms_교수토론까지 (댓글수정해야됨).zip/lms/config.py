# config.py — Unified & Backward-Compatible
import os
from urllib.parse import quote_plus

# ─────────────────────────────────────────────────────────────────────────────
# 공통/기본 경로
# ─────────────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """
    통합 설정:
    - 두 버전의 옵션을 모두 포함
    - 기존 코드와의 호환을 위해 경로/이름 별칭 제공
    - 환경변수 우선, 없으면 합리적인 기본값
    """

    # ── DB ───────────────────────────────────────────────────────────────────
    # 1) 완전 DSN 지정이 들어오면 그걸 최우선 사용
    SQLALCHEMY_DATABASE_URI = os.environ.get("SQLALCHEMY_DATABASE_URI")

    # 2) DSN이 없다면, 개별 ENV로부터 안전하게 구성(특수문자 비번 인코딩)
    if not SQLALCHEMY_DATABASE_URI:
        DB_USER = os.getenv("DB_USER", "wsuser")                  # v1 기본: wsuser
        DB_PASS = os.getenv("DB_PASS", "wsuser!")                 # v1 기본 비번
        DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
        DB_PORT = os.getenv("DB_PORT", "3306")
        DB_NAME = os.getenv("DB_NAME", "lms_db")
        _pwd_enc = quote_plus(DB_PASS)
        SQLALCHEMY_DATABASE_URI = (
            f"mysql+pymysql://{DB_USER}:{_pwd_enc}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
        )

    # 레거시 기본 DSN과 보강판 기본 DSN도 별칭으로 보관(필요시 참고/로그 등)
    LEGACY_DEFAULT_URI = "mysql+pymysql://wsuser:wsuser!@127.0.0.1:3306/lms_db?charset=utf8mb4"
    ENHANCED_DEFAULT_URI = "mysql+pymysql://root:root1234@127.0.0.1:3306/lms_db?charset=utf8mb4"

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 1800,  # 30분마다 재연결(MySQL server has gone away 예방)
        "pool_size": 5,
        "max_overflow": 10,
    }

    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "dev-secret")

    # ── 경로(양 버전 호환) ───────────────────────────────────────────────────
    # v1(기존): static/uploads 트리
    BASE_DIR = BASE_DIR
    STATIC_UPLOAD_ROOT = os.path.join(BASE_DIR, "static", "uploads")
    AVATAR_SUBDIR = "avatars"   # v1에서 사용
    RESUME_SUBDIR = "resumes"   # v1에서 사용
    AVATAR_DIR = os.path.join(STATIC_UPLOAD_ROOT, AVATAR_SUBDIR)
    RESUME_DIR = os.path.join(STATIC_UPLOAD_ROOT, RESUME_SUBDIR)

    # v2(보강판): uploads 트리 + materials 하위
    UPLOAD_ROOT_V2 = os.path.join(BASE_DIR, "uploads")
    MATERIALS_DIR = os.path.join(UPLOAD_ROOT_V2, "materials")

    # 주 경로(UPDLOAD_ROOT/UPLOAD_DIR)는 환경변수로 오버라이드 가능.
    # - 기본값은 v1과 동일하게 static/uploads 를 우선으로 지정.
    UPLOAD_ROOT = os.environ.get("UPLOAD_ROOT", STATIC_UPLOAD_ROOT)
    UPLOAD_DIR = UPLOAD_ROOT  # 두 버전 모두에서 참조하던 이름

    # 보조 별칭: 둘 다 노출해서 어느 코드에서도 참조 가능
    UPLOAD_ROOT_V1 = STATIC_UPLOAD_ROOT
    UPLOAD_ROOT_V2_ALIAS = UPLOAD_ROOT_V2  # 이름 겹침 방지용 별칭

    # ── 업로드 정책(두 버전 통합) ────────────────────────────────────────────
    ALLOWED_IMAGE_EXTS = {"png", "jpg", "jpeg", "gif"}  # v1
    ALLOWED_DOC_EXTS = {"pdf", "doc", "docx"}           # v1
    ALLOWED_VIDEO_EXTS = {"mp4", "webm", "mov", "m4v"}  # v2 추가

    # v1+v2 통합 확장자 묶음(양쪽 모두 포함)
    ALLOWED_EXTS = {
        "pdf", "zip", "doc", "docx", "ppt", "pptx", "xlsx", "csv",
        "ipynb", "py", "txt", "md", "rar",
        "jpg", "jpeg", "png", "gif",
        "mp4", "webm", "mov", "m4v",
    }

    # 최대 업로드 용량(보강판에 있었던 설정)
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_MB", "512")) * 1024 * 1024

    # ── 표시/템플릿/정적 파일(보강판 추가) ───────────────────────────────────
    JSON_AS_ASCII = False
    TEMPLATES_AUTO_RELOAD = True
    SEND_FILE_MAX_AGE_DEFAULT = 3600  # 1시간(운영은 CDN/NGINX 권장)

    # ── 세션/쿠키(보강판 추가) ─────────────────────────────────────────────
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "0") == "1"

    # ── 데모 사용자/날짜 포맷(공통) ─────────────────────────────────────────
    DEMO_USER_ID = int(os.environ.get("DEMO_USER_ID", 1))

    DATE_ONLY = "%Y-%m-%d"
    DATE_HM = "%Y-%m-%d %H:%M"
    DATE_T = "%Y-%m-%dT%H:%M"


# ── 필요 폴더 자동 생성(모든 트리 생성) ─────────────────────────────────────
try:
    # v1 경로 트리
    os.makedirs(Config.STATIC_UPLOAD_ROOT, exist_ok=True)
    os.makedirs(Config.AVATAR_DIR, exist_ok=True)
    os.makedirs(Config.RESUME_DIR, exist_ok=True)

    # v2 경로 트리
    os.makedirs(Config.UPLOAD_ROOT_V2_ALIAS, exist_ok=True)
    os.makedirs(Config.MATERIALS_DIR, exist_ok=True) 

    # 실제 사용되는 UPLOAD_ROOT(환경변수로 바뀔 수 있음)도 보장
    os.makedirs(Config.UPLOAD_ROOT, exist_ok=True)
except Exception:
    # 권한 문제 등은 무시(앱 기동 시 다시 시도 가능)
    pass