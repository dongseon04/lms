# extensions.py — 확장 인스턴스
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()