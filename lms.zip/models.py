# models.py
from __future__ import annotations

from datetime import datetime
from typing import Optional, List

from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func, BigInteger, Index
from extensions import db
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import INTEGER as MyInt, LONGBLOB, BIGINT
from sqlalchemy import Enum as SAEnum
from sqlalchemy.dialects.mysql import JSON as MyJSON

# ─────────────────────────────────────────────────────────────────────────────
# User
# ─────────────────────────────────────────────────────────────────────────────
class User(db.Model):
    __tablename__ = "users"
    __table_args__ = (
        db.Index("ix_users_role", "role"),
        db.Index("ix_users_is_active", "is_active"),
        db.UniqueConstraint("email", name="uq_users_email"),
        db.UniqueConstraint("username", name="uq_users_username"),
    )

    # 기본
    id: int = db.Column(db.Integer, primary_key=True)
    name: str = db.Column(db.String(100), nullable=False)
    email: str = db.Column(db.String(190), nullable=False)
    department = db.Column("department", db.String(120))

    # 계정/상태
    role: str = db.Column(db.String(20), nullable=False, default="student")  # student|instructor|admin
    username: Optional[str] = db.Column(db.String(50))
    phone: Optional[str] = db.Column(db.String(30))
    is_active: bool = db.Column(db.Boolean, nullable=False, default=True)

    # 레거시/부가 정보
    student_no: Optional[str] = db.Column(db.String(50))
    school: Optional[str] = db.Column(db.String(120))  # ✅ 추가: 학교
    github_url: Optional[str] = db.Column(db.String(255), default="https://github.com/kim-smile")
    profile_image: Optional[str] = db.Column(db.String(255))
    resume_file: Optional[str] = db.Column(db.String(255))

    # 비밀번호
    password_hash: Optional[str] = db.Column(db.String(255))
    password: Optional[str] = db.Column(db.String(128))

    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # 관계
    enrollments = db.relationship("Enrollment", back_populates="user", cascade="all,delete-orphan")
    submissions = db.relationship("Submission", back_populates="user", cascade="all,delete")
    # 교수/관리자 업로드 자료(보강판)
    uploaded_materials = db.relationship("Material", back_populates="owner", cascade="all,delete")

     # ✅ 여기만 남기고 back_populates 사용 (backref 금지)
    markers = db.relationship(
        "UserMarker",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    # helpers
    def set_password(self, raw: str) -> None:
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw: str) -> bool:
        if self.password_hash:
            return check_password_hash(self.password_hash, raw)
        if self.password:
            return self.password == raw
        return False

    def __repr__(self) -> str:
        return f"<User id={self.id} name={self.name!r} email={self.email!r}>"


# ─────────────────────────────────────────────────────────────────────────────
# Course
# ─────────────────────────────────────────────────────────────────────────────
class Course(db.Model):
    __tablename__ = "courses"
    __table_args__ = (
        db.Index("ix_courses_start_date", "start_date"),
        db.Index("ix_courses_end_date", "end_date"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    title: str = db.Column(db.String(200), nullable=False)

    # 기간/메타(보강판 확장)
    start_date: Optional[datetime] = db.Column(db.Date)
    end_date: Optional[datetime] = db.Column(db.Date)
    description: Optional[str] = db.Column(db.Text)
    schedule_text: Optional[str] = db.Column(db.String(120))  # 예: '월, 수 14:00-15:30'
    credit: int = db.Column(db.Integer, default=3)

    # 담당 교수(단일)
    instructor_user_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("users.id"))
    instructor = db.relationship("User", foreign_keys=[instructor_user_id])

    @property
    def professor_id(self) -> Optional[int]:
        return self.instructor_user_id
    
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # 관계
    enrollments = db.relationship("Enrollment", back_populates="course", cascade="all,delete-orphan")
    assignments = db.relationship("Assignment", back_populates="course", cascade="all,delete-orphan")
    # 자료(보강판)
    materials = db.relationship("Material", back_populates="course", cascade="all,delete-orphan", lazy="dynamic")

    def __repr__(self) -> str:
        return f"<Course id={self.id} title={self.title!r}>"


# ─────────────────────────────────────────────────────────────────────────────
# Enrollment
# ─────────────────────────────────────────────────────────────────────────────
class Enrollment(db.Model):
    __tablename__ = "enrollments"
    __table_args__ = (
        db.Index("ix_enrollments_user", "user_id"),
        db.Index("ix_enrollments_course", "course_id"),
        db.UniqueConstraint("user_id", "course_id", name="uq_enroll_user_course"),  # 보강판 제약 포함
    )

    id: int = db.Column(db.Integer, primary_key=True)
    user_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    course_id: int = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="enrollments")
    course = db.relationship("Course", back_populates="enrollments")

    def __repr__(self) -> str:
        return f"<Enrollment id={self.id} user_id={self.user_id} course_id={self.course_id}>"


# ─────────────────────────────────────────────────────────────────────────────
# Assignment
# ─────────────────────────────────────────────────────────────────────────────
class Assignment(db.Model):
    __tablename__ = "assignments"
    __table_args__ = (
        db.Index("ix_assignments_course", "course_id"),
        db.Index("ix_assignments_due", "due_at"),
    )

    id         = db.Column(db.Integer, primary_key=True)
    course_id  = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    title      = db.Column(db.String(200), nullable=False)
    due_at     = db.Column(db.DateTime)
    total_score= db.Column(db.Integer, nullable=False, default=100)

    # 설명/첨부
    description     = db.Column(db.Text, nullable=True)
    attachment_data = db.Column(db.LargeBinary, nullable=True)     # LONGBLOB
    attachment_name = db.Column(db.String(255), nullable=True)
    attachment_mime = db.Column(db.String(100), nullable=True)
    attachment_size = db.Column(BigInteger, nullable=True)
    attachment_md5  = db.Column(db.String(32), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 관계 (중복 선언 제거)
    course = db.relationship("Course", back_populates="assignments")
    submissions = db.relationship(
        "Submission", back_populates="assignment", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Assignment id={self.id} course_id={self.course_id} title={self.title!r}>"



# ─────────────────────────────────────────────────────────────────────────────
# Submission
# ─────────────────────────────────────────────────────────────────────────────
class Submission(db.Model):
    __tablename__ = "submissions"
    __table_args__ = (
        db.Index("ix_submissions_user", "user_id"),
        db.Index("ix_submissions_assignment", "assignment_id"),
        db.Index("ix_submissions_submitted_at", "submitted_at"),
        db.UniqueConstraint("user_id", "assignment_id", name="uq_sub_user_assignment"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    assignment_id: int = db.Column(db.Integer, db.ForeignKey("assignments.id"), nullable=False)
    user_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    submitted_at: Optional[datetime] = db.Column(db.DateTime)
    score: Optional[int] = db.Column(db.Integer)

    # 첨부/메타
    file_url: Optional[str] = db.Column(db.String(255))
    comment: Optional[str] = db.Column(db.Text)
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Optional[datetime] = db.Column(db.DateTime, onupdate=datetime.utcnow)
    graded_at: Optional[datetime] = db.Column(db.DateTime)

    assignment = db.relationship("Assignment", back_populates="submissions")
    user = db.relationship("User", back_populates="submissions")

    @property
    def is_late(self) -> bool:
        if not self.submitted_at or not self.assignment or not self.assignment.due_at:
            return False
        return self.submitted_at > self.assignment.due_at

    def __repr__(self) -> str:
        return f"<Submission id={self.id} assignment_id={self.assignment_id} user_id={self.user_id}>"

# =============================================================================
# Learning Materials (강의자료) + Events(재생/다운로드 로그)
# =============================================================================
class Material(db.Model):
    """
    강의자료(영상/파일/외부링크). 로컬 파일은 file_path 기준으로 /u/<path> 로 서빙,
    외부 경로(S3/유튜브)는 storage_url로 리다이렉트.
    """
    __tablename__ = "materials"
    __table_args__ = (
        db.Index("ix_materials_course", "course_id"),
        db.Index("ix_materials_week", "week"),
        db.Index("ix_materials_published", "is_published"),
    )


    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    owner_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    title = db.Column(db.String(200), nullable=False)
    week = db.Column(db.Integer)  # 주차(선택)

    # video | file | link
    kind = db.Column(db.Enum("video", "file", "link", name="material_kind"), nullable=False, default="video")

    # 외부/스트리밍 주소(유튜브/S3/사내 CDN 등). 있으면 우선 사용
    storage_url = db.Column(db.String(500))

    # 로컬 저장상대경로 (예: "materials/1/1-html.mp4" 또는 "materials/1/html.zip")
    file_path = db.Column(db.String(255))

    mime = db.Column(db.String(120))
    size_bytes = db.Column(db.Integer)
    duration_seconds = db.Column(db.Integer)  # 영상 길이(선택)

    # 노출/다운로드 정책
    is_published = db.Column(db.Boolean, nullable=False, default=True)     # 학생에게 노출 여부
    is_downloadable = db.Column(db.Boolean, nullable=False, default=True)  # 다운로드 허용

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    course = db.relationship("Course", back_populates="materials")
    owner = db.relationship("User", back_populates="uploaded_materials")
    events = db.relationship("MaterialEvent", back_populates="material", cascade="all,delete-orphan")

    def __repr__(self) -> str:
        return f"<Material id={self.id} course_id={self.course_id} title={self.title!r} kind={self.kind}>"


class MaterialEvent(db.Model):
    """
    자료 사용 로그: 재생(play), 완료(complete), 다운로드(download)
    seconds_watched는 프런트에서 전송 시 저장(선택)
    """
    __tablename__ = "material_events"
    __table_args__ = (
        db.Index("ix_mevents_user", "user_id"),
        db.Index("ix_mevents_material", "material_id"),
        db.Index("ix_mevents_action", "action"),
        db.Index("ix_mevents_created_at", "created_at"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    material_id = db.Column(db.Integer, db.ForeignKey("materials.id"), nullable=False)

    action = db.Column(db.Enum("play", "complete", "download", name="material_action"), nullable=False)
    seconds_watched = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User")
    material = db.relationship("Material", back_populates="events")

    def __repr__(self) -> str:
        return f"<MaterialEvent id={self.id} material_id={self.material_id} user_id={self.user_id} action={self.action}>"
    
# =============================================================================
# Mentoring
# =============================================================================
class MentoringTeam(db.Model):
    __tablename__ = "mentoring_teams"
    __table_args__ = (db.Index("ix_mentoring_teams_owner", "owner_user_id"),)

    id: int = db.Column(db.Integer, primary_key=True)
    name: str = db.Column(db.String(120), nullable=False)
    owner_user_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)  # 팀장
    is_solo: bool = db.Column(db.Boolean, nullable=False, default=False)
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    owner = db.relationship("User", foreign_keys=[owner_user_id])
    members = db.relationship("MentoringTeamMember", back_populates="team", cascade="all,delete-orphan")

    def __repr__(self) -> str:
        return f"<MentoringTeam id={self.id} name={self.name!r}>"


class MentoringTeamMember(db.Model):
    __tablename__ = "mentoring_team_members"
    __table_args__ = (
        db.Index("ix_mtm_team", "team_id"),
        db.Index("ix_mtm_user", "user_id"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    team_id: int = db.Column(db.Integer, db.ForeignKey("mentoring_teams.id"), nullable=False)
    user_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    role: str = db.Column(db.String(40), default="member")  # member|leader|mentor
    joined_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    team = db.relationship("MentoringTeam", back_populates="members")
    user = db.relationship("User")

    def __repr__(self) -> str:
        return f"<MentoringTeamMember id={self.id} team_id={self.team_id} user_id={self.user_id} role={self.role}>"


class MentoringReport(db.Model):
    __tablename__ = "mentoring_reports"
    __table_args__ = (
        db.Index("ix_mreports_author", "author_user_id"),
        db.Index("ix_mreports_team", "team_id"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    author_user_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    team_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("mentoring_teams.id"))
    title: str = db.Column(db.String(200), nullable=False)
    content: Optional[str] = db.Column(db.Text)
    file_url: Optional[str] = db.Column(db.String(255))
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    author = db.relationship("User")
    team = db.relationship("MentoringTeam")

    def __repr__(self) -> str:
        return f"<MentoringReport id={self.id} title={self.title!r}>"


class Project(db.Model):
    __tablename__ = "projects"
    __table_args__ = (
        db.Index("ix_projects_team", "team_id"),
        db.Index("ix_projects_owner", "owner_user_id"),
        db.Index("ix_projects_status", "status"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    title: str = db.Column(db.String(200), nullable=False)
    description: Optional[str] = db.Column(db.Text)
    team_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("mentoring_teams.id"))
    owner_user_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("users.id"))
    mentor_user_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("users.id"))
    status: str = db.Column(db.String(30), default="ongoing")  # ongoing|done|paused
    github_repo_url: Optional[str] = db.Column(db.String(255))
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    team = db.relationship("MentoringTeam")
    owner = db.relationship("User", foreign_keys=[owner_user_id])
    mentor = db.relationship("User", foreign_keys=[mentor_user_id])
    tasks = db.relationship("ProjectTask", back_populates="project", cascade="all,delete-orphan")

    def __repr__(self) -> str:
        return f"<Project id={self.id} title={self.title!r} status={self.status}>"


class ProjectTask(db.Model):
    __tablename__ = "project_tasks"
    __table_args__ = (
        db.Index("ix_ptasks_project", "project_id"),
        db.Index("ix_ptasks_assignee", "assignee_user_id"),
        db.Index("ix_ptasks_due", "due_at"),
        db.Index("ix_ptasks_status", "status"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    project_id: int = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=False)
    title: str = db.Column(db.String(200), nullable=False)
    due_at: Optional[datetime] = db.Column(db.DateTime)
    assignee_user_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("users.id"))
    status: str = db.Column(db.String(20), default="todo")  # todo|doing|done
    description: Optional[str] = db.Column(db.Text)

    project = db.relationship("Project", back_populates="tasks")
    assignee = db.relationship("User")

    def __repr__(self) -> str:
        return f"<ProjectTask id={self.id} project_id={self.project_id} title={self.title!r}>"


class Competition(db.Model):
    __tablename__ = "competitions"
    __table_args__ = (
        db.Index("ix_competitions_deadline", "apply_deadline"),
        db.Index("ix_competitions_start", "start_at"),
        db.Index("ix_competitions_end", "end_at"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    title: str = db.Column(db.String(200), nullable=False)
    host: Optional[str] = db.Column(db.String(120))
    url: Optional[str] = db.Column(db.String(255))
    apply_deadline: Optional[datetime] = db.Column(db.DateTime)
    start_at: Optional[datetime] = db.Column(db.DateTime)
    end_at: Optional[datetime] = db.Column(db.DateTime)

    def __repr__(self) -> str:
        return f"<Competition id={self.id} title={self.title!r}>"


class CompetitionEntry(db.Model):
    __tablename__ = "competition_entries"
    __table_args__ = (
        db.Index("ix_centries_competition", "competition_id"),
        db.Index("ix_centries_team", "team_id"),
        db.Index("ix_centries_applicant", "applicant_user_id"),
        db.Index("ix_centries_project", "project_id"),
        db.Index("ix_centries_status", "status"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    competition_id: int = db.Column(db.Integer, db.ForeignKey("competitions.id"), nullable=False)
    team_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("mentoring_teams.id"))
    applicant_user_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("users.id"))
    project_id: Optional[int] = db.Column(db.Integer, db.ForeignKey("projects.id"))
    status: str = db.Column(db.String(20), default="draft")  # draft|submitted|accepted|rejected
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    competition = db.relationship("Competition")
    team = db.relationship("MentoringTeam")
    applicant = db.relationship("User")
    project = db.relationship("Project")

    def __repr__(self) -> str:
        return f"<CompetitionEntry id={self.id} competition_id={self.competition_id} status={self.status}>"
    
class ProjectTaskFile(db.Model):
    __tablename__ = "project_task_files"
    __table_args__ = (
        db.Index("idx_ptf_task", "task_id"),
        db.Index("idx_ptf_uploader", "uploader_user_id"),
    )

    id: int = db.Column(db.Integer, primary_key=True)
    task_id: int = db.Column(db.Integer, db.ForeignKey("project_tasks.id"), nullable=False)
    file_url: str = db.Column(db.String(255), nullable=False)
    filename: str | None = db.Column(db.String(255))
    size_bytes: int | None = db.Column(db.BigInteger)
    uploader_user_id: int | None = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at: datetime = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    task = db.relationship("ProjectTask", back_populates="attachments")
    uploader = db.relationship("User")

    def __repr__(self) -> str:
        return f"<ProjectTaskFile id={self.id} task_id={self.task_id} filename={self.filename!r}>"

# ProjectTask에 관계 추가 (기존 클래스 정의에 다음 줄을 추가하세요)
ProjectTask.attachments = db.relationship(
    "ProjectTaskFile",
    back_populates="task",
    cascade="all,delete-orphan",
    order_by=ProjectTaskFile.created_at.desc()
)


# =============================================================================
# Boards / Posts / Attachments
# =============================================================================
class Board(db.Model):
    __tablename__ = "boards"
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(32), unique=True, nullable=False)  # 'notice' | 'free'
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    posts = db.relationship("Post", back_populates="board", cascade="all,delete-orphan")


class Post(db.Model):
    __tablename__ = "posts"
    __table_args__ = (
        db.Index("idx_posts_board_created", "board_id", "created_at"),
        db.Index("idx_posts_board_pinned", "board_id", "is_pinned", "created_at"),
    )
    id = db.Column(db.Integer, primary_key=True)
    board_id = db.Column(db.Integer, db.ForeignKey("boards.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text)
    is_pinned = db.Column(db.Boolean, default=False, nullable=False)
    is_locked = db.Column(db.Boolean, default=False, nullable=False)
    views = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    board = db.relationship("Board", back_populates="posts")
    author = db.relationship("User")
    attachments = db.relationship("Attachment", back_populates="post", cascade="all,delete-orphan")


class Attachment(db.Model):
    __tablename__ = "attachments"
    __table_args__ = (db.Index("idx_attach_post", "post_id"),)

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    kind = db.Column(db.Enum("file", "url"), nullable=False)  # 'file' or 'url'
    storage_path = db.Column(db.String(255))
    original_name = db.Column(db.String(255))
    content_type = db.Column(db.String(100))
    file_size = db.Column(db.BigInteger)
    url = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    post = db.relationship("Post", back_populates="attachments")

    @property
    def is_file(self) -> bool:
        return self.kind == "file" and self.storage_path

    @property
    def is_url(self) -> bool:
        return self.kind == "url" and self.url


# =============================================================================
# Messages + Profile (UserSetting)
# =============================================================================
class Message(db.Model):
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text)
    read_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, server_default=func.now(), nullable=False)

    # 테이블 컬럼명과 정확히 일치 (코드/SQL 통일)
    sender_deleted = db.Column(db.Boolean, nullable=False, default=False)
    receiver_deleted = db.Column(db.Boolean, nullable=False, default=False)

    sender = db.relationship("User", foreign_keys=[sender_id])
    receiver = db.relationship("User", foreign_keys=[receiver_id])

    @property
    def is_read(self) -> bool:
        return self.read_at is not None


class UserSetting(db.Model):
    __tablename__ = "user_settings"
    __table_args__ = (db.Index("ix_usersettings_user", "user_id"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    language = db.Column(db.String(10), default="ko")
    theme = db.Column(db.String(10), default="light")  # light|dark
    timezone = db.Column(db.String(50), default="Asia/Seoul")
    email_notifications = db.Column(db.Boolean, default=True, nullable=False)
    push_notifications = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    user = db.relationship("User")

    def __repr__(self) -> str:
        return f"<UserSetting id={self.id} user_id={self.user_id} theme={self.theme}>"
    
# =============================================================================
# 공지사항
# =============================================================================
class Notice(db.Model):
    __tablename__ = "notices"
    id             = db.Column(db.Integer, primary_key=True)
    course_id      = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    author_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    title     = db.Column(db.String(200), nullable=False)
    body      = db.Column(db.Text, nullable=False)
    is_pinned = db.Column(db.Boolean, nullable=False, default=False)

    created_at = db.Column(db.DateTime, server_default=func.now(), nullable=False)
    updated_at = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    # 첨부는 전용 테이블 사용
    attachments = db.relationship(
        "NoticeAttachment",
        back_populates="notice",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

class NoticeAttachment(db.Model):
    __tablename__ = "notice_attachments"
    id         = db.Column(db.Integer, primary_key=True)
    notice_id  = db.Column(db.Integer, db.ForeignKey("notices.id", ondelete="CASCADE"), nullable=False)
    file_path  = db.Column(db.String(255))
    storage_url= db.Column(db.String(2048))
    filename   = db.Column(db.String(255), nullable=False)
    size_bytes = db.Column(db.BigInteger)
    created_at = db.Column(db.DateTime, server_default=func.now(), nullable=False)

    notice = db.relationship("Notice", back_populates="attachments")

    def __repr__(self):
        return f"<NoticeAttachment id={self.id} notice_id={self.notice_id} filename={self.filename!r}>"


# =============================================================================
# 토론 (바꿈)
# =============================================================================
class DiscussionThread(db.Model):
    __tablename__ = "discussion_threads"
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    author_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now())

    # 관계
    course = relationship("Course", lazy="joined")
    author = relationship("User", lazy="joined")
    comments = relationship(
        "DiscussionComment",
        back_populates="thread",
        cascade="all, delete-orphan"
    )


class DiscussionComment(db.Model):
    __tablename__ = "discussion_comments"
    id = db.Column(db.Integer, primary_key=True)
    thread_id = db.Column(
        db.Integer,
        db.ForeignKey("discussion_threads.id", ondelete="CASCADE", onupdate="CASCADE"),
        nullable=False
    )
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id", ondelete="CASCADE", onupdate="CASCADE"),
        nullable=False
    )
    parent_id = db.Column(
        db.Integer,
        db.ForeignKey("discussion_comments.id", ondelete="CASCADE", onupdate="CASCADE"),
        nullable=True
    )
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now())

    # 관계
    thread = relationship("DiscussionThread", back_populates="comments")
    user = relationship("User", lazy="joined")  # 템플릿에서 c.user.name 사용 가능
    parent = relationship(
        "DiscussionComment",
        remote_side=[id],
        backref=backref("children", cascade="all, delete-orphan")
    )


class DiscussionCommentLike(db.Model):
    __tablename__ = "discussion_comment_likes"
    comment_id = db.Column(
        db.Integer,
        db.ForeignKey("discussion_comments.id", ondelete="CASCADE", onupdate="CASCADE"),
        primary_key=True
    )
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id", ondelete="CASCADE", onupdate="CASCADE"),
        primary_key=True
    )
    created_at = db.Column(db.DateTime, server_default=func.now())


# DiscussionComment <-> Like 관계 (표시/카운트 용)
DiscussionComment.likes = relationship(
    "DiscussionCommentLike",
    backref=backref("comment", lazy="joined"),
    cascade="all, delete-orphan",
    passive_deletes=True,
)


# =============================================================================
# BLOB (비디오) — MaterialBlob
# =============================================================================
class MaterialBlob(db.Model):
    __tablename__ = "material_blobs"

    id = db.Column(MyInt(unsigned=True), primary_key=True)
    material_id = db.Column(
        MyInt(unsigned=True),
        db.ForeignKey("materials.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    data = db.Column(LONGBLOB, nullable=False)                 # 최대 4GB
    size_bytes = db.Column(BIGINT(unsigned=True))
    mime_type  = db.Column(db.String(100), default="video/mp4")
    checksum_md5 = db.Column(db.String(32))

    created_at = db.Column(db.DateTime, server_default=func.now(), nullable=False)
    updated_at = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    material = db.relationship(
        "Material",
        backref=db.backref("blob", uselist=False, cascade="all, delete-orphan", lazy="joined"),
    )

ParentKindType = SAEnum(
    "course", "assignment", "notice",
    "mentoring_report", "project", "task",   # ← 추가
    name="course_attachment_kind",
    native_enum=False,
    validate_strings=True,
    create_constraint=True,
)


# 모델: CourseAttachment
class CourseAttachment(db.Model):
    __tablename__ = "course_attachments"

    id = db.Column(db.Integer, primary_key=True)
    # ⬇⬇⬇ nullable=True 로 변경, FK는 SET NULL 또는 CASCADE 중 DB와 맞추세요
    course_id   = db.Column(
        db.Integer,
        db.ForeignKey("courses.id", ondelete="SET NULL"),
        nullable=True
    )
    parent_kind = db.Column(ParentKindType, nullable=False, default="course")
    parent_id   = db.Column(db.Integer, nullable=True, index=True)

    filename = db.Column(db.String(255), nullable=False)
    mime     = db.Column(db.String(100), nullable=False, default="application/octet-stream")
    size     = db.Column(db.BigInteger)
    md5      = db.Column(db.String(32))
    data     = db.Column(LONGBLOB)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    course = db.relationship("Course", backref=db.backref("attachments", cascade="all, delete-orphan"))

    __table_args__ = (Index("ix_ca_scope", "course_id", "parent_kind", "parent_id"),)

# =============================================================================
# Attendance (ArUco)
# =============================================================================

AttStatus = SAEnum(
    "present", "late", "absent", "excused",
    name="att_status",
    native_enum=False, validate_strings=True, create_constraint=True,
)
AttSource = SAEnum(
    "auto", "manual",
    name="att_source",
    native_enum=False, validate_strings=True, create_constraint=True,
)
DetSource = SAEnum(
    "prof_cam", "student_cam", "upload",
    name="det_source",
    native_enum=False, validate_strings=True, create_constraint=True,
)

class UserMarker(db.Model):
    __tablename__ = "user_markers"
    id = db.Column(MyInt(unsigned=True), primary_key=True, autoincrement=True)
    user_id = db.Column(MyInt(unsigned=True), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    marker_id = db.Column(db.Integer, nullable=False)  # ArUco ID
    marker_filename = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        db.UniqueConstraint("user_id", "marker_id", name="uq_user_marker"),
        db.UniqueConstraint("marker_id", name="uq_marker_id"),
        db.Index("ix_user_markers_user", "user_id"),
    )

    # ✅ back_populates로만 연결
    user = db.relationship("User", back_populates="markers")


class AttendanceSession(db.Model):
    __tablename__ = "attendance_sessions"
    id = db.Column(MyInt(unsigned=True), primary_key=True, autoincrement=True)
    course_id = db.Column(MyInt(unsigned=True), db.ForeignKey("courses.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    title = db.Column(db.String(120))
    session_code = db.Column(db.String(8), nullable=False, unique=True)
    opens_at = db.Column(db.DateTime, nullable=False)
    closes_at = db.Column(db.DateTime, nullable=False)
    created_by = db.Column(MyInt(unsigned=True), db.ForeignKey("users.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    is_open = db.Column(db.Boolean, nullable=False, default=True)
    allow_student_self_tag = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    course = db.relationship("Course")
    creator = db.relationship("User", foreign_keys=[created_by])

    detections = db.relationship("AttendanceDetection", back_populates="session", cascade="all,delete-orphan")
    records = db.relationship("AttendanceRecord", back_populates="session", cascade="all,delete-orphan")

    __table_args__ = (db.Index("idx_session_course_time", "course_id", "opens_at", "closes_at"),)

class AttendanceDetection(db.Model):
    __tablename__ = "attendance_detections"
    id = db.Column(MyInt(unsigned=True), primary_key=True, autoincrement=True)
    session_id = db.Column(MyInt(unsigned=True), db.ForeignKey("attendance_sessions.id", ondelete="CASCADE"), nullable=False)
    marker_id = db.Column(db.Integer, nullable=False)
    detected_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    bbox_json = db.Column(MyJSON)                 # MariaDB 10.2+; 낮으면 TEXT로 변경
    raw_identity_json = db.Column(MyJSON)
    candidate_user_id = db.Column(MyInt(unsigned=True), db.ForeignKey("users.id", ondelete="SET NULL"))
    source = db.Column(DetSource, nullable=False, default="prof_cam")

    session = db.relationship("AttendanceSession", back_populates="detections")
    candidate = db.relationship("User")

    __table_args__ = (
        db.UniqueConstraint("session_id", "marker_id", name="uq_detect_once"),
        db.Index("idx_det_time", "detected_at"),
    )

class AttendanceRecord(db.Model):
    __tablename__ = "attendance_records"
    id = db.Column(MyInt(unsigned=True), primary_key=True, autoincrement=True)
    session_id = db.Column(MyInt(unsigned=True), db.ForeignKey("attendance_sessions.id", ondelete="CASCADE"), nullable=False)
    student_id = db.Column(MyInt(unsigned=True), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    marker_id = db.Column(db.Integer)
    status = db.Column(AttStatus, nullable=False, default="present")
    source = db.Column(AttSource, nullable=False, default="auto")
    marked_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    note = db.Column(db.String(255))

    session = db.relationship("AttendanceSession", back_populates="records")
    student = db.relationship("User")

    __table_args__ = (
        db.UniqueConstraint("session_id", "student_id", name="uq_session_student"),
        db.Index("idx_status", "status"),
    )

class AttendanceAudit(db.Model):
    __tablename__ = "attendance_audits"
    id = db.Column(MyInt(unsigned=True), primary_key=True, autoincrement=True)
    record_id = db.Column(MyInt(unsigned=True), db.ForeignKey("attendance_records.id", ondelete="CASCADE"), nullable=False)
    changed_by = db.Column(MyInt(unsigned=True), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    old_status = db.Column(db.String(20))
    new_status = db.Column(db.String(20))
    changed_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    note = db.Column(db.String(255))

    record = db.relationship("AttendanceRecord")
    changer = db.relationship("User")

