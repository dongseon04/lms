# services/aruco_identity_system.py
from __future__ import annotations
import os, json
from typing import Dict, Any

# OpenCV(aruco)는 contrib 버전 필요
#   pip install opencv-contrib-python
try:
    import cv2
    _cv_ok = True
except Exception:
    cv2 = None
    _cv_ok = False

# PIL은 마커 PNG 저장/텍스트 합성 fallback용
try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = ImageDraw = ImageFont = None

# ✅ 넘파이 추가
try:
    import numpy as np
except Exception:
    np = None


class ArUcoIdentitySystem:
    """
    - identities_file: JSON 경로 (marker_id -> 메타)
    - markers_folder : 생성된 마커 PNG 저장 폴더
    - dictionary     : OpenCV ArUco dict name (예: DICT_4X4_50)
    """

    def __init__(self):
        self.identities_file: str = "aruco_identities.json"
        self.markers_folder: str = "static/markers"
        self.dictionary: str = "DICT_4X4_50"
        self.identities: Dict[str, Any] = {}

    # ─────────────────────────────────────────────────────────────
    # 데이터 로드/저장
    # ─────────────────────────────────────────────────────────────
    def load_identities(self) -> Dict[str, Any]:
        try:
            if os.path.exists(self.identities_file):
                with open(self.identities_file, "r", encoding="utf-8") as f:
                    self.identities = json.load(f) or {}
            else:
                self.identities = {}
        except Exception:
            self.identities = {}
        return self.identities

    def save_identities(self) -> None:
        os.makedirs(os.path.dirname(self.identities_file) or ".", exist_ok=True)
        with open(self.identities_file, "w", encoding="utf-8") as f:
            json.dump(self.identities, f, ensure_ascii=False, indent=2)

    # ─────────────────────────────────────────────────────────────
    # ArUco dict 핸들링
    # ─────────────────────────────────────────────────────────────
    def _get_aruco_dict(self):
        if not _cv_ok:
            return None
        try:
            aruco = cv2.aruco
        except Exception:
            return None

        name = (self.dictionary or "DICT_4X4_50").upper()
        if not name.startswith("DICT_"):
            name = "DICT_4X4_50"
        if not hasattr(aruco, name):
            name = "DICT_4X4_50"

        return aruco.getPredefinedDictionary(getattr(aruco, name))

    # ─────────────────────────────────────────────────────────────
    # 마커 생성 (PNG 파일 경로 반환)
    # ─────────────────────────────────────────────────────────────
    def create_identity_marker(self, marker_id: int, name: str = "", affiliation: str = "") -> str:
        os.makedirs(self.markers_folder, exist_ok=True)
        filename = f"{int(marker_id)}.png"
        out_path = os.path.join(self.markers_folder, filename)

        dict_obj = self._get_aruco_dict()

        if dict_obj is not None and np is not None:
            # ✅ OpenCV 경로 (버전 호환)
            aruco = cv2.aruco
            side_px = 600

            # 1) 마커 생성: drawMarker 우선, 실패하면 generateImageMarker
            try:
                marker = aruco.drawMarker(dict_obj, int(marker_id), side_px)
            except Exception:
                # 일부 버전은 drawMarker가 없거나 시그니처가 다를 수 있음
                marker = aruco.generateImageMarker(dict_obj, int(marker_id), side_px)

            # marker: uint8(0/255) 단일 채널. 흰 배경으로 변환/합성
            # (drawMarker는 흰 바탕/검은 마커이므로 그대로 사용)
            if marker.ndim == 2:
                marker_rgb = cv2.cvtColor(marker, cv2.COLOR_GRAY2BGR)
            else:
                marker_rgb = marker

            h, w = marker_rgb.shape[:2]
            label_h = 100
            # ✅ 흰색 캔버스 만들고 마커 붙이기
            full = np.full((h + label_h, w, 3), 255, dtype=np.uint8)
            full[0:h, 0:w, :] = marker_rgb

            # 2) 하단 라벨
            label_text = f"{name} | {affiliation} | ID:{marker_id}".strip(" |")
            cv2.putText(full, label_text, (10, h + 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2, cv2.LINE_AA)

            cv2.imwrite(out_path, full)

        else:
            # ✅ Fallback: PIL
            if Image is None:
                # PIL도 없으면 안내용 더미 파일(최소한의 유효 PNG 헤더) – 의존성 설치 권장
                with open(out_path, "wb") as f:
                    f.write(b"\x89PNG\r\n\x1a\n")
            else:
                img = Image.new("RGB", (600, 700), "white")
                d = ImageDraw.Draw(img)
                # 테두리 박스(마커 자리)
                d.rectangle([50, 50, 550, 550], outline="black", width=6)
                label = f"{name} | {affiliation} | ID:{marker_id}".strip(" |")
                d.text((60, 580), label, fill="black")
                img.save(out_path, format="PNG")

        # ✅ identities JSON 갱신
        key = str(marker_id)
        self.identities[key] = {
            "marker_id": marker_id,
            "name": name,
            "affiliation": affiliation,
            "file": out_path.replace("\\", "/"),
        }
        try:
            self.save_identities()
        except Exception:
            pass

        return out_path.replace("\\", "/")
