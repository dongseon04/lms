# services/aruco_engine.py
from __future__ import annotations
import os, threading
from typing import Any
from flask import current_app

_lock = threading.Lock()
_engine: Any = None  # ← Any로 변경

def get_engine() -> Any:   # ← 반환 타입도 Any
    global _engine
    if _engine is not None:
        return _engine
    with _lock:
        if _engine is not None:
            return _engine

        # 런타임 임포트 (services → 루트 순서)
        try:
            from services.aruco_identity_system import ArUcoIdentitySystem
        except Exception:
            from aruco_identity_system import ArUcoIdentitySystem

        cfg = current_app.config
        base_dir = cfg.get("BASE_DIR", current_app.root_path)
        identities_path = identities_path = (
            identities_path if (identities_path := cfg.get("ARUCO_IDENTITIES_JSON")) and os.path.isabs(identities_path)
            else os.path.join(base_dir, cfg.get("ARUCO_IDENTITIES_JSON", "aruco_identities.json"))
        )
        output_dir = (
            output_dir if (output_dir := cfg.get("ARUCO_OUTPUT_DIR")) and os.path.isabs(output_dir)
            else os.path.join(base_dir, cfg.get("ARUCO_OUTPUT_DIR", os.path.join("static","markers")))
        )

        os.makedirs(os.path.dirname(identities_path), exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)

        eng = ArUcoIdentitySystem()  # 네 구현은 인자 없는 생성자
        eng.identities_file = identities_path
        eng.markers_folder  = output_dir
        try:
            eng.identities = eng.load_identities()
        except Exception:
            eng.identities = {}

        _engine = eng
        return _engine
