# blueprints/attendance/routes.py
from __future__ import annotations
import io, os, secrets
from datetime import datetime, timedelta, timezone

from flask import Blueprint, render_template, request, jsonify, abort, g, send_file, url_for
from sqlalchemy import func

from extensions import db
from helpers.auth import login_required
from helpers.roles import ensure_course_owner_or_403, is_course_owner_or_admin
from models import Course, User, Enrollment, AttendanceSession, AttendanceRecord

bp = Blueprint("attendance", __name__, url_prefix="/attendance")

# ---- (선택) qrcode 의존성: pip install qrcode[pil]
try:
    import qrcode
except Exception:
    qrcode = None

UTC = timezone.utc


def _now_utc() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)  # DB naive UTC 사용 가정


# ─────────────────────────────────────────────────────────────
# 교수: 출석 세션 시작 (기본 10분)
# ─────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/start", endpoint="start")
@login_required
def start(course_id: int):
    course = ensure_course_owner_or_403(course_id)

    minutes = int(request.json.get("minutes", 10))
    now = _now_utc()

    code = secrets.token_urlsafe(6)[:8]  # 8자 세션 코드
    sess = AttendanceSession(
        course_id=course.id,
        created_by=g.user.id,
        session_code=code,
        opens_at=now,
        closes_at=now + timedelta(minutes=minutes),
        is_open=True,
        allow_student_self_tag=True,
    )
    db.session.add(sess)
    db.session.commit()

    prof_url = url_for("attendance.session_view", course_id=course.id, session_id=sess.id, _external=True)
    qr_png = url_for("attendance.qr_png", code=code, _external=True)
    return jsonify({"status": "ok", "session_id": sess.id, "session_code": code, "prof_url": prof_url, "qr_png": qr_png})


# ─────────────────────────────────────────────────────────────
# 교수: 세션 관리 화면 (선택)
# ─────────────────────────────────────────────────────────────
@bp.get("/<int:course_id>/session/<int:session_id>", endpoint="session_view")
@login_required
def session_view(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    rows = (
        db.session.query(AttendanceRecord, User)
        .join(User, AttendanceRecord.student_id == User.id)
        .filter(AttendanceRecord.session_id == sess.id)
        .order_by(AttendanceRecord.marked_at.asc())
        .all()
    )
    return render_template("pro/attendance_session.html", course=course, sess=sess, rows=rows)


# ─────────────────────────────────────────────────────────────
# QR 이미지 생성
# ─────────────────────────────────────────────────────────────
@bp.get("/qr/<code>.png", endpoint="qr_png")
def qr_png(code: str):
    url = url_for("attendance.session_landing", code=code, _external=True)
    if qrcode is None:
        # qrcode 모듈이 없으면 간단한 PNG 대체
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (480, 480), (235, 235, 235))
            d = ImageDraw.Draw(img)
            d.text((12, 220), "Install qrcode[pil]\n" + url, fill=(0, 0, 0))
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            buf.seek(0)
            return send_file(buf, mimetype="image/png")
        except Exception:
            # 완전 폴백: 텍스트/플레인
            return ("QR library missing", 200, {"Content-Type": "text/plain"})
    img = qrcode.make(url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


# ─────────────────────────────────────────────────────────────
# 학생: QR로 들어오는 랜딩 페이지
# ─────────────────────────────────────────────────────────────
@bp.get("/s/<code>", endpoint="session_landing")
@login_required
def session_landing(code: str):
    sess = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.session_code == code)
        .first()
    ) or abort(404)
    now = _now_utc()
    expired = (not sess.is_open) or (now > sess.closes_at)
    return render_template("attendance_landing.html", sess=sess, expired=expired)


# ─────────────────────────────────────────────────────────────
# 학생: 출석 버튼 → 기록
# ─────────────────────────────────────────────────────────────
@bp.post("/checkin", endpoint="checkin")
@login_required
def checkin():
    code = (request.json.get("code") or "").strip()
    sess = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.session_code == code)
        .first()
    ) or abort(404)

    now = _now_utc()
    if (not sess.is_open) or (now > sess.closes_at):
        return jsonify({"status": "closed"}), 410

    # 수강 여부 확인
    enrolled = (
        db.session.query(Enrollment.id)
        .filter_by(course_id=sess.course_id, user_id=g.user.id)
        .first()
    )
    if not enrolled:
        return jsonify({"status": "forbidden", "message": "수강 중이 아닙니다."}), 403

    # 중복 방지
    exist = (
        db.session.query(AttendanceRecord.id)
        .filter_by(session_id=sess.id, student_id=g.user.id)
        .first()
    )
    if exist:
        return jsonify({"status": "ok", "message": "이미 체크인됨"})

    status = "present" if (now <= sess.closes_at) else "late"
    db.session.add(AttendanceRecord(session_id=sess.id, student_id=g.user.id, status=status))
    db.session.commit()
    return jsonify({"status": "ok", "marked": status})


# ─────────────────────────────────────────────────────────────
# 교수: 세션 종료
# ─────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/session/<int:session_id>/close", endpoint="close")
@login_required
def close(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)
    sess.is_open = False
    db.session.commit()
    return jsonify({"status": "ok"})


# ─────────────────────────────────────────────────────────────
# 교수: 실시간 통계(출석/미출석 목록)
# ─────────────────────────────────────────────────────────────
@bp.get("/<int:course_id>/session/<int:session_id>/stats", endpoint="stats")
@login_required
def stats(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    # 출석한 학생
    pres = (
        db.session.query(AttendanceRecord, User)
        .join(User, AttendanceRecord.student_id == User.id)
        .filter(AttendanceRecord.session_id == sess.id)
        .order_by(AttendanceRecord.marked_at.asc())
        .all()
    )
    present = [
        {"id": u.id, "name": u.name, "email": u.email, "status": r.status}
        for r, u in pres
    ]
    present_ids = {u["id"] for u in present}

    # 전체 수강생
    roster = (
        db.session.query(User)
        .join(Enrollment, Enrollment.user_id == User.id)
        .filter(Enrollment.course_id == course.id)
        .order_by(User.name.asc())
        .all()
    )
    absent = [
        {"id": u.id, "name": u.name, "email": u.email}
        for u in roster
        if u.id not in present_ids
    ]

    now = _now_utc()
    return jsonify({
        "status": "ok",
        "is_open": bool(sess.is_open and (now <= sess.closes_at)),
        "present_count": len(present),
        "absent_count": len(absent),
        "present": present,
        "absent": absent,
    })
