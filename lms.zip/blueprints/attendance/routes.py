# blueprints/attendance/routes.py
from __future__ import annotations
import io, os, secrets
from datetime import datetime, timedelta, timezone

from flask import Blueprint, render_template, request, jsonify, abort, g, send_file, url_for
from sqlalchemy import func, delete
from sqlalchemy.exc import IntegrityError
from extensions import db
from helpers.auth import login_required
from helpers.roles import ensure_course_owner_or_403, is_course_owner_or_admin
from models import Course, User, Enrollment, AttendanceSession, AttendanceRecord
import string, secrets

bp = Blueprint("attendance", __name__, url_prefix="/attendance")

# ---- (선택) qrcode 의존성: pip install qrcode[pil]
try:
    import qrcode
except Exception:
    qrcode = None

UTC = timezone.utc
KST = timezone(timedelta(hours=9))

def _now_utc() -> datetime:
    """DB는 naive UTC 가정 → naive UTC 반환"""
    return datetime.now(UTC).replace(tzinfo=None)

def _to_kst(dt: datetime) -> str | None:
    """naive UTC → KST 문자열(YYYY-MM-DDTHH:MM:SS)"""
    if not dt:
        return None
    return dt.replace(tzinfo=UTC).astimezone(KST).strftime("%Y-%m-%dT%H:%M:%S")

def _gen_code(n: int = 6) -> str:
    """영문 소문자만 n자 생성"""
    alphabet = string.ascii_lowercase
    return ''.join(secrets.choice(alphabet) for _ in range(n))

def _is_session_open(sess) -> bool:
    """세션이 열려있는지 판단."""
    now = _now_utc()
    start_at = getattr(sess, "opens_at", None) or getattr(sess, "start_at", None) or getattr(sess, "started_at", None)
    end_at   = getattr(sess, "closes_at", None) or getattr(sess, "closed_at", None) or getattr(sess, "end_at", None) or getattr(sess, "ends_at", None)
    # naive UTC 로 통일
    if start_at and start_at.tzinfo: start_at = start_at.astimezone(UTC).replace(tzinfo=None)
    if end_at   and end_at.tzinfo:   end_at   = end_at.astimezone(UTC).replace(tzinfo=None)
    if start_at and now < start_at:  return False
    if end_at   and now >= end_at:   return False
    return bool(getattr(sess, "is_open", True))

def _status_by_time(sess, marked_at_utc_naive: datetime) -> str:
    """
    시간 기준으로 'present' / 'late' 판정.
    - 기준: sess.opens_at(+ late_after_sec)
    - late_after_sec가 없거나 0이면 항상 present
    """
    start_at = getattr(sess, "opens_at", None) or getattr(sess, "start_at", None) or getattr(sess, "started_at", None)
    if not start_at:
        return "present"
    if start_at.tzinfo:
        start_at = start_at.astimezone(UTC).replace(tzinfo=None)
    late_after_sec = int(getattr(sess, "late_after_sec", 0) or 0)
    if late_after_sec <= 0:
        return "present"
    return "late" if (marked_at_utc_naive - start_at).total_seconds() > late_after_sec else "present"

def _fmt_kst_hm(dt: datetime) -> str | None:
    """naive UTC -> KST 'YYYY-MM-DD HH:MM'"""
    if not dt:
        return None
    return dt.replace(tzinfo=UTC).astimezone(KST).strftime("%Y-%m-%d %H:%M")

def build_attendance_for_student(course: Course, user: User) -> dict:
    """course_detail 템플릿에 넘길 attendance 딕셔너리 구성"""
    sessions = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.course_id == course.id)
        .order_by(AttendanceSession.opens_at.desc())
        .all()
    )
    sid_list = [s.id for s in sessions]

    recs = []
    if sid_list:
        recs = (
            db.session.query(AttendanceRecord)
            .filter(
                AttendanceRecord.student_id == user.id,
                AttendanceRecord.session_id.in_(sid_list),
            )
            .all()
        )
    rec_map = {r.session_id: r for r in recs}

    now = _now_utc()
    rows = []
    cnt_present = cnt_late = cnt_absent = 0

    for s in sessions:
        r = rec_map.get(s.id)
        if r:
            st = (r.status or "").lower()
            if st == "late":
                code = "late"; cnt_late += 1
            else:
                code = "present"; cnt_present += 1
            marked = r.marked_at
        else:
            still_open = bool(s.is_open and (not s.closes_at or now <= s.closes_at))
            if still_open:
                code = "pending"; marked = None
            else:
                code = "absent"; cnt_absent += 1; marked = None

        rows.append({
            "session_id": s.id,
            "session_code": s.session_code,  # ✅ 템플릿에서 쓸 세션코드
            "start_at_str": _fmt_kst_hm(getattr(s, "opens_at", None) or getattr(s, "start_at", None)),
            "end_at_str":   _fmt_kst_hm(getattr(s, "closes_at", None) or getattr(s, "end_at", None)),
            "checked_at_str": _fmt_kst_hm(marked),
            "status": code,  # present/late/absent/pending
        })

    total = len(sessions)
    rate = int(round(((cnt_present + cnt_late) / total) * 100)) if total else 0

    return {
        "summary": {
            "total": total,
            "present": cnt_present,
            "late": cnt_late,
            "absent": cnt_absent,
            "rate": rate,
        },
        "rows": rows,
    }
# ------ END ADD ------

# ─────────────────────────────────────────────────────────────
# 교수: 출석 세션 시작 (기본 10분)
# ─────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/start", endpoint="start")
@login_required
def start(course_id: int):
    course = ensure_course_owner_or_403(course_id)

    minutes = int(request.json.get("minutes", 10))
    now = _now_utc()

    # 영문 소문자 6자, 중복 방지
    code = _gen_code(6)
    while db.session.query(AttendanceSession.id).filter_by(session_code=code).first():
        code = _gen_code(6)
    sess = AttendanceSession(
        course_id=course.id,
        created_by=g.user.id,
        session_code=code,
        opens_at=now,
        closes_at=now + timedelta(minutes=minutes),
        is_open=True,
        allow_student_self_tag=True,
    )
    db.session.add(sess)
    db.session.commit()

    qr_png = url_for("attendance.qr_png", code=code)  # QR 이미지 URL

    return jsonify({
        "status": "ok",
        "session_id": sess.id,
        "session_code": code,
        "qr_png": qr_png,
        "is_open": True,
        "expires_at": sess.closes_at.isoformat(),
        "expires_ts": int(sess.closes_at.replace(tzinfo=UTC).timestamp()),
    })

@bp.post("/<int:course_id>/session/<int:session_id>/extend", endpoint="extend")
@login_required
def extend(course_id: int, session_id: int):
    """세션 종료시간을 10분 연장 (닫힌 세션이면 400)"""
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    now = _now_utc()
    if not sess.is_open or (sess.closes_at and now > sess.closes_at):
        return jsonify({"status": "error", "message": "session closed"}), 400

    # 기준: 현재 closes_at이 now 이전이면 now부터 다시 10분, 아니면 기존 closes_at + 10분
    base = max(sess.closes_at or now, now)
    sess.closes_at = base + timedelta(minutes=10)
    db.session.commit()

    return jsonify({
        "status": "ok",
        "closes_at": sess.closes_at.isoformat(),
        "expires_ts": int(sess.closes_at.replace(tzinfo=UTC).timestamp()),
    })

# ─────────────────────────────────────────────────────────────
# QR 이미지 생성
# ─────────────────────────────────────────────────────────────
@bp.get("/qr/<code>.png", endpoint="qr_png")
def qr_png(code: str):
    url = url_for("attendance.session_landing", code=code, _external=True)

    # qrcode 모듈이 없을 때의 폴백
    if qrcode is None:
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (560, 560), (255, 255, 255))
            d = ImageDraw.Draw(img)
            d.text((16, 16), "Install qrcode[pil]\n" + url, fill=(0, 0, 0))
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            buf.seek(0)
            return send_file(buf, mimetype="image/png")
        except Exception:
            return ("QR library missing", 200, {"Content-Type": "text/plain"})

    # ✅ qrcode 전역 모듈을 직접 사용 (로컬에서 다시 import 하지 않음)
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,  # 인식률 향상
        box_size=10,   # 박스 크기 키워서 더 큼직하게
        border=2       # 흰 여백(quiet zone)
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")
# ─────────────────────────────────────────────────────────────
# 학생: QR로 들어오는 랜딩 페이지
# ─────────────────────────────────────────────────────────────
@bp.get("/s/<code>", endpoint="session_landing")
@login_required
def session_landing(code: str):
    sess = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.session_code == code)
        .first()
    ) or abort(404)
    now = _now_utc()
    expired = (not sess.is_open) or (now > sess.closes_at)
    return render_template("attendance_landing.html", sess=sess, expired=expired)


# ─────────────────────────────────────────────────────────────
# 학생: 출석 버튼 → 기록
# ─────────────────────────────────────────────────────────────
@bp.post("/checkin", endpoint="checkin")
@login_required
def checkin():
    code = (request.json.get("code") or "").strip()
    sess = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.session_code == code)
        .first()
    ) or abort(404)

    now = _now_utc()
    # 세션 상태/만료 확인
    if (not _is_session_open(sess)):
        return jsonify({"status": "closed"}), 410

    # 수강 여부 확인
    enrolled = (
        db.session.query(Enrollment.id)
        .filter_by(course_id=sess.course_id, user_id=g.user.id)
        .first()
    )
    if not enrolled:
        return jsonify({"status": "forbidden", "message": "수강 중이 아닙니다."}), 403

    # 이미 체크인되어 있으면 그대로 OK
    exist = (
        db.session.query(AttendanceRecord.id)
        .filter_by(session_id=sess.id, student_id=g.user.id)
        .first()
    )
    if exist:
        return jsonify({"status": "ok", "message": "이미 체크인됨"})

    # ✅ 지각 규칙 반영
    status = _status_by_time(sess, now)  # 'present' or 'late'

    try:
        db.session.add(AttendanceRecord(
            session_id=sess.id,
            student_id=g.user.id,
            status=status,
            source="auto",
            marked_at=now
        ))
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        # 동시성으로 unique 충돌시에도 OK로 응답
        return jsonify({"status": "ok", "message": "이미 체크인됨"})

    return jsonify({"status": "ok", "marked": status})


# ─────────────────────────────────────────────────────────────
# 교수: 세션 종료
# ─────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/session/<int:session_id>/close", endpoint="close")
@login_required
def close(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    now = _now_utc()
    sess.is_open = False
    sess.closes_at = now

    db.session.commit()
    return jsonify({"status": "ok", "closed_at": sess.closes_at.isoformat()})


# ─────────────────────────────────────────────────────────────
# 교수: 실시간 통계(출석/미출석 목록)
# ─────────────────────────────────────────────────────────────
@bp.get("/<int:course_id>/session/<int:session_id>/stats", endpoint="stats")
@login_required
def stats(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    # 출석한 학생
    pres = (
        db.session.query(AttendanceRecord, User)
        .join(User, AttendanceRecord.student_id == User.id)
        .filter(AttendanceRecord.session_id == sess.id)
        .order_by(AttendanceRecord.marked_at.asc())
        .all()
    )
    present = [
        {"id": u.id, "name": u.name, "email": u.email, "status": r.status}
        for r, u in pres
    ]
    present_ids = {u["id"] for u in present}

    # 전체 수강생
    roster = (
        db.session.query(User)
        .join(Enrollment, Enrollment.user_id == User.id)
        .filter(Enrollment.course_id == course.id)
        .order_by(User.name.asc())
        .all()
    )
    absent = [
        {"id": u.id, "name": u.name, "email": u.email}
        for u in roster
        if u.id not in present_ids
    ]

    now = _now_utc()
    still_open = bool(sess.is_open and (not sess.closes_at or now <= sess.closes_at))

    return jsonify({
        "status": "ok",
        "is_open": still_open,
        "session_code": sess.session_code,
        "opens_at": _to_kst(sess.opens_at),
        "closes_at": _to_kst(sess.closes_at),
        "present_count": len(present),
        "absent_count": len(absent),
        "present": present,
        "absent": absent,
        "expires_ts": int(sess.closes_at.replace(tzinfo=UTC).timestamp()) if sess.closes_at else None,
    })

@bp.get("/<int:course_id>/sessions", endpoint="sessions_list")
@login_required
def sessions_list(course_id: int):
    course = ensure_course_owner_or_403(course_id)

    limit = int(request.args.get("limit", 50))
    sessions = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.course_id == course.id)
        .order_by(AttendanceSession.opens_at.desc())
        .limit(limit)
        .all()
    )

    # 출석 수 집계 (필요 시 성능 최적화 가능)
    # 간단히 per-session count 쿼리로 구현
    def present_count_for(sid: int) -> int:
        return (
            db.session.query(func.count(AttendanceRecord.id))
            .filter(AttendanceRecord.session_id == sid)
            .scalar()
        ) or 0

    payload = []
    for s in sessions:
        payload.append({
            "id": s.id,
            "session_code": s.session_code,
            "opens_at": s.opens_at.isoformat() + "Z",
            # ✅ 목록에 표시할 종료 시각은 DB 의 closes_at (종료 버튼 클릭 시각)
            "closes_at": s.closes_at.isoformat() + "Z" if s.closes_at else None,
            "is_open": bool(s.is_open and (_now_utc() <= s.closes_at if s.closes_at else True)),
            "present_count": present_count_for(s.id),
        })

    return jsonify({"status": "ok", "sessions": payload})

@bp.delete("/<int:course_id>/session/<int:session_id>", endpoint="delete_session")
@login_required
def delete_session(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    # 출석 레코드 먼저 삭제 → 세션 삭제
    db.session.execute(
        delete(AttendanceRecord).where(AttendanceRecord.session_id == sess.id)
    )
    db.session.delete(sess)
    db.session.commit()
    return jsonify({"status": "ok", "deleted_session_id": session_id})

# ─────────────────────────────────────────────────────────────
# 교수: 특정 세션의 특정 학생 출석 상태 수정 (present / absent / late)
# ─────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/session/<int:session_id>/mark", endpoint="mark")
@login_required
def mark(course_id: int, session_id: int):
    course = ensure_course_owner_or_403(course_id)
    sess = db.session.get(AttendanceSession, session_id) or abort(404)
    if sess.course_id != course.id:
        abort(404)

    try:
        student_id = int(request.json.get("student_id"))
    except Exception:
        return jsonify({"status": "error", "message": "invalid student"}), 400

    # 프론트 호환: status 또는 to_status 허용
    to_status = (request.json.get("status") or request.json.get("to_status") or "").strip()
    if to_status not in ("present", "absent"):
        return jsonify({"status": "error", "message": "invalid status"}), 400

    rec = (
        db.session.query(AttendanceRecord)
        .filter_by(session_id=sess.id, student_id=student_id)
        .first()
    )

    now = _now_utc()

    if to_status == "present":
        if rec:
            rec.status = "present"
            rec.source = "manual"
            rec.marked_at = now
        else:
            db.session.add(AttendanceRecord(
                session_id=sess.id,
                student_id=student_id,
                status="present",
                source="manual",
                marked_at=now
            ))
    else:  # to_status == "absent"  -> 레코드 삭제(=미출석)
        if rec:
            db.session.delete(rec)

    db.session.commit()
    return jsonify({"status": "ok", "student_id": student_id, "changed": to_status})


# 학생: QR 스캔 화면
@bp.get("/scan/<int:course_id>", endpoint="scan")
@login_required
def scan(course_id: int):
    course = db.session.get(Course, course_id) or abort(404)

    # 수강생 또는 교수/관리자만 접근 가능
    enrolled = (
        db.session.query(Enrollment.id)
        .filter_by(course_id=course.id, user_id=g.user.id)
        .first()
    )
    if not enrolled and not is_course_owner_or_admin(course, g.user):
        abort(403)

    return render_template("attendance_scan.html", course=course)

# 학생: 내 출석 히스토리(JSON)
@bp.get("/<int:course_id>/my", endpoint="my_history")
@login_required
def my_history(course_id: int):
    course = db.session.get(Course, course_id) or abort(404)

    # 수강생 또는 교수/관리자만 조회 가능
    enrolled = (
        db.session.query(Enrollment.id)
        .filter_by(course_id=course.id, user_id=g.user.id)
        .first()
    )
    if not enrolled and not is_course_owner_or_admin(course, g.user):
        abort(403)

    sessions = (
        db.session.query(AttendanceSession)
        .filter(AttendanceSession.course_id == course.id)
        .order_by(AttendanceSession.opens_at.desc())
        .all()
    )
    sid_list = [s.id for s in sessions]

    recs = []
    if sid_list:
        recs = (
            db.session.query(AttendanceRecord)
            .filter(
                AttendanceRecord.student_id == g.user.id,
                AttendanceRecord.session_id.in_(sid_list),
            )
            .all()
        )
    rec_map = {r.session_id: r for r in recs}

    now = _now_utc()
    rows = []
    cnt_present = cnt_late = cnt_absent = 0

    for s in sessions:
        r = rec_map.get(s.id)

        # 상태 계산
        if r:
            st = (r.status or "").lower()
            if st == "late":
                code, label = "late", "지각"
                cnt_late += 1
            else:
                code, label = "present", "출석"
                cnt_present += 1
            marked = r.marked_at
        else:
            still_open = bool(s.is_open and (not s.closes_at or now <= s.closes_at))
            if still_open:
                code, label = "pending", "대기"
                marked = None
            else:
                code, label = "absent", "결석"
                cnt_absent += 1
                marked = None

        # 화면용 문자열들(KST, 공백 포맷)
        start_at_str = _fmt_kst_hm(getattr(s, "opens_at", None) or getattr(s, "start_at", None))
        end_at_str   = _fmt_kst_hm(getattr(s, "closes_at", None) or getattr(s, "end_at", None))
        checked_at_str = _fmt_kst_hm(marked)

        rows.append({
            "session_id": s.id,
            "session_code": s.session_code,     # ✅ 교수 세션 코드
            "start_at_str": start_at_str,       # ✅ 제목에 사용할 시작~종료
            "end_at_str": end_at_str,
            "checked_at_str": checked_at_str,   # ✅ 부제 보조 정보
            "status": code,                     # present/late/absent/pending
            "status_label": label,
            # 참고: 원본 값이 필요하면 아래도 유지 가능
            "opens_at": _to_kst(getattr(s, "opens_at", None) or getattr(s, "start_at", None)),
            "closes_at": _to_kst(getattr(s, "closes_at", None) or getattr(s, "end_at", None)),
        })

    total = len(sessions)
    rate = int(round(((cnt_present + cnt_late) / total) * 100)) if total else 0

    return jsonify({
        "status": "ok",
        "summary": {
            "total": total,
            "present": cnt_present,
            "late": cnt_late,
            "absent": cnt_absent,
            "rate": rate,
        },
        "rows": rows,
    })