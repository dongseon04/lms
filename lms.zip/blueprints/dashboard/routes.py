# blueprints/dashboard/routes.py — 학생 대시보드(임시 공용)
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from flask import Blueprint, render_template
from sqlalchemy import func, and_, or_
from extensions import db
from models import Course, Enrollment, Assignment, Submission, Material  # Material 사용
from helpers.auth import login_required, _session_uid
from services.metrics import (
    assignment_progress_for_user,
    average_score_for_user,
    recent_activities_for_user,
)

bp = Blueprint("dashboard", __name__)

# 한국 표준시
KST = timezone(timedelta(hours=9))

@bp.get("/", endpoint="home")  # ✅ 엔드포인트: dashboard.home (루트는 항상 "/")
@login_required
def dashboard():
    uid = _session_uid() or 1

    # 상단 카드 메트릭
    course_count = db.session.query(Enrollment).filter_by(user_id=uid).count()
    progress_pct, submitted_cnt, total_cnt = assignment_progress_for_user(uid)
    avg_score = average_score_for_user(uid)

    # 내가 수강 중인 코스 목록
    courses = db.session.execute(
        db.select(Course.id, Course.title)
        .join(Enrollment, Enrollment.course_id == Course.id)
        .where(Enrollment.user_id == uid)
    ).all()
    course_ids = [cid for cid, _ in courses]
    course_title_map = {cid: title for cid, title in courses}

    # 코스별 과제 총수
    total_by_course = {}
    if course_ids:
        total_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Assignment.course_id, func.count(Assignment.id))
                .where(Assignment.course_id.in_(course_ids))
                .group_by(Assignment.course_id)
            ).all()
        }

    # 코스별 내가 제출한 과제 수(제출 완료 기준)
    submitted_by_course = {}
    if course_ids:
        submitted_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Assignment.course_id, func.count(Submission.id))
                .join(Assignment, Assignment.id == Submission.assignment_id)
                .where(
                    Assignment.course_id.in_(course_ids),
                    Submission.user_id == uid,
                    Submission.submitted_at.isnot(None),
                )
                .group_by(Assignment.course_id)
            ).all()
        }

    # 진행률 바 데이터
    bars = []
    for cid, title in courses:
        total_c = int(total_by_course.get(cid, 0))
        submitted_c = int(submitted_by_course.get(cid, 0))
        pct = int((submitted_c / total_c) * 100) if total_c else 0
        bars.append({"course": {"id": cid, "title": title}, "pct": pct})

    # -----------------------------
    # 📅 캘린더에 뿌릴 이벤트 구성
    # -----------------------------
    # 달력은 클라이언트에서 월을 넘기지만, 서버는 "최근 2주 ~ 앞으로 60일" 구간을 넉넉하게 전달
    now = datetime.now(tz=KST)
    start_window = now - timedelta(days=14)
    end_window = now + timedelta(days=60)

    events: list[dict] = []

    if course_ids:
        # 1) 과제 마감 이벤트
        # - due_at 있는 과제만 대상
        # - 내가 제출했는지(제출 완료) 여부를 붙여서 표기
        A = Assignment
        S = Submission
        q_assign = (
            db.session.query(
                A.id.label("aid"),
                A.title.label("atitle"),
                A.course_id.label("cid"),
                A.due_at.label("due_at"),
                func.max(
                    func.ifnull(
                        func.if_(and_(S.user_id == uid, S.submitted_at.isnot(None)), 1, 0), 0
                    )
                ).label("is_submitted"),
            )
            .outerjoin(S, S.assignment_id == A.id)
            .filter(
                A.course_id.in_(course_ids),
                A.due_at.isnot(None),
                A.due_at >= start_window,
                A.due_at <= end_window,
            )
            .group_by(A.id, A.title, A.course_id, A.due_at)
            .order_by(A.due_at.asc())
        )

        for row in q_assign.all():
            cid = int(row.cid)
            due = row.due_at
            submitted = bool(row.is_submitted)
            course_title = course_title_map.get(cid, "코스")
            # 안전한 코스 상세 URL (탭 고정)
            link = f"/course/{cid}?tab=assignments"
            title = f"[마감] {row.atitle}"
            if submitted:
                title += " (제출 완료)"
            events.append({
                "id": f"assg-{row.aid}",
                "kind": "assignment",   # 클라이언트에서 chip 스타일링용
                "title": title,
                "start": due.astimezone(KST).isoformat(),
                "end": None,
                "course": course_title,
                "location": "",         # 필요 시 강의실/온라인 링크 등
                "url": link,
            })

        # 2) 시청할 강좌/강의자료 이벤트
        # Material에 스케줄 필드가 정해지지 않았다면,
        # - publish_at/available_at 중 있는 값 우선
        # - 없으면 created_at로 대체해 "업로드됨/시청" 이벤트로 사용
        M = Material
        # 컬럼 존재 가능성 고려: getattr로 안전 접근
        publish_col = getattr(M, "publish_at", None)
        avail_col = getattr(M, "available_at", None)
        created_col = getattr(M, "created_at", None)
        # 시작시각 후보 컬럼을 coalesce
        start_expr = None
        if publish_col is not None and avail_col is not None:
            start_expr = func.coalesce(publish_col, avail_col, created_col)
        elif publish_col is not None:
            start_expr = func.coalesce(publish_col, created_col)
        elif avail_col is not None:
            start_expr = func.coalesce(avail_col, created_col)
        else:
            start_expr = created_col  # 최후 fallback

        if start_expr is not None:
            q_mat = (
                db.session.query(
                    M.id.label("mid"),
                    M.title.label("mtitle"),
                    M.course_id.label("cid"),
                    start_expr.label("start_at"),
                )
                .filter(
                    M.course_id.in_(course_ids),
                    start_expr.isnot(None),
                    start_expr >= start_window,
                    start_expr <= end_window,
                )
                .order_by(start_expr.asc())
            )

            for row in q_mat.all():
                cid = int(row.cid)
                st = row.start_at
                course_title = course_title_map.get(cid, "코스")
                link = f"/course/{cid}?tab=materials"
                events.append({
                    "id": f"mat-{row.mid}",
                    "kind": "material",
                    "title": f"[시청] {row.mtitle}",
                    "start": st.astimezone(KST).isoformat(),
                    "end": None,
                    "course": course_title,
                    "location": "",
                    "url": link,
                })

    # 예정/최근 활동
    upcoming = []  # TODO: 필요 시 구현
    recent = recent_activities_for_user(uid, limit=5)

    return render_template(
        # 템플릿 파일명이 student.html이라면 여기와 맞추세요
        "dashboard.html",
        course_count=course_count,
        progress_pct=progress_pct,
        submitted_cnt=submitted_cnt,
        total_cnt=total_cnt,
        avg_score=avg_score,
        bars=bars,
        upcoming=upcoming,
        recent=recent,
        events=events,  # ✅ 달력에 내려줄 데이터
    )