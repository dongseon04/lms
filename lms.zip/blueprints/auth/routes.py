# blueprints/auth/routes.py — 로그인/로그아웃/데모계정/회원가입 (최종)
from __future__ import annotations
from datetime import datetime, timezone
import os, secrets, re

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db
from models import User, AttendanceSession
from helpers.auth import _login, _logout

from flask import current_app
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

bp = Blueprint("auth", __name__)

# ─────────────────────────────────────────────────────────────────────────────
# 초대 코드: 환경변수 우선, 없으면 서버 부팅 시 1회 임의 생성
# ─────────────────────────────────────────────────────────────────────────────
PROF_INVITE_CODE = os.environ.get("PROF_INVITE_CODE") or "137413"

# ─────────────────────────────────────────────────────────────────────────────
# 내부 유틸: 역할별 기본 홈, 안전한 next 계산
# ─────────────────────────────────────────────────────────────────────────────
def _role_home(user: User) -> str:
    role = (getattr(user, "role", "") or "").strip().lower()
    if role in {"admin", "administrator"}:
        return url_for("courses.admin_list")
    if role in {"instructor", "professor", "prof", "teacher", "교수"}:
        return url_for("courses.home")
    return url_for("dashboard.home")

def _safe_next(nxt: str | None, fallback: str) -> str:
    if not nxt:
        return fallback
    if nxt.startswith("//"):
        return fallback
    if not nxt.startswith("/"):
        return fallback
    return nxt

# --- 유틸: 토큰/전화번호/마스킹 ---
def _serializer() -> URLSafeTimedSerializer:
    # 비밀번호 재설정 토큰용
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="pw-reset")

def _normalize_phone(s: str) -> str:
    return re.sub(r"[^0-9]", "", (s or "").strip())

def _mask_email(email: str) -> str:
    local, _, domain = (email or "").partition("@")
    if not domain:
        return email
    visible = min(2, len(local))
    return local[:visible] + ("*" * max(len(local) - visible, 1)) + "@" + domain


# ─────────────────────────────────────────────────────────────────────────────
# 로그인 페이지
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/login", endpoint="home")  # 엔드포인트: auth.home
def login():
    uid = session.get("uid")
    if uid:
        user = db.session.get(User, uid)
        if user:
            return redirect(_role_home(user))
    return render_template("auth_login.html")

# ★ NEW: 출석 세션 강제 종료 유틸
def _now_utc_naive():
    return datetime.now(timezone.utc).replace(tzinfo=None)

def close_open_attendance_sessions_for_user(user_id: int) -> int:
    """
    해당 사용자가 연 '열려있는' 출석 세션을 모두 종료.
    closes_at을 현재로 덮어쓰고 is_open=False 로 만든다.
    반환값: 종료한 세션 수
    """
    now = _now_utc_naive()
    rows = (
        db.session.query(AttendanceSession)
        .filter(
            AttendanceSession.created_by == user_id,
            AttendanceSession.is_open.is_(True),
            or_(AttendanceSession.closes_at.is_(None), AttendanceSession.closes_at > now),
        )
        .all()
    )
    for s in rows:
        s.is_open = False
        s.closes_at = now
    if rows:
        db.session.commit()
    return len(rows)

# ─────────────────────────────────────────────────────────────────────────────
# 로그인 처리
# ─────────────────────────────────────────────────────────────────────────────
def _is_active(user: User) -> bool:
    return bool(getattr(user, "is_active", True))

@bp.post("/login", endpoint="login_post")
def login_post():
    email = (request.form.get("email") or "").strip().lower()
    password = (request.form.get("password") or "").strip()

    user = db.session.query(User).filter(func.lower(User.email) == email).first()
    if not user:
        flash("이메일 또는 비밀번호가 올바르지 않습니다.", "error")
        return redirect(url_for("auth.home"))

    if not _is_active(user):
        flash("계정이 비활성화되었습니다. 문의처에 문의하세요.", "error")
        return redirect(url_for("auth.home"))

    ok = False
    if hasattr(user, "password_hash") and user.password_hash:
        ok = check_password_hash(user.password_hash, password)
    elif hasattr(user, "password"):
        ok = (user.password == password)

    if not ok:
        flash("이메일 또는 비밀번호가 올바르지 않습니다.", "error")
        return redirect(url_for("auth.home"))

    _login(user.id)

    default_after_login = _role_home(user)
    nxt = _safe_next(request.args.get("next"), fallback=default_after_login)
    return redirect(nxt)

# ─────────────────────────────────────────────────────────────────────────────
# 로그아웃: GET/POST 분리
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/logout", endpoint="logout_get")
def logout_get():
    # ★ NEW: _logout() 전에 교수님이 열어둔 출석 세션 강제 종료
    uid = session.get("uid")
    if uid is not None:
        try:
            close_open_attendance_sessions_for_user(uid)
        except Exception:
            db.session.rollback()
    _logout()
    flash("로그아웃되었습니다.", "success")
    return redirect(url_for("auth.home"))

@bp.post("/logout", endpoint="logout_post")
def logout_post():
    # ★ NEW: _logout() 전에 교수님이 열어둔 출석 세션 강제 종료
    uid = session.get("uid")
    if uid is not None:
        try:
            close_open_attendance_sessions_for_user(uid)
        except Exception:
            db.session.rollback()
    _logout()
    flash("로그아웃되었습니다.", "success")
    return redirect(url_for("auth.home"))

# ─────────────────────────────────────────────────────────────────────────────
# 데모 계정 초기화
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/init_demo", endpoint="init_demo")
def init_demo():
    """관리자/교수/학생 3계정 자동 생성 (이미 있으면 건너뜀)"""
    created = []
    demo_users = [
        ("관리자", "admin@example.com", "admin", "admin123"),
        ("김교수", "prof@example.com", "instructor", "prof123"),
        ("홍학생", "student@example.com", "student", "student123"),
    ]
    for name, email, role, pw in demo_users:
        u = db.session.query(User).filter(func.lower(User.email) == email.lower()).first()
        if not u:
            u = User(
                name=name,
                email=email,
                role=role,
                username=email.split("@")[0],
                created_at=datetime.utcnow(),
            )
            if hasattr(User, "password_hash"):
                u.password_hash = generate_password_hash(pw)
            elif hasattr(User, "password"):
                u.password = pw
            db.session.add(u)
            created.append(email)
    if created:
        db.session.commit()

    flash(f"데모 계정 준비 완료: {', '.join(created) if created else '이미 존재함'}", "success")
    return redirect(url_for("auth.home"))

# ─────────────────────────────────────────────────────────────────────────────
# 회원가입: GET/POST
# ─────────────────────────────────────────────────────────────────────────────
def _validate_password(pw: str) -> tuple[bool, str | None]:
    if len(pw) < 8:
        return False, "비밀번호는 최소 8자 이상이어야 합니다."
    kinds = 0
    kinds += 1 if re.search(r"[A-Z]", pw) else 0
    kinds += 1 if re.search(r"[0-9]", pw) else 0
    kinds += 1 if re.search(r"[^A-Za-z0-9]", pw) else 0
    if kinds < 2:
        return False, "대문자/숫자/특수문자 중 2가지 이상을 포함하세요."
    return True, None

def _verify_prof_invite(code: str | None) -> bool:
    # 동적으로 유지되는 초대 코드와 일치해야 함
    return bool(code and code.strip() == PROF_INVITE_CODE)

def _normalize_role(role: str) -> str:
    r = (role or "").strip().lower()
    if r in {"prof", "professor", "instructor", "teacher", "교수"}:
        return "instructor"
    if r in {"admin", "administrator"}:
        return "admin"
    return "student"

@bp.get("/register", endpoint="register")
def register():
    # 이미 로그인 상태면 역할별 홈으로
    uid = session.get("uid")
    if uid:
        user = db.session.get(User, uid)
        if user:
            return redirect(_role_home(user))
    # 현재 초대 코드 템플릿에 표시(개발 용). 배포 전 제거 권장.
    return render_template("auth_register.html")

@bp.post("/register", endpoint="register_post")
def register_post():
    name = (request.form.get("name") or "").strip()
    email = (request.form.get("email") or "").strip().lower()
    phone_raw = (request.form.get("phone") or "").strip()
    # 숫자만 남기기: 화면에서는 하이픈 자동 표시하지만 서버에서는 숫자만 저장
    phone_digits = re.sub(r"[^0-9]", "", phone_raw)

    pw1 = request.form.get("password") or ""
    pw2 = request.form.get("password2") or ""
    role_raw = (request.form.get("role") or "student")
    invite_code = (request.form.get("invite_code") or "").strip()
    agree = request.form.get("agree")
    nxt = request.args.get("next")

    # 기본 검증
    if not name:
        flash("이름을 입력하세요.", "error"); return redirect(url_for("auth.register", next=nxt))
    if not email:
        flash("이메일을 입력하세요.", "error"); return redirect(url_for("auth.register", next=nxt))
    if not phone_digits:
        flash("전화번호를 입력하세요.", "error"); return redirect(url_for("auth.register", next=nxt))
    # 한국형 휴대전화 기본 길이(10~11자리) 체크
    if len(phone_digits) < 10 or len(phone_digits) > 11:
        flash("전화번호 형식이 올바르지 않습니다. 숫자 10~11자리로 입력하세요.", "error")
        return redirect(url_for("auth.register", next=nxt))

    if pw1 != pw2:
        flash("비밀번호가 일치하지 않습니다.", "error"); return redirect(url_for("auth.register", next=nxt))
    ok, msg = _validate_password(pw1)
    if not ok:
        flash(msg, "error"); return redirect(url_for("auth.register", next=nxt))
    if agree != "1":
        flash("이용약관 및 개인정보 처리방침에 동의해야 합니다.", "error")
        return redirect(url_for("auth.register", next=nxt))

    role = _normalize_role(role_raw)
    if role == "admin":
        flash("관리자 계정은 초대로만 생성할 수 있습니다.", "error")
        return redirect(url_for("auth.register", next=nxt))
    if role == "instructor" and not _verify_prof_invite(invite_code):
        flash("유효한 교수 초대 코드가 필요합니다.", "error")
        return redirect(url_for("auth.register", next=nxt))

    # 이메일 중복
    if db.session.query(User.id).filter(func.lower(User.email) == email).first():
        flash("이미 사용 중인 이메일입니다.", "error")
        return redirect(url_for("auth.register", next=nxt))

    # 사용자 생성 (전화번호는 숫자만 저장)
    user = User(
        name=name,
        email=email,
        phone=phone_digits,  # ✅ 숫자만 저장
        role=role,
        username=email.split("@")[0],
        created_at=datetime.utcnow(),
    )
    if hasattr(User, "password_hash"):
        user.password_hash = generate_password_hash(pw1)
    elif hasattr(User, "password"):
        user.password = pw1

    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        flash("이미 사용 중인 이메일입니다.", "error")
        return redirect(url_for("auth.register", next=nxt))

    _login(user.id)
    flash("환영합니다! 회원가입이 완료되었습니다.", "success")
    default_after = _role_home(user)
    return redirect(_safe_next(nxt, fallback=default_after))

# ─────────────────────────────────────────────────────────────────────────────
# 이메일 찾기
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/find_email", endpoint="find_email")
def find_email():
    return render_template("auth_find_email.html")

@bp.post("/find_email", endpoint="find_email_post")
def find_email_post():
    name  = (request.form.get("name") or "").strip()
    phone = _normalize_phone(request.form.get("phone") or "")

    if not phone:
        flash("전화번호를 입력하세요.", "error")
        return redirect(url_for("auth.find_email"))

    q = db.session.query(User).filter(User.phone == phone)
    if name:
        q = q.filter(func.lower(User.name) == func.lower(name))
    users = q.all()

    if not users:
        flash("입력하신 정보와 일치하는 계정이 없습니다.", "error")
        return redirect(url_for("auth.find_email"))

    masked = [_mask_email(u.email) for u in users]
    # 결과 페이지 렌더
    return render_template("auth_find_email.html", results=masked)

# ─────────────────────────────────────────────────────────────────────────────
# 비밀번호 찾기(재설정 링크 발급 후 바로 이동)  ★여기 변경
# ─────────────────────────────────────────────────────────────────────────────
@bp.post("/forgot", endpoint="forgot_password_post")
def forgot_password_post():
    email = (request.form.get("email") or "").strip().lower()
    phone = _normalize_phone(request.form.get("phone") or "")

    if not email or not phone:
        flash("이메일과 전화번호를 모두 입력하세요.", "error")
        return redirect(url_for("auth.forgot_password"))

    user = db.session.query(User).filter(
        func.lower(User.email) == email,
        User.phone == phone
    ).first()

    if not user:
        flash("입력하신 정보와 일치하는 계정이 없습니다.", "error")
        return redirect(url_for("auth.forgot_password"))

    # 토큰 생성 후 곧장 재설정 페이지로 이동
    s = _serializer()
    token = s.dumps({"uid": user.id})
    return redirect(url_for("auth.reset_password", token=token))

# ─────────────────────────────────────────────────────────────────────────────
# 비밀번호 재설정 폼 (토큰 사전 검증) ★여기 살짝 보강
# ─────────────────────────────────────────────────────────────────────────────
@bp.get("/reset/<token>", endpoint="reset_password")
def reset_password(token):
    # GET 단계에서 토큰 유효성 간단 체크(만료/위조 시 안내)
    s = _serializer()
    try:
        s.loads(token, max_age=3600)  # 1시간 유효
    except SignatureExpired:
        flash("재설정 링크의 유효기간이 만료되었습니다. 다시 요청하세요.", "error")
        return redirect(url_for("auth.forgot_password"))
    except BadSignature:
        flash("재설정 링크가 올바르지 않습니다.", "error")
        return redirect(url_for("auth.forgot_password"))

    return render_template("auth_reset_password.html", token=token)