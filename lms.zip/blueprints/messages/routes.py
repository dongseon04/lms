# routes.py (messages blueprint)
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, g
from sqlalchemy import or_, func
from datetime import datetime
from helpers.auth import login_required
from models import db, User, Message

bp = Blueprint("messages", __name__, url_prefix="/messages")


@bp.get("/", endpoint="home")
@login_required
def page():
    uid = g.user.id
    role = (getattr(g.user, "role", "") or "").strip().lower()
    tab = (request.args.get("tab") or "inbox").strip().lower()
    if tab not in {"inbox", "sent", "compose"}:
        tab = "inbox"

    q_raw = (request.args.get("q") or "").strip()
    q = q_raw.lower()

    # 받은편지함
    base_inbox = (
        db.session.query(Message)
        .filter(
            Message.receiver_id == uid,
            Message.receiver_deleted.is_(False)
        )
    )

    # 보낸편지함
    base_sent = (
        db.session.query(Message)
        .filter(
            Message.sender_id == uid,
            Message.sender_deleted.is_(False)
        )
    )

    if q:
        like = f"%{q}%"
        base_inbox = (
            base_inbox.join(User, Message.sender_id == User.id)
            .filter(
                or_(
                    func.lower(Message.title).like(like),
                    func.lower(Message.body).like(like),
                    func.lower(User.name).like(like),
                )
            )
        )
        base_sent = (
            base_sent.join(User, Message.receiver_id == User.id)
            .filter(
                or_(
                    func.lower(Message.title).like(like),
                    func.lower(Message.body).like(like),
                    func.lower(User.name).like(like),
                )
            )
        )

    inbox = base_inbox.order_by(
        Message.read_at.is_(None).desc(),
        Message.created_at.desc()
    ).all()
    sent = base_sent.order_by(Message.created_at.desc()).all()

    # 🎯 선택 목록
    users = []
    students = []
    if role in {"instructor", "admin"}:
        # 교수/관리자: 학생 목록
        students = (
            db.session.query(User)
            .filter(User.id != uid, User.role.in_(["student"]))
            .order_by(User.name.asc())
            .all()
        )
    else:
        # 학생: 교수만
        users = (
            db.session.query(User)
            .filter(User.id != uid, User.role.in_(["instructor"]))
            .order_by(User.name.asc())
            .all()
        )

    unread_cnt = db.session.scalar(
        db.select(func.count(Message.id)).where(
            Message.receiver_id == uid,
            Message.receiver_deleted.is_(False),
            Message.read_at.is_(None),
        )
    ) or 0

    return render_template(
        "messages.html",
        tab=tab,
        q=q_raw,
        inbox=inbox,
        sent=sent,
        users=users,          # 학생에게만 의미
        students=students,    # 교수/관리자에게만 의미
        unread_cnt=unread_cnt,
    )


@bp.get("/<int:msg_id>", endpoint="detail")
@login_required
def detail(msg_id: int):
    uid = g.user.id
    m = db.session.get(Message, msg_id)
    if not m or (m.sender_id != uid and m.receiver_id != uid):
        abort(404)

    # 내가 삭제한 쪽에서는 상세 접근 불가
    if (m.sender_id == uid and m.sender_deleted) or (m.receiver_id == uid and m.receiver_deleted):
        abort(404)

    # 받은 사람이 열면 읽음 처리
    if m.receiver_id == uid and m.read_at is None:
        m.read_at = datetime.utcnow()
        db.session.commit()

    back_tab = "sent" if m.sender_id == uid else "inbox"
    return render_template("message_detail.html", m=m, back_tab=back_tab, is_sender=(m.sender_id == uid))


@bp.post("/send", endpoint="send")
@login_required
def send():
    uid = g.user.id
    role = (getattr(g.user, "role", "") or "").strip().lower()

    title = (request.form.get("title") or "").strip()
    body = (request.form.get("body") or "").strip()

    # 공통: 제목 필수
    if not title:
        flash("제목은 필수입니다.", "error")
        return redirect(url_for("messages.home", tab="compose"))

    # ----------------------------------------------------------------------------
    # 교수/관리자: 다중/전체 전송
    # ----------------------------------------------------------------------------
    if role in {"instructor", "admin"}:
        to_all = (request.form.get("to_all") == "1")
        to_ids = request.form.getlist("to_ids")  # ['3','5',...]

        # 수신자 집합 구성
        recipients_query = db.session.query(User).filter(User.id != uid, User.role == "student")
        recipients = []

        if to_all:
            recipients = recipients_query.all()
            if not recipients:
                flash("보낼 학생이 없습니다.", "error")
                return redirect(url_for("messages.home", tab="compose"))
        else:
            # 체크박스 선택
            valid_ids = [int(x) for x in to_ids if x.isdigit()]
            if not valid_ids:
                flash("받는 학생을 선택하거나 '전체 학생'을 사용하세요.", "error")
                return redirect(url_for("messages.home", tab="compose"))
            recipients = recipients_query.filter(User.id.in_(valid_ids)).all()
            if not recipients:
                flash("선택한 학생을 찾을 수 없습니다.", "error")
                return redirect(url_for("messages.home", tab="compose"))

        # 자기 자신 제외 안전장치(이론상 student가 아니라서 걸릴 일은 없지만 방어)
        recipients = [u for u in recipients if u.id != uid]

        # 메시지 벌크 생성
        msgs = [Message(sender_id=uid, receiver_id=u.id, title=title, body=(body or None)) for u in recipients]
        if not msgs:
            flash("전송할 대상이 없습니다.", "error")
            return redirect(url_for("messages.home", tab="compose"))

        # 커밋 한 번에
        db.session.add_all(msgs)
        db.session.commit()

        flash(f"{len(msgs)}명의 학생에게 메시지를 보냈습니다.", "success")
        return redirect(url_for("messages.home", tab="sent"))

    # ----------------------------------------------------------------------------
    # 학생/기타: 기존 단일 전송 로직 그대로
    # ----------------------------------------------------------------------------
    to_id_raw = (request.form.get("to_id") or "").strip()
    to_email = (request.form.get("to_email") or "").strip()

    # 상호배타 검증
    if to_id_raw and to_email:
        flash("받는 사람을 드롭다운에서 선택했으면 이메일 입력 칸은 비워두세요.", "error")
        return redirect(url_for("messages.home", tab="compose"))
    if not to_id_raw and not to_email:
        flash("받는 사람을 선택하거나 이메일을 입력하세요.", "error")
        return redirect(url_for("messages.home", tab="compose"))

    # 실제 수신자 결정
    to_user = None
    if to_email:
        to_user = db.session.query(User).filter(func.lower(User.email) == to_email.lower()).first()
        if not to_user:
            flash("해당 이메일의 사용자를 찾을 수 없습니다.", "error")
            return redirect(url_for("messages.home", tab="compose"))
    else:
        if not to_id_raw.isdigit():
            flash("받는 사람 선택이 올바르지 않습니다.", "error")
            return redirect(url_for("messages.home", tab="compose"))
        to_user = db.session.get(User, int(to_id_raw))
        if not to_user or to_user.role not in ("instructor", "admin"):
            flash("받는 사람 선택이 올바르지 않습니다.", "error")
            return redirect(url_for("messages.home", tab="compose"))

    if to_user.id == uid:
        flash("자기 자신에게는 보낼 수 없습니다.", "error")
        return redirect(url_for("messages.home", tab="compose"))

    msg = Message(sender_id=uid, receiver_id=to_user.id, title=title, body=body or None)
    db.session.add(msg)
    db.session.commit()

    flash("메시지를 보냈습니다.", "success")
    return redirect(url_for("messages.home", tab="sent"))


@bp.post("/reply/<int:msg_id>", endpoint="reply")
@login_required
def reply(msg_id: int):
    uid = g.user.id
    src = db.session.get(Message, msg_id)
    if not src or (src.sender_id != uid and src.receiver_id != uid):
        abort(404)

    # 내가 삭제한 쪽에서는 원본 접근 불가
    if (src.sender_id == uid and src.sender_deleted) or (src.receiver_id == uid and src.receiver_deleted):
        abort(404)

    # 답장은 "수신자"만 가능
    if src.receiver_id != uid:
        flash("보낸 메시지에서는 답장할 수 없습니다.", "error")
        return redirect(url_for("messages.detail", msg_id=msg_id))

    # ⬇️ 서버에서도 제목 필수(공백만도 금지). 기본값 자동 채우기 제거!
    raw_title = request.form.get("title")
    title = (raw_title or "").strip()
    body = (request.form.get("body") or "").strip()

    if not title:
        flash("제목은 필수입니다.", "error")
        return redirect(url_for("messages.detail", msg_id=msg_id))

    # 수신자는 원본 발신자
    to_id = src.sender_id

    msg = Message(sender_id=uid, receiver_id=to_id, title=title, body=body or None)
    db.session.add(msg)
    db.session.commit()
    flash("답장을 보냈습니다.", "success")
    return redirect(url_for("messages.home", tab="sent"))


# 보낸 편지함에서 삭제
@bp.post("/delete/sent/<int:msg_id>", endpoint="delete_sent")
@login_required
def delete_sent(msg_id: int):
    uid = g.user.id
    m = db.session.get(Message, msg_id)
    if not m or m.sender_id != uid:
        abort(404)
    m.sender_deleted = True
    db.session.commit()
    flash("보낸 메시지를 삭제했습니다.", "success")
    return redirect(url_for("messages.home", tab="sent"))


# 받은 편지함에서 삭제
@bp.post("/delete/inbox/<int:msg_id>", endpoint="delete_inbox")
@login_required
def delete_inbox(msg_id: int):
    uid = g.user.id
    m = db.session.get(Message, msg_id)
    if not m or m.receiver_id != uid:
        abort(404)
    m.receiver_deleted = True
    db.session.commit()
    flash("받은 메시지를 삭제했습니다.", "success")
    return redirect(url_for("messages.home", tab="inbox"))