# blueprints/users/routes.py
from __future__ import annotations
from flask import Blueprint, render_template, request, redirect, url_for, flash
from sqlalchemy import func
from extensions import db
from models import User

bp = Blueprint("users", __name__, url_prefix="/users")

ADMIN_ROLES      = {"admin", "administrator", "관리자"}
INSTRUCTOR_ROLES = {"instructor", "professor", "prof", "teacher", "교수"}
STUDENT_ROLES    = {"student", "학생"}

def _norm_role(u: User | None) -> str:
    return ((getattr(u, "role", "") or "") if u else "").strip().lower()

def _role_col():
    return func.lower(func.trim(User.role))

def _is_admin(u: User) -> bool:
    return _norm_role(u) in ADMIN_ROLES

def _role_label(u: User) -> str:
    r = _norm_role(u)
    if r in INSTRUCTOR_ROLES: return "교수"
    if r in STUDENT_ROLES:    return "학생"
    if r in ADMIN_ROLES:      return "관리자"
    return (u.role or "").strip() or "미지정"

def _is_active(u: User) -> bool:
    return bool(getattr(u, "is_active", True))

@bp.get("/", endpoint="home")
def home():
    # 탭: instructor | student (전체 탭 제거)
    tab = (request.args.get("tab") or "instructor").strip().lower()
    if tab not in {"instructor", "student"}:
        tab = "instructor"

    # 학과 필터: dept=all(기본) | none(NULL) | 특정 학과명
    dept = (request.args.get("dept") or "all").strip()

    base_q = db.session.query(User).filter(_role_col().notin_(list(ADMIN_ROLES)))

    # 역할별 필터
    if tab == "instructor":
        q = base_q.filter(_role_col().in_(list(INSTRUCTOR_ROLES)))
    else:
        q = base_q.filter(_role_col().in_(list(STUDENT_ROLES)))

    # 학과별 필터
    if dept == "none":
        q = q.filter(User.department.is_(None))
    elif dept != "all":
        q = q.filter(User.department == dept)

    # 정렬 (MariaDB 호환: NULLS LAST)
    users = (
        q.order_by(func.isnull(User.created_at).asc(), User.created_at.desc())
         .all()
    )

    # 현재 탭 기준으로 학과 목록(중복 제거, 정렬)
    dept_q = base_q
    if tab == "instructor":
        dept_q = dept_q.filter(_role_col().in_(list(INSTRUCTOR_ROLES)))
    else:
        dept_q = dept_q.filter(_role_col().in_(list(STUDENT_ROLES)))

    # DISTINCT department (NULL 포함 여부를 위해 별도 처리)
    rows = (
        db.session.query(User.department)
        .filter(dept_q.whereclause)  # 동일한 where 사용
        .distinct()
        .all()
    )
    depts = sorted({row[0] for row in rows if row[0]})  # None 제외 정렬
    has_none = any(row[0] is None for row in rows)

    return render_template(
        "users.html",
        users=users,
        role_label=_role_label,
        is_active=_is_active,
        tab=tab,
        dept=dept,
        depts=depts,      # 문자열 학과 목록
        has_none=has_none # NULL 학과 존재 여부
    )

@bp.post("/<int:uid>/deactivate", endpoint="deactivate")
def deactivate(uid: int):
    u = db.session.get(User, uid)
    if not u:
        flash("사용자를 찾을 수 없습니다.", "error")
        return redirect(url_for("users.home"))
    if _is_admin(u):
        flash("관리자 계정은 변경할 수 없습니다.", "error")
        return redirect(url_for("users.home"))

    if hasattr(u, "is_active"):
        u.is_active = False
        db.session.commit()
        flash("계정을 비활성화했습니다.", "success")
    else:
        flash("is_active 필드가 없어 상태를 변경할 수 없습니다. 모델에 Boolean 'is_active'를 추가하세요.", "error")
    return redirect(url_for("users.home", tab=request.args.get("tab", "instructor"), dept=request.args.get("dept", "all")))

@bp.post("/<int:uid>/activate", endpoint="activate")
def activate(uid: int):
    u = db.session.get(User, uid)
    if not u:
        flash("사용자를 찾을 수 없습니다.", "error")
        return redirect(url_for("users.home"))
    if _is_admin(u):
        flash("관리자 계정은 변경할 수 없습니다.", "error")
        return redirect(url_for("users.home"))

    if hasattr(u, "is_active"):
        u.is_active = True
        db.session.commit()
        flash("계정을 활성화했습니다.", "success")
    else:
        flash("is_active 필드가 없어 상태를 변경할 수 없습니다. 모델에 Boolean 'is_active'를 추가하세요.", "error")
    return redirect(url_for("users.home", tab=request.args.get("tab", "instructor"), dept=request.args.get("dept", "all")))