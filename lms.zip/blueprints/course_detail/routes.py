from __future__ import annotations

import math
import mimetypes
import os
import tempfile
import subprocess
import shutil
import secrets
from hashlib import md5
from io import BytesIO
from urllib.parse import quote
from collections import defaultdict
from datetime import datetime, date, timedelta, timezone, time


from flask import (
    Blueprint, render_template, request, redirect, url_for, flash,
    abort, g, session, current_app, send_file
)
from sqlalchemy import func

from helpers.auth import login_required
from helpers.utils import _save_upload  # 선택적 폴백용(주석 참고)
from helpers.roles import (
    ensure_course_owner_or_403,
    is_course_owner_or_admin,
)
from helpers.course_attachments import save_many_course_attachments

from models import (
    db,
    Course,
    Assignment,
    Submission,
    Enrollment,
    Material,
    MaterialEvent,
    Notice,
    DiscussionThread,
    DiscussionComment,
    User,
    MaterialBlob,
    CourseAttachment
)

bp = Blueprint("course_detail", __name__, url_prefix="/course")

# 한국 표준시
KST = timezone(timedelta(hours=9))

# 프로젝트 모델 별칭(가독성)
LectureMaterial = Material
Announcement = Notice


# ────────────────────────────────────────────────────────────────
# 권한/유틸
# ────────────────────────────────────────────────────────────────

def _ensure_access(user, course) -> None:
    """소유자/관리자는 통과, 그 외에는 수강중이어야 통과."""
    if is_course_owner_or_admin(course, user):
        return
    ok = (
        db.session.query(Enrollment.id)
        .filter_by(user_id=user.id, course_id=course.id)
        .first()
    )
    if not ok:
        abort(403)


def _ffmpeg_path() -> str | None:
    """ffmpeg 위치 탐색 (PATH 또는 환경변수 FFMPEG_BINARY)."""
    env = os.environ.get("FFMPEG_BINARY")
    if env and os.path.exists(env):
        return env
    return shutil.which("ffmpeg")


def _transcode_to_h264_bytes(file_storage) -> tuple[bytes, str] | None:
    """
    업로드 동영상을 H.264(yuv420p)/AAC/faststart로 변환해 bytes 반환.
    실패 시 None 반환(원본 사용).
    """
    ffmpeg = _ffmpeg_path()
    if not ffmpeg:
        return None

    suffix = os.path.splitext(file_storage.filename or "")[1] or ".mp4"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as src_tmp:
        file_storage.stream.seek(0)
        src_tmp.write(file_storage.read())
        src_path = src_tmp.name

    out_path = src_path + "_h264.mp4"

    cmd = [
        ffmpeg, "-y", "-i", src_path,
        "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
        "-c:v", "libx264", "-profile:v", "main", "-level", "4.1", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "160k",
        "-movflags", "+faststart",
        out_path,
    ]

    try:
        subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        with open(out_path, "rb") as f:
            data = f.read()
        return data, "video/mp4"
    except Exception:
        return None
    finally:
        for p in (src_path, out_path):
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass


def _fmt_duration(sec: int | None) -> str | None:
    if not sec:
        return None
    m, s = divmod(int(sec), 60)
    return f"{m}분" if s == 0 else f"{m}분 {s}초"


def _fmt_size(bytes_: int | None) -> str | None:
    if not bytes_:
        return None
    mb = bytes_ / (1024 * 1024)
    return f"{mb:.1f}MB"


def _weeks_total(course: Course) -> int:
    """강좌 총 주차(기간 우선)."""
    if course.start_date and course.end_date:
        days = (course.end_date - course.start_date).days + 1
        return max(1, math.ceil(days / 7))
    w = db.session.query(func.max(Material.week)).filter(Material.course_id == course.id).scalar()
    return int(w or 15)


def current_week_range(tz=KST, week_start: str = "sun") -> tuple[date, date]:
    """이번 주(일~토 or 월~일) 범위."""
    today = datetime.now(tz).date()
    if week_start == "sun":
        start = today - timedelta(days=(today.weekday() + 1) % 7)
    else:
        start = today - timedelta(days=today.weekday())
    end = start + timedelta(days=6)
    return start, end


def _week_range(course: Course, w: int) -> tuple[date | None, date | None]:
    """강좌 시작일 기준 w주차의 시작/끝 날짜."""
    if not course.start_date:
        return None, None
    start = course.start_date + timedelta(days=7 * (w - 1))
    end = start + timedelta(days=6)
    return start, end


def _current_week(course: Course, *, weeks_total: int) -> int:
    """현재 주차(1..weeks_total)."""
    today = datetime.now(KST).date()
    if course.start_date:
        if today < course.start_date:
            return 1
        diff_days = (today - course.start_date).days
        w = diff_days // 7 + 1
        if course.end_date:
            w = min(w, weeks_total)
        return max(1, min(weeks_total, w))
    return 1

# ── 과제 설명/첨부 헬퍼 ─────────────────────────────────────────

def get_assignment_desc(a):
    return (getattr(a, "description", "") or "")

def set_assignment_desc(a, text: str | None):
    if hasattr(a, "description"):
        a.description = (text or "")

def get_assignment_file(a):
    return getattr(a, "file_url", None) or getattr(a, "file_path", None)

def set_assignment_file(a, path: str):
    if hasattr(a, "file_url"):
        a.file_url = path
    elif hasattr(a, "file_path"):
        a.file_path = path

# ────────────────────────────────────────────────────────────────
# 공지
# ────────────────────────────────────────────────────────────────
def _get_author_col(model):
    """
    model(DiscussionThread/DiscussionComment)에서 작성자 컬럼을 찾아
    (컬럼객체, 컬럼명) 튜플을 돌려준다.
    우선순위: author_user_id > user_id > author_id > owner_user_id > created_by > creator_user_id
    """
    for name in ("author_user_id", "user_id", "author_id",
                 "owner_user_id", "created_by", "creator_user_id"):
        if hasattr(model, name):
            return getattr(model, name), name
    return None, None

def _set_author(model_instance, user_id):
    """작성자 컬럼 이름을 찾아 값 세팅"""
    _, name = _get_author_col(type(model_instance))
    if name:
        setattr(model_instance, name, user_id)

def _save_upload_to_blob(file_storage, obj):
    """
    request.files['file']에서 받은 파일을 obj(Assignment/Notice)의 BLOB 컬럼에 저장.
    기존 file_path/file_url 계열은 혼선 방지를 위해 비웁니다.
    """
    if not file_storage or not getattr(file_storage, "filename", ""):
        return

    # 안전하게 포인터 초기화
    try:
        file_storage.stream.seek(0)
    except Exception:
        pass

    data = file_storage.read()

    # 메타
    filename = os.path.basename(file_storage.filename)
    mime = file_storage.mimetype or mimetypes.guess_type(filename)[0] or "application/octet-stream"

    # 모델 공통 필드 세팅 (존재할 때만)
    if hasattr(obj, "attachment_data"): obj.attachment_data = data
    if hasattr(obj, "attachment_name"): obj.attachment_name = filename
    if hasattr(obj, "attachment_mime"): obj.attachment_mime = mime
    if hasattr(obj, "attachment_size"): obj.attachment_size = len(data)
    if hasattr(obj, "attachment_md5"):  obj.attachment_md5  = md5(data).hexdigest()

    # 경로/URL 방식은 충돌 방지로 비움
    if hasattr(obj, "file_url"):  obj.file_url  = None
    if hasattr(obj, "file_path"): obj.file_path = None

# ────────────────────────────────────────────────────────────────
# 상세
# ────────────────────────────────────────────────────────────────
@bp.get("/<int:course_id>", endpoint="detail")
@login_required
def detail(course_id: int):
    user = g.user
    uid = user.id

    course = db.session.get(Course, course_id) or abort(404, description="강좌를 찾을 수 없습니다.")
    _ensure_access(user, course)

    tab = (request.args.get("tab") or "materials").strip().lower()
    if tab not in {"materials", "assignments", "notices", "discussion", "students", "attendance"}:
        tab = "materials"

    # 진행률(과제 기준)
    total = db.session.query(Assignment).filter_by(course_id=course.id).count()
    submitted = (
        db.session.query(Submission)
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .filter(
            Submission.user_id == uid,
            Assignment.course_id == course.id,
            Submission.submitted_at.isnot(None),
        )
        .count()
    )
    progress_pct = int((submitted / total) * 100) if total else 0

    # 과제 + 내 제출맵
    assignments = (
        db.session.query(Assignment)
        .filter_by(course_id=course.id)
        .order_by(Assignment.due_at.is_(None), Assignment.due_at.asc())
        .all()
    )
    subs = (
        db.session.query(Submission)
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .filter(Submission.user_id == uid, Assignment.course_id == course.id)
        .all()
    )
    sub_map = {s.assignment_id: s for s in subs}

    # ✅ 과제 첨부 맵: {assignment_id: [CourseAttachment...]}
    att_map: dict[int, list[CourseAttachment]] = {}
    if assignments:
        aid_list = [a.id for a in assignments]
        ca_rows = (
            db.session.query(CourseAttachment)
            .filter(
                CourseAttachment.course_id == course.id,
                CourseAttachment.parent_kind == "assignment",
                CourseAttachment.parent_id.in_(aid_list),
            )
            .order_by(CourseAttachment.created_at.asc())
            .all()
        )
        for ca in ca_rows:
            att_map.setdefault(ca.parent_id, []).append(ca)

    # 자료 + 내 이벤트
    m_rows = (
        db.session.query(Material)
        .filter(Material.course_id == course.id, Material.is_published.is_(True))
        .order_by(Material.week.is_(None), Material.week.asc(), Material.created_at.desc())
        .all()
    )
    mat_ids = [m.id for m in m_rows]
    played: set[int] = set()
    completed: set[int] = set()
    if mat_ids:
        for mid, action in (
            db.session.query(MaterialEvent.material_id, MaterialEvent.action)
            .filter(MaterialEvent.user_id == uid, MaterialEvent.material_id.in_(mat_ids))
            .all()
        ):
            if action == "play":
                played.add(mid)
            elif action == "complete":
                completed.add(mid)

    # 주차 그룹
    by_week: dict[int, list[dict]] = defaultdict(list)
    for r in m_rows:
        acts_done = "complete" if r.id in completed else ("play" if r.id in played else None)
        status = "완료" if acts_done == "complete" else ("진행중" if acts_done == "play" else "대기")
        item = {
            "id": r.id,
            "week": r.week or 0,
            "title": r.title,
            "duration": _fmt_duration(getattr(r, "duration_seconds", None)),
            "size": _fmt_size(getattr(r, "size_bytes", None)),
            "download": bool(r.kind == "file" and getattr(r, "is_downloadable", False)),
            "status": status,
            "kind": r.kind,
            "play_url": url_for("materials.play", material_id=r.id) if r.kind != "file" else None,
            "download_url": url_for("materials.download", material_id=r.id) if r.kind == "file" else None,
        }
        by_week[r.week or 0].append(item)

    # 주차/날짜 계산
    weeks_total = _weeks_total(course)
    cur_week = _current_week(course, weeks_total=weeks_total)
    cur_start, cur_end = current_week_range(week_start="sun")
    
    # 강의 시작일이 있으면 해당 주차 범위 사용, 없으면 달력 주(일~토)
    ws, we = _week_range(course, cur_week)
    if ws and we:
        cur_start, cur_end = ws, we
    else:
        cur_start, cur_end = current_week_range(week_start="sun")

    # 이번주(선정된 범위)로 created_at 비교값 구성 (naive 가정)
    cur_start_dt = datetime.combine(cur_start, time.min)
    cur_end_dt   = datetime.combine(cur_end,   time.max)

    # 주차별 (시작일, 종료일) 맵 (교수 템플릿에서 표시 가능)
    week_ranges = {w: _week_range(course, w) for w in range(1, weeks_total + 1)}

    # 이번주 목록: (1) 현재 주차 자료 + (2) 이번주에 생성된 모든 자료(주차 지정/미지정 상관없음)
    cur_list = list(by_week.get(cur_week, []))
    already_ids = {it["id"] for it in cur_list}

    recent_any = (
        db.session.query(Material)
        .filter(
            Material.course_id == course.id,
            Material.is_published.is_(True),
            Material.week.is_(None),
            Material.created_at >= cur_start_dt,
            Material.created_at <= cur_end_dt,
        )
        .order_by(Material.created_at.desc())
        .all()
    )
    for r in recent_any:
        if r.id in already_ids:
            continue
        acts_done = "complete" if r.id in completed else ("play" if r.id in played else None)
        status = "완료" if acts_done == "complete" else ("진행중" if acts_done == "play" else "대기")
        cur_list.append({
            "id": r.id,
            "week": r.week or cur_week,  # 화면 표시용
            "title": r.title,
            "duration": _fmt_duration(getattr(r, "duration_seconds", None)),
            "size": _fmt_size(getattr(r, "size_bytes", None)),
            "download": bool(r.kind == "file" and getattr(r, "is_downloadable", False)),
            "status": status,
            "kind": r.kind,
            "play_url": url_for("materials.play", material_id=r.id) if r.kind != "file" else None,
            "download_url": url_for("materials.download", material_id=r.id) if r.kind == "file" else None,
        })

    # 주차별 진행 요약(칩)
    week_status = []
    for w in range(1, weeks_total + 1):
        lst = by_week.get(w, [])
        total_cnt = len(lst)
        done_cnt = sum(1 for it in lst if it["status"] == "완료")
        if total_cnt == 0:
            state = "-"
        elif done_cnt == 0:
            state = "대기"
        elif done_cnt == total_cnt:
            state = "완료"
        else:
            state = "진행"
        week_status.append(
            {
                "week": w,
                "total": total_cnt,
                "done": done_cnt,
                "state": state,
                "href": url_for("course_detail.detail", course_id=course.id, tab="materials") + f"#w{w}",
            }
        )

    # 공지
    notices = (
        db.session.query(Notice)
        .filter(Notice.course_id == course.id)
        .order_by(Notice.is_pinned.desc(), Notice.created_at.desc())
        .all()
    )

    # ✅ 공지 첨부 맵: {notice_id: [CourseAttachment...]}
    natt_map: dict[int, list[CourseAttachment]] = {}
    if notices:
        nid_list = [n.id for n in notices]
        cn_rows = (
            db.session.query(CourseAttachment)
            .filter(
                CourseAttachment.course_id == course.id,
                CourseAttachment.parent_kind == "notice",
                CourseAttachment.parent_id.in_(nid_list),
            )
            .order_by(CourseAttachment.created_at.asc())
            .all()
        )
        for ca in cn_rows:
            natt_map.setdefault(ca.parent_id, []).append(ca)

    # 토론 
    threads = (
        db.session.query(DiscussionThread)
        .filter(DiscussionThread.course_id == course.id)
        .order_by(DiscussionThread.updated_at.desc())
        .all()
    )
    discussion = []
    for t in threads:
        cnt = db.session.query(func.count(DiscussionComment.id)).filter_by(thread_id=t.id).scalar()
        latest = (
            db.session.query(func.max(DiscussionComment.created_at))
            .filter(DiscussionComment.thread_id == t.id)
            .scalar()
        ) or t.updated_at
        discussion.append({
            "id": t.id,
            "title": t.title,
            "comments": int(cnt or 0),
            "updated": latest.strftime("%Y-%m-%d %H:%M"),
        })

    # 수강 학생(교수 전용 탭)
    students_rows = []
    if tab == "students" and is_course_owner_or_admin(course, user):
        students_rows = (
            db.session.query(Enrollment, User)
            .join(User, Enrollment.user_id == User.id)
            .filter(Enrollment.course_id == course.id)
            .order_by(User.name.asc())
            .all()
        )

    is_owner_or_admin = is_course_owner_or_admin(course, user)
    template_name = "pro/course_detail.html" if is_owner_or_admin else "course_detail.html"

    # 한 번만 유효한 업로드 토큰(중복 업로드 방지)
    upload_token = None
    if is_owner_or_admin:
        upload_token = secrets.token_urlsafe(20)
        session['upload_once_token'] = upload_token
    else:
        session.pop('upload_once_token', None)

    return render_template(
        template_name,
        course=course,
        tab=tab,
        progress_pct=progress_pct,
        assignments=assignments,
        sub_map=sub_map,
        att_map=att_map,
        natt_map=natt_map,
        # 주차/진도/자료 컨텍스트
        cur_week=cur_week,
        cur_start=cur_start,
        cur_end=cur_end,
        weeks_total=weeks_total,
        week_status=week_status,
        materials_by_week=by_week,
        materials_this_week=cur_list,
        # 공지/토론
        notices=notices,
        discussion=discussion,
        # 교수 전용 컨텍스트
        students=students_rows,
        week_ranges=week_ranges,
        upload_token=upload_token,
        is_owner_or_admin=is_owner_or_admin,
    )


# 기존 /students 페이지는 통합 탭으로 리다이렉트
@bp.get("/<int:course_id>/students", endpoint="students")
@login_required
def students(course_id: int):
    course = ensure_course_owner_or_403(course_id)
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="students"))


# ────────────────────────────────────────────────────────────────
# 강의자료 업로드/삭제(교수/관리자)
# ────────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/materials/new", endpoint="materials_new")
@login_required
def materials_new(course_id: int):
    course = ensure_course_owner_or_403(course_id)

    # 1) 업로드 1회 토큰 검사
    token = request.form.get("upload_once_token")
    if not token or session.get("upload_once_token") != token:
        flash("중복 제출이 감지되어 업로드가 취소되었습니다. 페이지를 새로고침 후 다시 시도하세요.", "warning")
        return redirect(url_for("course_detail.detail", course_id=course.id, tab="materials"))
    session.pop("upload_once_token", None)

    title = (request.form.get("title") or "").strip()
    desc  = (request.form.get("description") or "").strip()
    if not title:
        flash("제목은 필수입니다.", "warning")
        return redirect(url_for("course_detail.detail", course_id=course.id, tab="materials"))

    # 주차 선택(없으면 현재 주차)
    week_s = (request.form.get("week") or "").strip()
    week = int(week_s) if week_s.isdigit() else None
    if week is None:
        weeks_total = _weeks_total(course)
        week = _current_week(course, weeks_total=weeks_total)

    # (선택) 외부 링크도 폼에서 받을 수 있도록
    storage_url = (request.form.get("storage_url") or "").strip()

    # 2) 메타 먼저 생성
    m = LectureMaterial(course_id=course.id, title=title)
    if hasattr(m, "owner_user_id"):
        m.owner_user_id = g.user.id
    if hasattr(m, "week"):
        m.week = week
    # 기본은 비디오로
    if hasattr(m, "kind") and not getattr(m, "kind", None):
        m.kind = "video"
    if hasattr(m, "is_published") and not getattr(m, "is_published", None):
        m.is_published = True
    if storage_url and hasattr(m, "storage_url"):
        m.storage_url = storage_url
    for attr in ("description", "body", "summary", "desc"):
        if hasattr(m, attr):
            setattr(m, attr, desc)

    db.session.add(m)
    db.session.flush()  # m.id 확보

    # 3) 업로드 파일 → ffmpeg 변환 → DB LONGBLOB 저장
    f = request.files.get("file")
    if f and f.filename:
        transcoded = _transcode_to_h264_bytes(f)
        if transcoded:
            blob_bytes, mime = transcoded
        else:
            try:
                f.stream.seek(0)
            except Exception:
                pass
            blob_bytes = f.read()
            mime = f.mimetype or mimetypes.guess_type(f.filename)[0] or "video/mp4"

        size = len(blob_bytes)
        checksum = md5(blob_bytes).hexdigest()

        if hasattr(m, "mime"):
            m.mime = mime

        b = db.session.query(MaterialBlob).filter_by(material_id=m.id).first()
        if b:
            b.data = blob_bytes
            b.size_bytes = size
            b.mime_type = mime
            b.checksum_md5 = checksum
        else:
            db.session.add(MaterialBlob(
                material_id=m.id,
                data=blob_bytes,
                size_bytes=size,
                mime_type=mime,
                checksum_md5=checksum,
            ))

    # 4) ✅ 소스 보장 가드: BLOB/외부URL/파일경로 중 하나도 없으면 롤백 후 안내
    b = db.session.query(MaterialBlob).filter_by(material_id=m.id).first()
    has_blob = bool(b and b.data)
    has_url  = bool(getattr(m, "storage_url", None))
    has_file = bool(getattr(m, "file_path", None))

    if m.kind == "video" and not (has_blob or has_url or has_file):
        db.session.rollback()
        flash("동영상 소스(파일 업로드/외부 URL/로컬 경로)가 필요합니다. 파일을 선택하거나 외부 링크를 입력해 주세요.", "danger")
        return redirect(url_for("course_detail.detail", course_id=course.id, tab="materials"))

    # 5) 커밋 및 완료
    db.session.commit()
    flash("강의 자료가 업로드되었습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="materials"))


@bp.post("/<int:course_id>/materials/<int:material_id>/delete", endpoint="materials_delete")
@login_required
def materials_delete(course_id: int, material_id: int):
    course = ensure_course_owner_or_403(course_id)
    m = db.session.get(Material, material_id) or abort(404)
    if m.course_id != course.id:
        abort(404)
    db.session.delete(m)
    db.session.commit()
    flash("자료를 삭제했습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="materials"))


# ────────────────────────────────────────────────────────────────
# 강의 기간 설정(교수/관리자)
# ────────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/dates", endpoint="update_dates")
@login_required
def update_dates(course_id: int):
    course = ensure_course_owner_or_403(course_id)
    s = (request.form.get("start_date") or "").strip()
    e = (request.form.get("end_date") or "").strip()

    course.start_date = date.fromisoformat(s) if s else None
    course.end_date   = date.fromisoformat(e) if e else None
    db.session.commit()

    # 미지정 자료 자동 주차 배정(기존 주차는 보존)
    if course.start_date:
        weeks_total = _weeks_total(course)
        q = (
            db.session.query(Material)
            .filter(Material.course_id == course.id)
            .filter((Material.week.is_(None)) | (Material.week == 0))
        )
        for m in q:
            created = (m.created_at.date() if getattr(m, "created_at", None) else course.start_date)
            diff_days = (created - course.start_date).days
            w = (diff_days // 7) + 1
            m.week = max(1, min(weeks_total, w))
        db.session.commit()

    flash("강의 기간을 저장했습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab=(request.args.get("tab") or "materials")))


# ────────────────────────────────────────────────────────────────
# 과제 생성/삭제/수정(교수/관리자)
# ────────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/assignments/new", endpoint="assignments_new")
@login_required
def assignments_new(course_id: int):
    course = ensure_course_owner_or_403(course_id)

    title = request.form["title"].strip()
    desc  = (request.form.get("description") or "").strip()
    due_s = (request.form.get("due_at") or "").strip()
    due   = datetime.fromisoformat(due_s) if due_s else None

    a = Assignment(course_id=course.id, title=title, due_at=due, description=desc)
    db.session.add(a)
    db.session.flush()  # a.id 확보

    # (선택) 레거시 단일 BLOB
    f = request.files.get("file")
    if f and getattr(f, "filename", ""):
        _save_upload_to_blob(f, a)

    # ✅ 다중 첨부 저장
    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=course.id,
            parent_kind="assignment",
            parent_id=a.id,
        )

    db.session.commit()
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="assignments"))


@bp.post("/assignments/<int:aid>/delete", endpoint="assignments_delete")
@login_required
def assignments_delete(aid: int):
    a = db.session.get(Assignment, aid) or abort(404)
    course = ensure_course_owner_or_403(a.course_id)
    db.session.delete(a)
    db.session.commit()
    flash("과제를 삭제했습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="assignments"))


@bp.post("/assignments/<int:aid>/update", endpoint="assignments_update")
@login_required
def assignments_update(aid: int):
    a = db.session.get(Assignment, aid) or abort(404)
    course = ensure_course_owner_or_403(a.course_id)

    a.title = (request.form.get("title") or a.title or "").strip()
    a.description = (request.form.get("description") or "").strip()
    due_s = (request.form.get("due_at") or "").strip()
    a.due_at = datetime.fromisoformat(due_s) if due_s else None

    # (선택) 레거시 단일 첨부 교체
    f = request.files.get("file")
    if f and getattr(f, "filename", ""):
        f.stream.seek(0)
        data = f.read()
        mime = f.mimetype or mimetypes.guess_type(f.filename)[0] or "application/octet-stream"
        name = os.path.basename(f.filename)
        size = len(data)
        checksum = md5(data).hexdigest()

        if hasattr(a, "attachment_data"): a.attachment_data = data
        if hasattr(a, "attachment_mime"): a.attachment_mime = mime
        if hasattr(a, "attachment_name"): a.attachment_name = name
        if hasattr(a, "attachment_size"): a.attachment_size = size
        if hasattr(a, "attachment_md5"):  a.attachment_md5  = checksum

    # ✅ 다중 첨부 추가(교체가 아니라 ‘추가’)
    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=course.id,
            parent_kind="assignment",
            parent_id=a.id,
        )

    db.session.commit()
    flash("과제 정보를 수정했습니다.", "success")
    return redirect(url_for("course_detail.assignments_submissions", aid=a.id))


@bp.get("/assignments/<int:aid>/submissions", endpoint="assignments_submissions")
@login_required
def assignments_submissions(aid: int):
    a = db.session.get(Assignment, aid) or abort(404)
    course = ensure_course_owner_or_403(a.course_id)

    edit_mode = (request.args.get("edit") == "1")

    subs_all = (
        Submission.query
        .filter_by(assignment_id=aid)
        .order_by(Submission.submitted_at.desc())
        .all()
    )
    sub_map = {}
    for s in subs_all:
        if s.user_id not in sub_map:
            sub_map[s.user_id] = s
    subs = list(sub_map.values())

    roster_rows = (
        db.session.query(Enrollment, User)
        .join(User, Enrollment.user_id == User.id)
        .filter(Enrollment.course_id == course.id)
        .order_by(User.name.asc())
        .all()
    )
    roster = [u for _, u in roster_rows]
    submitted_uids = set(sub_map.keys())
    not_submitted = [u for u in roster if u.id not in submitted_uids]

    # ✅ 과제용 ‘다중 첨부’만 조회 (parent_kind='assignment')
    ca_list = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.course_id == course.id,
            CourseAttachment.parent_kind == "assignment",
            CourseAttachment.parent_id == aid,
        )
        .order_by(CourseAttachment.created_at.desc())
        .all()
    )

    return render_template(
        "pro/submissions.html",
        course=course,
        assignment=a,
        assignment_desc=(a.description or ""),
        submissions=subs,
        roster=roster,
        not_submitted=not_submitted,
        total=len(roster),
        submitted=len(submitted_uids),
        pending=len(not_submitted),
        edit_mode=edit_mode,
        # ⛔ assignment_has_attachment 제거
        ca_list=ca_list,  # 다중 첨부만 템플릿에 노출
    )

@bp.post("/assignments/<int:aid>/attach", endpoint="assignments_attach")
@login_required
def assignments_attach(aid: int):
    """[레거시 차단] 단일 첨부 업로드는 더 이상 지원하지 않음 — 다중 첨부만 사용하세요."""
    a = db.session.get(Assignment, aid) or abort(404)
    course = ensure_course_owner_or_403(a.course_id)

    flash("단일 첨부 업로드는 지원하지 않습니다. 아래 ‘첨부’에서 여러 파일을 추가하세요.", "warning")
    return redirect(url_for("course_detail.assignments_submissions", aid=aid))


@bp.get("/assignments/<int:aid>/download", endpoint="assignments_download")
@login_required
def assignments_download(aid: int):
    """[레거시 차단] 단일 첨부 다운로드는 사용하지 않습니다. (다중 첨부를 이용하세요)"""
    abort(404, description="이 과제는 '다중 첨부'만 지원합니다. 첨부 목록에서 개별 파일을 내려받아 주세요.")

    # 2) 폴백: 기존 URL/경로
    url = getattr(a, "file_url", None) or getattr(a, "file_path", None)
    if url:
        if isinstance(url, str) and url.startswith("/"):
            return redirect(url)
        if isinstance(url, str) and os.path.isabs(url) and os.path.exists(url):
            return send_file(url, as_attachment=True)
        return redirect(url)

    abort(404, description="첨부가 없습니다.")


# ────────────────────────────────────────────────────────────────
# 공지 (CRUD + 다운로드)
# ────────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/announcements/new", endpoint="announcements_new")
@login_required
def announcements_new(course_id: int):
    course = ensure_course_owner_or_403(course_id)
    title = request.form["title"].strip()
    content = (request.form.get("content") or "").strip()

    # ✅ 모델명 교정: Notice
    ann = Notice(course_id=course.id, title=title, body=content)
    if hasattr(ann, "author_user_id"):
        ann.author_user_id = g.user.id

    db.session.add(ann)
    db.session.flush()  # ann.id 확보

    # (선택) 레거시 단일 BLOB
    f = request.files.get("file")
    if f and getattr(f, "filename", ""):
        _save_upload_to_blob(f, ann)

    # ✅ 다중 첨부 저장
    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=course.id,
            parent_kind="notice",
            parent_id=ann.id,
        )

    db.session.commit()
    flash("공지사항이 등록되었습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="notices"))


@bp.get("/announcements/<int:nid>", endpoint="announcements_detail")
@login_required
def announcements_detail(nid: int):
    # ✅ 모델명 교정: Notice
    ann = db.session.get(Notice, nid) or abort(404)
    course = db.session.get(Course, ann.course_id) or abort(404)
    _ensure_access(g.user, course)

    is_owner = is_course_owner_or_admin(course, g.user)
    edit_mode = bool(is_owner and (request.args.get("edit") == "1"))

    # ✅ 공지의 다중 첨부
    ca_list = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.course_id == course.id,
            CourseAttachment.parent_kind == "notice",
            CourseAttachment.parent_id == ann.id,
        )
        .order_by(CourseAttachment.created_at.desc())
        .all()
    )

    # ✅ 템플릿 이름/변수 통일
    template = "pro/announcement_detail.html" if is_owner else "notices.html"
    return render_template(
        template,
        course=course,
        ann=ann,
        edit_mode=edit_mode,
        ca_list=ca_list,  # ← 템플릿과 일치
    )


@bp.post("/announcements/<int:nid>/update", endpoint="announcements_update")
@login_required
def announcements_update(nid: int):
    ann = db.session.get(Notice, nid) or abort(404)
    course = ensure_course_owner_or_403(ann.course_id)

    ann.title = (request.form.get("title") or ann.title or "").strip()
    ann.body  = (request.form.get("content") or "").strip()

    # (선택) 레거시 단일 첨부 교체
    f = request.files.get("file")
    if f and f.filename:
        f.stream.seek(0)
        data = f.read()
        mime = f.mimetype or mimetypes.guess_type(f.filename)[0] or "application/octet-stream"
        name = os.path.basename(f.filename)
        ann.attachment_data = data
        ann.attachment_mime = mime
        ann.attachment_name = name
        ann.attachment_size = len(data)
        ann.attachment_md5  = md5(data).hexdigest()

    # ✅ 다중 첨부 추가
    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=course.id,
            parent_kind="notice",
            parent_id=ann.id,
        )

    db.session.commit()
    flash("공지사항을 수정했습니다.", "success")
    return redirect(url_for("course_detail.announcements_detail", nid=ann.id))


@bp.post("/announcements/<int:nid>/delete", endpoint="announcements_delete")
@login_required
def announcements_delete(nid: int):
    ann = db.session.get(Notice, nid) or abort(404)
    course = ensure_course_owner_or_403(ann.course_id)
    db.session.delete(ann)
    db.session.commit()
    flash("공지사항을 삭제했습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="notices"))


@bp.get("/announcements/<int:nid>/download", endpoint="announcements_download")
@login_required
def announcements_download(nid: int):
    ann = db.session.get(Notice, nid) or abort(404)
    course = db.session.get(Course, ann.course_id) or abort(404)
    _ensure_access(g.user, course)

    # 레거시 단일 첨부가 있을 때만 사용 (다중 첨부는 아래 별도 라우트 사용)
    if getattr(ann, "attachment_data", None):
        data = ann.attachment_data
        mime = ann.attachment_mime or "application/octet-stream"
        name = ann.attachment_name or "attachment"
        size = ann.attachment_size
        resp = current_app.response_class(data, mimetype=mime)
        resp.headers["Content-Disposition"] = f"attachment; filename*=UTF-8''{quote(name)}"
        if size:
            resp.headers["Content-Length"] = str(size)
        return resp

    abort(404, description="공지 첨부가 없습니다.")

# ────────────────────────────────────────────────────────────────
# 토론(스레드/댓글) CRUD
# ────────────────────────────────────────────────────────────────
@bp.post("/<int:course_id>/discussions/new", endpoint="discussions_new")
@login_required
def discussions_new(course_id: int):
    course = ensure_course_owner_or_403(course_id)
    title = request.form["title"].strip()
    body  = (request.form.get("body") or "").strip()

    th = DiscussionThread(course_id=course.id, title=title, author_user_id=g.user.id)
    if hasattr(th, "body"):
        th.body = body

    db.session.add(th)
    db.session.flush()  # th.id 확보

    # body 컬럼이 없다면 첫 댓글로 대체
    if body and not hasattr(th, "body"):
        db.session.add(DiscussionComment(thread_id=th.id, user_id=g.user.id, body=body))

    db.session.commit()
    flash("토론이 생성되었습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="discussion"))


@bp.post("/discussions/<int:tid>/update", endpoint="discussion_update")
@login_required
def discussion_update(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    course = ensure_course_owner_or_403(th.course_id)

    th.title = (request.form.get("title") or th.title or "").strip()
    if hasattr(th, "body"):
        th.body = (request.form.get("body") or "").strip()

    th.updated_at = datetime.now(KST)
    db.session.commit()
    flash("토론을 수정했습니다.", "success")
    return redirect(url_for("course_detail.discussion_view", tid=th.id))


@bp.post("/discussions/<int:tid>/comments", endpoint="comment_create")
@login_required
def comment_create(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    course = db.session.get(Course, th.course_id) or abort(404)
    _ensure_access(g.user, course)

    body = (request.form.get("body") or "").strip()
    parent_id = request.form.get("parent_id", type=int)

    if not body:
        flash("내용을 입력해 주세요.", "warning")
        return redirect(url_for("course_detail.discussion_view", tid=tid))

    db.session.add(DiscussionComment(
        thread_id=tid,
        user_id=g.user.id,
        body=body,
        parent_id=parent_id if parent_id else None,
    ))
    th.updated_at = datetime.now(KST)
    db.session.commit()
    return redirect(url_for("course_detail.discussion_view", tid=tid))


@bp.post("/discussions/comments/<int:cid>/update", endpoint="comment_update")
@login_required
def comment_update(cid: int):
    c = db.session.get(DiscussionComment, cid) or abort(404)
    th = db.session.get(DiscussionThread, c.thread_id) or abort(404)
    course = db.session.get(Course, th.course_id) or abort(404)

    if (c.user_id != g.user.id) and (not is_course_owner_or_admin(course, g.user)):
        abort(403)

    body = (request.form.get("body") or "").strip()
    if not body:
        flash("내용을 입력하세요.", "warning")
        return redirect(url_for("course_detail.discussion_view", tid=th.id))

    c.body = body
    th.updated_at = datetime.now(KST)
    db.session.commit()
    flash("댓글을 수정했습니다.", "success")
    return redirect(url_for("course_detail.discussion_view", tid=th.id))


@bp.post("/discussions/<int:tid>/comments/<int:cid>/delete", endpoint="comment_delete")
@login_required
def comment_delete(tid: int, cid: int):
    c = db.session.get(DiscussionComment, cid) or abort(404)
    th = db.session.get(DiscussionThread, c.thread_id) or abort(404)
    course = db.session.get(Course, th.course_id) or abort(404)

    if (c.user_id != g.user.id) and (not is_course_owner_or_admin(course, g.user)):
        abort(403)

    # 자식들까지 한 번에 삭제
    to_delete = [cid]
    idx = 0
    while idx < len(to_delete):
        pid = to_delete[idx]
        child_ids = [row.id for row in db.session.query(DiscussionComment.id)
                     .where(DiscussionComment.parent_id == pid).all()]
        to_delete.extend(child_ids)
        idx += 1

    (db.session.query(DiscussionComment)
     .where(DiscussionComment.id.in_(to_delete))
     .delete(synchronize_session=False))

    th.updated_at = datetime.now(KST)
    db.session.commit()
    flash("댓글을 삭제했습니다.", "success")
    return redirect(url_for("course_detail.discussion_view", tid=tid))


@bp.post("/discussions/<int:tid>/delete", endpoint="discussion_delete")
@login_required
def discussion_delete(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    course = ensure_course_owner_or_403(th.course_id)

    DiscussionComment.query.filter_by(thread_id=th.id).delete(synchronize_session=False)
    db.session.delete(th)
    db.session.commit()
    flash("토론을 삭제했습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="discussion"))


@bp.get("/discussions/<int:tid>", endpoint="discussion_view")
@login_required
def discussion_view(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    course = db.session.get(Course, th.course_id) or abort(404)
    _ensure_access(g.user, course)

    edit_mode = (request.args.get("edit") == "1") and is_course_owner_or_admin(course, g.user)

    rows = (
        db.session.query(DiscussionComment, User)
        .join(User, DiscussionComment.user_id == User.id)
        .filter(DiscussionComment.thread_id == tid)
        .order_by(DiscussionComment.created_at.asc())
        .all()
    )

    children = defaultdict(list)
    for c, u in rows:
        p = getattr(c, "parent_id", None)
        p = None if (p is None or p == 0) else p
        children[p].append((c, u))
    top_level = children[None]

    reply_to = request.args.get("reply_to", type=int)
    edit_comment_id = request.args.get("edit_comment", type=int)

    return render_template(
        "pro/discussion_detail.html",
        course=course,
        thread=th,
        edit_mode=edit_mode,
        top_comments=top_level,
        children_map=children,
        is_owner=is_course_owner_or_admin(course, g.user),
        reply_to=reply_to,
        edit_comment_id=edit_comment_id,
    )

@bp.post("/<int:course_id>/attachments/new", endpoint="course_attachments_new")
@login_required
def course_attachments_new(course_id: int):
    course = ensure_course_owner_or_403(course_id)
    files = request.files.getlist("files")
    save_many_course_attachments(files, course_id=course.id, parent_kind="course", parent_id=None)
    db.session.commit()
    flash("강좌 첨부를 업로드했습니다.", "success")
    return redirect(url_for("course_detail.detail", course_id=course.id, tab="materials"))

@bp.get("/attachments/<int:att_id>/download", endpoint="course_attachment_download")
@login_required
def course_attachment_download(att_id: int):
    from models import CourseAttachment, Assignment, Notice, Course
    att = db.session.get(CourseAttachment, att_id) or abort(404)

    # 권한: parent_kind에 따라 실제 course를 찾아서 검사
    course = db.session.get(Course, att.course_id) or abort(404)
    # 학생 접근은 _ensure_access로 통과(수강생이면 OK)
    _ensure_access(g.user, course)

    resp = current_app.response_class(att.data or b"", mimetype=att.mime or "application/octet-stream")
    resp.headers["Content-Disposition"] = f"attachment; filename*=UTF-8''{quote(att.filename or 'attachment')}"
    if att.size: resp.headers["Content-Length"] = str(att.size)
    return resp


@bp.post("/attachments/<int:att_id>/delete", endpoint="course_attachment_delete")
@login_required
def course_attachment_delete(att_id: int):
    from models import CourseAttachment
    att = db.session.get(CourseAttachment, att_id) or abort(404)
    course = ensure_course_owner_or_403(att.course_id)  # 업로더 권한: 소유자/관리자만

    db.session.delete(att)
    db.session.commit()
    flash("첨부파일을 삭제했습니다.", "success")

    # 원위치 보내기
    if att.parent_kind == "assignment":
        return redirect(url_for("course_detail.assignments_submissions", aid=att.parent_id))
    elif att.parent_kind == "notice":
        return redirect(url_for("course_detail.announcements_detail", nid=att.parent_id))
    else:
        return redirect(url_for("course_detail.detail", course_id=course.id))