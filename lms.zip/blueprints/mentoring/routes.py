from __future__ import annotations
import os
from urllib.parse import urlparse, urljoin
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, send_file
from sqlalchemy import or_
from helpers.auth import login_required, roles_required
from helpers.utils import _save_upload, _parse_dt
from helpers.course_attachments import save_many_course_attachments  # 
from models import (
    db, User, MentoringTeam, MentoringTeamMember, MentoringReport,
    Project, ProjectTask, ProjectTaskFile, Competition, CompetitionEntry, CourseAttachment
)


bp = Blueprint("mentoring", __name__, url_prefix="/mentoring")
from io import BytesIO
# ----------------------------------------------------------------------------- #
# 권한 & 유틸
# ----------------------------------------------------------------------------- #
@bp.app_template_global()
def is_instructor_or_admin() -> bool:
    return getattr(g.user, "role", None) in ("instructor", "admin")

@bp.app_template_global()
def is_instructor() -> bool:
    return getattr(g.user, "role", None) == "instructor"

@bp.app_template_global()
def is_admin() -> bool:
    return getattr(g.user, "role", None) == "admin"

@bp.app_template_global(name="_is_author_or_admin")
def _is_author_or_admin(author_user_id: int) -> bool:
    return (g.user.id == author_user_id) or is_instructor_or_admin()

def _is_team_member(team_id: int | None) -> bool:
    if not team_id:
        return False
    return db.session.query(MentoringTeamMember).filter_by(
        team_id=team_id, user_id=g.user.id
    ).first() is not None

def _safe_redirect_url(target: str, fallback: str):
    if not target:
        return fallback
    base = urlparse(request.host_url)
    test = urlparse(urljoin(request.host_url, target))
    if test.scheme in ("http", "https") and test.netloc == base.netloc:
        return target
    return fallback

def _can_view_project(p: Project) -> bool:
    # 교수/관리자는 기존대로 열람 가능
    if is_instructor_or_admin():
        return True
    # 학생 권한: 소유/소속만
    if p.owner_user_id and p.owner_user_id == g.user.id:
        return True
    if p.team_id and _is_team_member(p.team_id):
        return True
    return False

def _can_manage_project(p: Project) -> bool:
    # 교수/관리자는 기존대로 관리 가능
    if is_instructor_or_admin():
        return True
    if p.owner_user_id and p.owner_user_id == g.user.id:
        return True
    if p.team_id:
        t = MentoringTeam.query.get(p.team_id)
        if t and t.owner_user_id == g.user.id:
            return True
    return False

def _try_delete_local_upload(file_url: str | None):
    if not file_url:
        return
    try:
        parsed = urlparse(file_url)
        if parsed.scheme or parsed.netloc:
            return  # 외부 URL은 삭제하지 않음
        abs_path = os.path.abspath("." + file_url) if file_url.startswith("/") else os.path.abspath(file_url)
        if os.path.isfile(abs_path):
            os.remove(abs_path)
    except Exception:
        pass

def _local_abs_path_from_url(file_url: str) -> str | None:
    parsed = urlparse(file_url)
    if parsed.scheme or parsed.netloc:
        return None
    return os.path.abspath("." + file_url) if file_url.startswith("/") else os.path.abspath(file_url)

# ----------------------------------------------------------------------------- #
# 홈
# ----------------------------------------------------------------------------- #
@bp.get("/", endpoint="home")
@login_required
def home():
    """
    - 관리자: 전체(ALL) 보기 전용, 생성 폼은 템플릿에서 숨김
    - 교수/학생: 기존 '내 것' 기준 그대로
    """
    uid = g.user.id
    tab = (request.args.get("tab") or "reports").strip().lower()
    if tab not in {"reports", "teams", "projects", "competitions"}:
        tab = "reports"

    # 내가 속한 팀 (교수/학생 공통으로 필요)
    my_teams = (
        db.session.query(MentoringTeam)
        .join(MentoringTeamMember, MentoringTeamMember.team_id == MentoringTeam.id)
        .filter(MentoringTeamMember.user_id == uid)
        .distinct()
        .all()
    )
    teams_owned = db.session.query(MentoringTeam).filter_by(owner_user_id=uid).all()
    team_ids = [t.id for t in my_teams]

    # ─────────────────────────────────────────────────────────────────────
    # 관리자: 전체 데이터
    # ─────────────────────────────────────────────────────────────────────
    if is_admin():
        # 보고서: 전체
        reports_list = (
            db.session.query(MentoringReport)
            .order_by(MentoringReport.created_at.desc())
            .all()
        )
        # 팀: 전체
        teams_list = db.session.query(MentoringTeam).order_by(MentoringTeam.created_at.desc()).all()
        # 프로젝트: 전체
        projects_list = db.session.query(Project).order_by(Project.created_at.desc()).all()

        # 프로젝트별 담당자 후보(팀원 or 개인)
        members_by_project_effective: dict[int, list[User]] = {}
        for p in projects_list:
            users: list[User] = []
            if p.team_id:
                mems = db.session.query(MentoringTeamMember).filter_by(team_id=p.team_id).all()
                users = [m.user for m in mems if m.user]
            elif p.owner_user_id:
                u = User.query.get(p.owner_user_id)
                users = [u] if u else []
            members_by_project_effective[p.id] = users

        # 공모전 목록(+신청 수)
        comps = db.session.query(Competition).order_by(
            Competition.apply_deadline.is_(None), Competition.apply_deadline.asc()
        ).all()
        counts_by_comp = {
            c.id: db.session.query(CompetitionEntry).filter_by(competition_id=c.id).count()
            for c in comps
        }

        return render_template(
            "mentoring.html",
            tab=tab,
            # 관리자 보기용 데이터
            reports_list=reports_list,
            teams_list=teams_list,
            projects_list=projects_list,
            members_by_project_effective=members_by_project_effective,
            # 공모전 공통
            comps=comps,
            counts_by_comp=counts_by_comp,
            # 교수/학생용 키(템플릿 호환 위해 빈값)
            team_reports=[],
            my_teams=my_teams,
            teams_owned=teams_owned,
            my_projects=[],
            members_by_project={},
            my_entries=[],
        )

    # ─────────────────────────────────────────────────────────────────────
    # 교수/학생: 기존 '내 것' 기준 (변경 없음)
    # ─────────────────────────────────────────────────────────────────────
    team_reports = []
    if team_ids:
        team_reports = (
            db.session.query(MentoringReport)
            .filter(MentoringReport.team_id.in_(team_ids))
            .order_by(MentoringReport.created_at.desc())
            .all()
        )

    conds = [Project.owner_user_id == uid]
    if team_ids:
        conds.append(Project.team_id.in_(team_ids))
    my_projects = (
        db.session.query(Project)
        .filter(or_(*conds))
        .order_by(Project.created_at.desc())
        .all()
    )

    members_by_project: dict[int, list[User]] = {}
    for p in my_projects:
        users: list[User] = []
        if p.team_id:
            mems = db.session.query(MentoringTeamMember).filter_by(team_id=p.team_id).all()
            users = [m.user for m in mems if m.user]
        elif p.owner_user_id:
            u = User.query.get(p.owner_user_id)
            users = [u] if u else []
        members_by_project[p.id] = users

    comps = db.session.query(Competition).order_by(
        Competition.apply_deadline.is_(None), Competition.apply_deadline.asc()
    ).all()
    counts_by_comp = {
        c.id: db.session.query(CompetitionEntry).filter_by(competition_id=c.id).count()
        for c in comps
    }

    my_entries = []
    entry_conds = [CompetitionEntry.applicant_user_id == uid]
    if team_ids:
        entry_conds.append(CompetitionEntry.team_id.in_(team_ids))
    my_entries = (
        db.session.query(CompetitionEntry)
        .filter(or_(*entry_conds))
        .order_by(CompetitionEntry.created_at.desc())
        .all()
    )

    return render_template(
        "mentoring.html",
        tab=tab,
        # 기존(교수/학생) 보기용 데이터
        team_reports=team_reports,
        my_teams=my_teams,
        teams_owned=teams_owned,
        my_projects=my_projects,
        members_by_project=members_by_project,
        my_entries=my_entries,
        # 공모전 공통
        comps=comps,
        counts_by_comp=counts_by_comp,
        # 관리자용 키(템플릿 호환 위해 빈값)
        reports_list=[],
        teams_list=[],
        projects_list=[],
        members_by_project_effective={},
    )

# ----------------------------------------------------------------------------- #
# 1) 보고서 (팀 전용)
#   - 관리자: 생성 금지(읽기 전용)
#   - 교수/학생: 기존 그대로 생성 가능
# ----------------------------------------------------------------------------- #
@bp.post("/reports/new")
@login_required
def report_new():
    if is_admin():
        flash("관리자 계정은 보고서를 생성할 수 없습니다.", "warning")
        return redirect(url_for("mentoring.home", tab="reports"))

    uid = g.user.id
    title = (request.form.get("title") or "").strip()
    content = (request.form.get("content") or "").strip()
    team_id_raw = (request.form.get("team_id") or "").strip()
    team_id_int = int(team_id_raw) if team_id_raw.isdigit() else None

    if not team_id_int:
        flash("팀을 반드시 선택해야 합니다.", "error")
        return redirect(url_for("mentoring.home", tab="reports"))
    if not _is_team_member(team_id_int):
        flash("해당 팀에 속해 있어야 팀 보고서를 등록할 수 있습니다.", "error")
        return redirect(url_for("mentoring.home", tab="reports"))
    if not title:
        flash("제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="reports"))

    file = request.files.get("file")
    file_url = _save_upload(file, prefix=f"report_u{uid}") if file else None

    r = MentoringReport(
        author_user_id=uid,
        team_id=team_id_int,
        title=title,
        content=content or None,
        file_url=file_url,
    )
    db.session.add(r)
    db.session.flush()  # r.id 확보

    # ✅ 보고서: 다중 첨부 저장 (course_id=None)
    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=None,                # ← 멘토링은 코스와 무관
            parent_kind="mentoring_report",
            parent_id=r.id,
        )
    db.session.commit()
    flash("팀 보고서가 등록되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="reports"))

@bp.get("/reports/<int:report_id>", endpoint="report_detail")
@login_required
def report_detail(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    if not (is_instructor_or_admin() or _is_author_or_admin(r.author_user_id) or (r.team_id and _is_team_member(r.team_id))):
        abort(403)

    ca_list = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.parent_kind == "mentoring_report",
            CourseAttachment.parent_id == r.id,
        )
        .order_by(CourseAttachment.created_at.desc())
        .all()
    )

    back_to = request.args.get("back")
    return render_template("mentoring/report_detail.html", r=r, back_to=back_to, ca_list=ca_list)


@bp.post("/reports/<int:report_id>/delete", endpoint="report_delete")
@login_required
def report_delete(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    if not _is_author_or_admin(r.author_user_id):
        abort(403)
    _try_delete_local_upload(r.file_url)
    db.session.delete(r)
    db.session.commit()
    flash("보고서를 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="reports"))

@bp.post("/reports/<int:report_id>/attachment/delete", endpoint="report_attach_delete")
@login_required
def report_attach_delete(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    if not _is_author_or_admin(r.author_user_id):
        abort(403)
    _try_delete_local_upload(r.file_url)
    r.file_url = None
    db.session.commit()
    flash("첨부를 삭제했습니다.", "success")
    return redirect(url_for("mentoring.report_detail", report_id=report_id, back=request.args.get("back") or "reports"))

# ----------------------------------------------------------------------------- #
# 2) 팀
#   - 관리자: 생성/참여 불필요 → 금지. 전체 팀/팀원/프로필 조회 + 강퇴 가능
#   - 교수/학생: 기존 그대로 생성/참여 가능
# ----------------------------------------------------------------------------- #
@bp.post("/teams/new")
@login_required
def team_new():
    if is_admin():
        flash("관리자 계정은 팀을 생성할 수 없습니다.", "warning")
        return redirect(url_for("mentoring.home", tab="teams"))

    uid = g.user.id
    name = (request.form.get("name") or "").strip()
    is_solo = bool(request.form.get("is_solo"))
    custom_id = (request.form.get("team_id_custom") or "").strip()

    if not name:
        flash("팀 이름은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    team = MentoringTeam(name=name, owner_user_id=uid, is_solo=is_solo)
    if custom_id:
        if not custom_id.isdigit():
            flash("팀 ID는 숫자여야 합니다.", "error")
            return redirect(url_for("mentoring.home", tab="teams"))
        cid = int(custom_id)
        if MentoringTeam.query.get(cid):
            flash("이미 사용 중인 팀 ID입니다.", "error")
            return redirect(url_for("mentoring.home", tab="teams"))
        team.id = cid

    db.session.add(team)
    db.session.flush()
    db.session.add(MentoringTeamMember(team_id=team.id, user_id=uid, role="leader"))
    db.session.commit()
    flash(f"팀이 생성되었습니다. (팀 ID: {team.id})", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.post("/teams/join")
@login_required
def team_join():
    if is_admin():
        flash("관리자 계정은 팀에 참여할 수 없습니다.", "warning")
        return redirect(url_for("mentoring.home", tab="teams"))

    uid = g.user.id
    team_id = (request.form.get("team_id") or "").strip()
    team_name = (request.form.get("team_name") or "").strip()

    if not team_id.isdigit() or not team_name:
        flash("팀 ID/팀 이름을 모두 입력하세요.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    team_id_int = int(team_id)
    team = MentoringTeam.query.get(team_id_int)
    if not team or team.name != team_name:
        flash("팀 ID 혹은 팀 이름이 일치하지 않습니다.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    exists = MentoringTeamMember.query.filter_by(team_id=team_id_int, user_id=uid).first()
    if exists:
        flash("이미 해당 팀에 속해 있습니다.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    db.session.add(MentoringTeamMember(team_id=team_id_int, user_id=uid, role="member"))
    db.session.commit()
    flash("팀에 참여했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.get("/teams/<int:team_id>", endpoint="team_detail")
@login_required
def team_detail(team_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    if not (is_instructor_or_admin() or _is_team_member(t.id) or t.owner_user_id == g.user.id):
        abort(403)
    members = (
        db.session.query(MentoringTeamMember)
        .filter_by(team_id=t.id)
        .join(User, User.id == MentoringTeamMember.user_id)
        .distinct(MentoringTeamMember.user_id)
        .order_by(MentoringTeamMember.joined_at.asc())
        .all()
    )
    back_to = request.args.get("back")
    return render_template("mentoring/team_detail.html", t=t, members=members, back_to=back_to)

@bp.post("/teams/<int:team_id>/leave", endpoint="team_leave")
@login_required
def team_leave(team_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    m = MentoringTeamMember.query.filter_by(team_id=team_id, user_id=g.user.id).first()
    if not m:
        abort(403)
    if t.owner_user_id == g.user.id:
        flash("팀장은 탈퇴할 수 없습니다. 권한을 이전한 뒤 탈퇴하세요.", "error")
        return redirect(url_for("mentoring.team_detail", team_id=team_id))
    db.session.delete(m)
    db.session.commit()
    flash("팀에서 탈퇴했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.get("/users/<int:user_id>", endpoint="user_profile_view")
@login_required
def user_profile_view(user_id: int):
    u = User.query.get_or_404(user_id)
    return render_template("mentoring/user_profile_view.html", u=u, editable=False)

@bp.post("/teams/<int:team_id>/delete", endpoint="team_delete")
@roles_required("admin", "instructor")
def team_delete(team_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    db.session.delete(t)
    db.session.commit()
    flash("팀을 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.post("/teams/<int:team_id>/members/<int:user_id>/remove", endpoint="team_member_remove")
@login_required
def team_member_remove(team_id: int, user_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    if not (is_instructor_or_admin() or g.user.id == t.owner_user_id):
        abort(403)
    if user_id == t.owner_user_id:
        flash("팀장은 강퇴할 수 없습니다.", "error")
        return redirect(url_for("mentoring.team_detail", team_id=team_id))
    m = MentoringTeamMember.query.filter_by(team_id=team_id, user_id=user_id).first()
    if not m:
        flash("해당 사용자는 팀원이 아닙니다.", "error")
        return redirect(url_for("mentoring.team_detail", team_id=team_id))
    db.session.delete(m)
    db.session.commit()
    flash("팀원을 제거했습니다.", "success")
    return redirect(url_for("mentoring.team_detail", team_id=team_id))

# ----------------------------------------------------------------------------- #
# 3) 프로젝트/작업
#   - 관리자: 프로젝트/작업 생성 금지(읽기 전용), 조회는 전체 가능
#   - 교수/학생: 기존 그대로 생성/관리 가능
# ----------------------------------------------------------------------------- #
@bp.post("/projects/new")
@login_required
def project_new():
    if is_admin():
        flash("관리자 계정은 프로젝트를 생성할 수 없습니다.", "warning")
        return redirect(url_for("mentoring.home", tab="projects"))

    uid = g.user.id
    title = (request.form.get("title") or "").strip()
    description = (request.form.get("description") or "").strip()
    team_id = request.form.get("team_id")
    team_id_int = int(team_id) if team_id and team_id.isdigit() else None

    if not title:
        flash("프로젝트 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="projects"))

    p = Project(
        title=title,
        description=description or None,
        team_id=team_id_int,
        owner_user_id=uid if not team_id_int else None,
        github_repo_url=None,
    )
    db.session.add(p)
    db.session.commit()
    flash("프로젝트가 생성되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="projects"))

@bp.get("/projects/<int:project_id>", endpoint="project_detail")
@login_required
def project_detail(project_id: int):
    p = Project.query.get_or_404(project_id)
    if not _can_view_project(p):
        abort(403)
    back_to = request.args.get("back")

    if p.team_id:
        mems = MentoringTeamMember.query.filter_by(team_id=p.team_id).all()
        assignees = [m.user for m in mems if m.user]
    else:
        assignees = [User.query.get(p.owner_user_id)] if p.owner_user_id else []

    can_manage = _can_manage_project(p)

    # ✅ 프로젝트 첨부 (CourseAttachment)
    ca_list = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.parent_kind == "project",
            CourseAttachment.parent_id == p.id,
        )
        .order_by(CourseAttachment.created_at.desc())
        .all()
    )

    return render_template(
        "mentoring/project_detail.html",
        p=p,
        assignees=assignees,
        back_to=back_to,
        can_manage=can_manage,
        ca_list=ca_list,  # ← 템플릿으로 전달
    )


@bp.post("/projects/<int:project_id>/delete", endpoint="project_delete")
@login_required
def project_delete(project_id: int):
    p = Project.query.get_or_404(project_id)
    if not _can_manage_project(p):
        abort(403)
    db.session.delete(p)
    db.session.commit()
    flash("프로젝트를 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="projects"))

@bp.post("/tasks/new", endpoint="task_new")
@login_required
def task_new():
    if is_admin():
        flash("관리자 계정은 작업을 생성할 수 없습니다.", "warning")
        return redirect(url_for("mentoring.home", tab="projects"))

    project_id = request.form.get("project_id", type=int)
    title = (request.form.get("title") or "").strip()
    description = (request.form.get("description") or "").strip() or None
    due_raw = request.form.get("due_at")  # 'YYYY-MM-DDTHH:MM' 또는 'YYYY-MM-DD HH:MM' 또는 ''
    assignee_id = request.form.get("assignee_id", type=int)

    if not project_id or not title:
        flash("프로젝트와 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="projects"))

    p = Project.query.get(project_id)
    if not p or not _can_manage_project(p):
        abort(403)

    dt = _parse_dt(due_raw) if due_raw else None
    if due_raw and not dt:
        flash("마감 형식은 YYYY-MM-DDTHH:MM 또는 YYYY-MM-DD HH:MM 입니다.", "error")
        return redirect(url_for("mentoring.project_detail", project_id=p.id))

    t = ProjectTask(
        project_id=p.id,
        title=title,
        description=description,
        due_at=dt,
        assignee_user_id=assignee_id,  # None 허용
    )
    db.session.add(t)
    db.session.flush()  # t.id 확보

    # 다중 첨부 저장 (빈 파일칸 제외)
    files_ca = [f for f in request.files.getlist("files") if getattr(f, "filename", "")]
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=None,          # 멘토링은 코스와 무관
            parent_kind="task",      # parent_kind는 VARCHAR(64)로 변경되어 있어야 함
            parent_id=t.id,
        )

    db.session.commit()
    flash("작업이 추가되었습니다.", "success")
    return redirect(url_for("mentoring.project_detail", project_id=p.id, back="projects"))



@bp.get("/tasks/<int:task_id>", endpoint="task_detail")
@login_required
def task_detail(task_id: int):
    t = ProjectTask.query.get(task_id)
    if not t:
        flash("존재하지 않거나 삭제된 작업입니다.", "error")
        return redirect(url_for("mentoring.home", tab="projects"))

    p = t.project
    if not _can_view_project(p):
        abort(403)

    back_to = request.args.get("back")
    can_manage = _can_manage_project(p)

    # ✅ 작업 첨부 (CourseAttachment)
    ca_list = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.parent_kind == "task",
            CourseAttachment.parent_id == t.id,
        )
        .order_by(CourseAttachment.created_at.desc())
        .all()
    )

    return render_template(
        "mentoring/task_detail.html",
        t=t,
        p=p,
        back_to=back_to,
        can_manage=can_manage,
        ca_list=ca_list,  # ← 템플릿에 전달
    )


@bp.post("/tasks/<int:task_id>/delete", endpoint="task_delete")
@login_required
def task_delete(task_id: int):
    t = ProjectTask.query.get_or_404(task_id)
    p = t.project
    if not _can_manage_project(p):
        abort(403)

    for f in t.attachments:
        _try_delete_local_upload(f.file_url)

    db.session.delete(t)
    db.session.commit()

    next_url = request.form.get("next") or url_for(
        "mentoring.project_detail", project_id=p.id, back="projects", src="task_del"
    )

    if request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.form.get("ajax") == "1":
        return {"ok": True, "redirect": next_url}

    return redirect(next_url)



@bp.post("/tasks/files/<int:file_id>/delete", endpoint="task_file_delete")
@login_required
def task_file_delete(file_id: int):
    f = ProjectTaskFile.query.get_or_404(file_id)
    t = f.task
    p = t.project
    if not _can_manage_project(p):
        abort(403)
    _try_delete_local_upload(f.file_url)
    db.session.delete(f)
    db.session.commit()
    flash("첨부 파일을 삭제했습니다.", "success")
    return redirect(url_for("mentoring.task_detail", task_id=t.id))

@bp.get("/tasks/files/<int:file_id>/download", endpoint="task_file_download")
@login_required
def task_file_download(file_id: int):
    f = ProjectTaskFile.query.get_or_404(file_id)
    t = f.task
    p = t.project
    if not _can_view_project(p):
        abort(403)

    parsed = urlparse(f.file_url)
    if parsed.scheme or parsed.netloc:
        return redirect(f.file_url)

    abs_path = _local_abs_path_from_url(f.file_url)
    if not abs_path or not os.path.isfile(abs_path):
        abort(404)
    return send_file(abs_path, as_attachment=True, download_name=(f.filename or os.path.basename(abs_path)))

# ----------------------------------------------------------------------------- #
# 4) 공모전 — 기존 교수 로직 유지 (원래처럼 admin도 허용되어 있으므로 그대로 둠)
# ----------------------------------------------------------------------------- #
@bp.post("/competitions/new", endpoint="comp_new")
@roles_required("admin", "instructor")
def comp_new():
    title = (request.form.get("title") or "").strip()
    host = (request.form.get("host") or "").strip()
    url_ = (request.form.get("url") or "").strip()
    deadline_raw = request.form.get("apply_deadline")  # 'YYYY-MM-DDTHH:MM' 또는 'YYYY-MM-DD HH:MM' 또는 ''

    # 필수값 체크
    if not title:
        flash("공모전 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    # 마감 파싱 (datetime-local/공백 포맷 모두 허용)
    apply_deadline = _parse_dt(deadline_raw) if deadline_raw else None
    if deadline_raw and not apply_deadline:
        flash("마감 형식은 YYYY-MM-DDTHH:MM 또는 YYYY-MM-DD HH:MM 입니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    # URL 간단 정규화 (스킴 누락 시 http:// 보정)
    if url_ and not (url_.startswith("http://") or url_.startswith("https://")):
        url_ = "http://" + url_

    c = Competition(
        title=title,
        host=host or None,
        url=url_ or None,
        apply_deadline=apply_deadline,
    )
    db.session.add(c)
    db.session.commit()

    flash("공모전이 등록되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

    if not title:
        flash("공모전 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    c = Competition(title=title, host=host or None, url=url_ or None, apply_deadline=dt)
    db.session.add(c)
    db.session.commit()
    flash("공모전이 등록되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

@bp.post("/competitions/<int:competition_id>/delete", endpoint="comp_delete")
@roles_required("admin", "instructor")
def comp_delete(competition_id: int):
    c = Competition.query.get_or_404(competition_id)
    db.session.delete(c)  # entries는 FK ON DELETE CASCADE
    db.session.commit()
    flash("공모전을 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

@bp.post("/competitions/apply", endpoint="comp_apply")
@login_required
def comp_apply():
    if is_instructor_or_admin():
        flash("교수/관리자는 공모전에 신청할 수 없습니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    uid = g.user.id
    competition_id = request.form.get("competition_id")
    team_id = request.form.get("team_id")
    project_id = request.form.get("project_id")

    if not competition_id or not competition_id.isdigit():
        flash("공모전 ID가 올바르지 않습니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    entry = CompetitionEntry(
        competition_id=int(competition_id),
        team_id=int(team_id) if team_id and team_id.isdigit() else None,
        applicant_user_id=uid,
        project_id=int(project_id) if project_id and project_id.isdigit() else None,
        status="submitted",
    )
    db.session.add(entry)
    db.session.commit()
    flash("공모전에 신청했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

@bp.get("/competitions/<int:competition_id>", endpoint="comp_detail_page")
@login_required
def comp_detail_page(competition_id: int):
    c = Competition.query.get_or_404(competition_id)
    back_to = request.args.get("back")

    applicants = None
    if is_instructor_or_admin():
        entries = (
            db.session.query(CompetitionEntry, User, MentoringTeam, Project)
            .outerjoin(User, User.id == CompetitionEntry.applicant_user_id)
            .outerjoin(MentoringTeam, MentoringTeam.id == CompetitionEntry.team_id)
            .outerjoin(Project, Project.id == CompetitionEntry.project_id)
            .filter(CompetitionEntry.competition_id == competition_id)
            .order_by(CompetitionEntry.created_at.desc())
            .all()
        )
        applicants = [
            {"entry": e, "user": u, "team": t, "project": p}
            for (e, u, t, p) in entries
        ]

    return render_template("mentoring/competition_detail.html",
                           c=c, back_to=back_to, applicants=applicants)

@bp.post("/competition_entries/<int:entry_id>/cancel", endpoint="comp_entry_cancel")
@login_required
def comp_entry_cancel(entry_id: int):
    e = CompetitionEntry.query.get_or_404(entry_id)
    if not (e.applicant_user_id == g.user.id or is_instructor_or_admin()):
        abort(403)
    db.session.delete(e)
    db.session.commit()
    flash("신청을 취소했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

@bp.get("/attachments/<int:att_id>/download", endpoint="attachment_download")
@login_required
def attachment_download(att_id: int):
    att = CourseAttachment.query.get_or_404(att_id)

    # 권한 체크: parent_kind 따라 소유/소속 확인
    if att.parent_kind == "mentoring_report":
        r = MentoringReport.query.get_or_404(att.parent_id)
        if not (is_instructor_or_admin() or _is_author_or_admin(r.author_user_id) or (r.team_id and _is_team_member(r.team_id))):
            abort(403)
    elif att.parent_kind == "project":
        p = Project.query.get_or_404(att.parent_id)
        if not _can_view_project(p):
            abort(403)
    elif att.parent_kind == "task":
        t = ProjectTask.query.get_or_404(att.parent_id)
        if not _can_view_project(t.project):
            abort(403)
    else:
        abort(404)

    resp = send_file(
        BytesIO(att.data or b""),
        mimetype=att.mime or "application/octet-stream",
        as_attachment=True,
        download_name=(att.filename or "attachment"),
    )
    # BytesIO import 필요
    return resp


@bp.post("/attachments/<int:att_id>/delete", endpoint="attachment_delete")
@login_required
def attachment_delete(att_id: int):
    att = CourseAttachment.query.get_or_404(att_id)

    # 권한 체크
    redirect_url = url_for("mentoring.home")
    if att.parent_kind == "mentoring_report":
        r = MentoringReport.query.get_or_404(att.parent_id)
        if not _is_author_or_admin(r.author_user_id):
            abort(403)
        redirect_url = url_for("mentoring.report_detail", report_id=r.id)
    elif att.parent_kind == "project":
        p = Project.query.get_or_404(att.parent_id)
        if not _can_manage_project(p):
            abort(403)
        redirect_url = url_for("mentoring.project_detail", project_id=p.id)
    elif att.parent_kind == "task":
        t = ProjectTask.query.get_or_404(att.parent_id)
        if not _can_manage_project(t.project):
            abort(403)
        redirect_url = url_for("mentoring.task_detail", task_id=t.id)
    else:
        abort(404)

    db.session.delete(att)
    db.session.commit()
    flash("첨부파일을 삭제했습니다.", "success")
    return redirect(redirect_url)

# --- 보고서 첨부 추가 ---
@bp.post("/reports/<int:report_id>/attachments", endpoint="report_attachments_add")
@login_required
def report_attachments_add(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    # 업로드 권한: 작성자 또는 교수/관리자
    if not _is_author_or_admin(r.author_user_id):
        abort(403)

    files_ca = request.files.getlist("files")
    if files_ca:
        # 멘토링은 코스와 무관하므로 course_id=None 허용(컬럼 NULL 허용 상태여야 함)
        save_many_course_attachments(
            files_ca,
            course_id=None,
            parent_kind="mentoring_report",
            parent_id=r.id,
        )
        db.session.commit()
        flash("첨부를 업로드했습니다.", "success")
    else:
        flash("업로드할 파일을 선택하세요.", "warning")

    return redirect(url_for("mentoring.report_detail", report_id=r.id))


# --- 프로젝트 첨부 추가 ---
@bp.post("/projects/<int:project_id>/attachments", endpoint="project_attachments_add")
@login_required
def project_attachments_add(project_id: int):
    p = Project.query.get_or_404(project_id)
    if not _can_manage_project(p):
        abort(403)

    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=None,                # 프로젝트도 코스와 무관 → NULL
            parent_kind="project",
            parent_id=p.id,
        )
        db.session.commit()
        flash("첨부를 업로드했습니다.", "success")
    else:
        flash("업로드할 파일을 선택하세요.", "warning")

    return redirect(url_for("mentoring.project_detail", project_id=p.id))


# --- 작업 첨부 추가 ---
@bp.post("/tasks/<int:task_id>/attachments", endpoint="task_attachments_add")
@login_required
def task_attachments_add(task_id: int):
    t = ProjectTask.query.get_or_404(task_id)
    if not _can_manage_project(t.project):
        abort(403)

    files_ca = request.files.getlist("files")
    if files_ca:
        save_many_course_attachments(
            files_ca,
            course_id=None,                # 작업도 코스와 무관 → NULL
            parent_kind="task",
            parent_id=t.id,
        )
        db.session.commit()
        flash("첨부를 업로드했습니다.", "success")
    else:
        flash("업로드할 파일을 선택하세요.", "warning")

    return redirect(url_for("mentoring.task_detail", task_id=t.id))