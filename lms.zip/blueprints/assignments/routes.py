# blueprints/assignments/routes.py
from __future__ import annotations
from datetime import datetime, timezone
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, g
from helpers.auth import login_required
from helpers.utils import _save_upload
from models import db, Course, Assignment, Submission, Enrollment, CourseAttachment
import os
from config import Config

# ✅ 단일 블루프린트 (이름도, prefix도 하나로 고정)
bp = Blueprint(
    "assignments_view",
    __name__,
    url_prefix="/assignments",
)

def _ensure_access(user, course: Course):
    role = getattr(user, "role", None)
    if role in ("admin", "instructor"):
        return
    ok = db.session.query(Enrollment.id).filter_by(user_id=user.id, course_id=course.id).first()
    if not ok:
        abort(403)

def _remain_text(due_at: datetime | None) -> str:
    """UTC 기준으로 남은 시간 표시 (과거면 '마감 지남')"""
    if not due_at:
        return "마감 기한 미정"
    # due_at이 naive면 UTC로 가정
    if due_at.tzinfo is None:
        due_at = due_at.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    delta = due_at - now
    if delta.total_seconds() <= 0:
        return "마감 지남"
    d = delta.days
    h = (delta.seconds // 3600)
    m = (delta.seconds % 3600) // 60
    if d and h: return f"{d}일 {h}시간 남음"
    if d:       return f"{d}일 남음"
    if h and m: return f"{h}시간 {m}분 남음"
    if h:       return f"{h}시간 남음"
    return f"{m}분 남음"

@bp.get("/", endpoint="home")
@login_required
def home():
    """내 수강 과목의 가장 가까운 마감 과제로 리다이렉트"""
    uid = g.user.id
    a = (
        db.session.query(Assignment)
        .join(Course, Course.id == Assignment.course_id)
        .join(Enrollment, Enrollment.course_id == Course.id)
        .filter(Enrollment.user_id == uid)
        .order_by(Assignment.due_at.is_(None), Assignment.due_at.asc())
        .first()
    )
    if a:
        return redirect(url_for("assignments_view.view", aid=a.id))
    flash("등록된 과제가 없습니다.", "info")
    return redirect(url_for("courses.home"))

@bp.get("/<int:aid>", endpoint="view")
@login_required
def view(aid: int):
    """과제 상세 — 교수 첨부(다중 첨부만 표기)"""
    a = db.session.get(Assignment, aid) or abort(404)
    course = db.session.get(Course, a.course_id) or abort(404)
    _ensure_access(g.user, course)

    sub = (
        db.session.query(Submission)
        .filter(Submission.assignment_id == a.id, Submission.user_id == g.user.id)
        .order_by(
            (Submission.updated_at.is_(None)),
            Submission.updated_at.desc(),
            (Submission.submitted_at.is_(None)),
            Submission.submitted_at.desc(),
        )
        .first()
    )

    # 교수 첨부들 (CourseAttachment, 다중 첨부만)
    prof_atts = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.course_id == course.id,
            CourseAttachment.parent_kind == "assignment",
            CourseAttachment.parent_id == a.id,
        )
        .order_by(CourseAttachment.created_at.asc())
        .all()
    )

    remain = _remain_text(a.due_at)

    return render_template(
        "assignments_view.html",
        a=a,
        sub=sub,
        remain=remain,
        prof_atts=prof_atts,
        # ⛔ legacy_att 제거!
    )

@bp.route("/<int:aid>/submit", methods=["GET", "POST"], endpoint="submit")
@login_required
def submit(aid: int):
    """제출 폼 + 제출 처리(파일/코멘트) — 파일 업로드는 _save_upload 사용"""
    uid = g.user.id
    a = db.session.get(Assignment, aid) or abort(404)
    course = db.session.get(Course, a.course_id) or abort(404)
    _ensure_access(g.user, course)

    sub = db.session.query(Submission).filter_by(assignment_id=aid, user_id=uid).first()

    if request.method == "POST":
        file = request.files.get("file")
        comment = (request.form.get("comment") or "").strip()

        file_url = _save_upload(file, prefix=f"u{uid}_a{aid}") if file else None
        if file and not file_url:
            flash("허용되지 않은 파일 형식입니다.", "error")
            return redirect(url_for("assignments_view.submit", aid=aid))

        now = datetime.now(timezone.utc).replace(tzinfo=None)  # DB가 naive UTC 저장이면 naive로 맞춤
        if not sub:
            sub = Submission(assignment_id=aid, user_id=uid)
            db.session.add(sub)

        if file_url:
            sub.file_url = file_url
        if comment:
            sub.comment = comment

        sub.submitted_at = now
        sub.updated_at = now
        db.session.commit()

        is_late = bool(a.due_at and ((a.due_at.replace(tzinfo=None) if a.due_at.tzinfo else a.due_at) < now))
        flash("제출되었습니다. (지각 제출)" if is_late else "제출되었습니다.", "success")
        return redirect(url_for("assignments_view.view", aid=aid))

    remain = _remain_text(a.due_at)
    # ✅ 전역 templates/assignments_submit.html 을 사용
    return render_template("assignments_submit.html", a=a, sub=sub, remain=remain)

@bp.post("/<int:aid>/delete-file", endpoint="delete_file")
@login_required
def delete_file(aid: int):
    """학생 제출 파일 삭제(+ 실제 파일 삭제) 및 상태 롤백"""
    uid = g.user.id
    a = db.session.get(Assignment, aid) or abort(404)
    course = db.session.get(Course, a.course_id) or abort(404)
    _ensure_access(g.user, course)

    sub = (
        db.session.query(Submission)
        .filter(Submission.assignment_id == aid, Submission.user_id == uid)
        .first()
    )
    if not sub or not sub.file_url:
        flash("삭제할 파일이 없습니다.", "error")
        return redirect(url_for("assignments_view.view", aid=aid))

    # 실제 파일 삭제 (정적 업로드 경로인 경우만)
    try:
        web = sub.file_url
        if web.startswith("/static/uploads"):
            rel = web.replace("/static/uploads", "", 1).lstrip("/")
            fpath = os.path.join(Config.UPLOAD_DIR, rel)
            if os.path.isfile(fpath):
                os.remove(fpath)
    except Exception:
        pass

    # 제출 상태를 '제출 전'으로 되돌림
    sub.file_url = None
    sub.submitted_at = None
    # 선택: 채점도 초기화하려면 아래 주석 해제
    # sub.score = None
    sub.updated_at = datetime.utcnow()
    db.session.commit()

    flash("첨부파일을 삭제했습니다. (제출 전 상태로 변경)", "success")
    return redirect(url_for("assignments_view.view", aid=aid))