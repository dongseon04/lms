# blueprints/uploads/routes.py
from __future__ import annotations
import mimetypes
import re
from urllib.parse import quote
from pathlib import Path
from flask import Blueprint, current_app, abort, request, Response, g
from helpers.auth import login_required
from models import db, Material, Enrollment, Notice, NoticeAttachment

bp = Blueprint("uploads", __name__, url_prefix="/u")


# ----- 업로드 루트: 기본은 프로젝트루트/static/uploads, 설정이 있으면 우선 -----
def _get_upload_root() -> Path:
    """
    UPLOAD_ROOT을 Path로 반환.
    1) current_app.config["UPLOAD_ROOT"]가 절대/상대 모두 허용 (상대면 앱 루트 기준)
    2) 없으면 프로젝트 루트의 static/uploads 사용
    경로가 없으면 생성
    """
    cfg = current_app.config.get("UPLOAD_ROOT")
    if cfg:
        cfg_path = Path(cfg)
        if not cfg_path.is_absolute():
            # 앱 루트 기준 절대화
            base = Path(current_app.root_path)
            root = (base / cfg_path).resolve()
        else:
            root = cfg_path.resolve()
    else:
        # __init__.py가 있는 앱 루트 기준으로 프로젝트 루트 추정: app.root_path == <project>/lms
        # 통상 static/uploads는 프로젝트 루트 하위
        project_root = Path(current_app.root_path).resolve()
        root = (project_root / "static" / "uploads").resolve()

    root.mkdir(parents=True, exist_ok=True)
    return root


# ----- 접근 권한: 수강생/교수/관리자만 -----
def _can_access_rel(relpath: str, user) -> bool:
    if getattr(user, "role", None) in ("admin", "instructor"):
        return True

    m = db.session.query(Material).filter(Material.file_path == relpath).first()
    if m:
        ok = db.session.query(Enrollment.id).filter_by(
            user_id=user.id, course_id=m.course_id
        ).first()
        return bool(ok)

    att = db.session.query(NoticeAttachment).filter(
        NoticeAttachment.file_path == relpath
    ).first()
    if att:
        n = db.session.get(Notice, att.notice_id)
        if not n:
            return False
        ok = db.session.query(Enrollment.id).filter_by(
            user_id=user.id, course_id=n.course_id
        ).first()
        return bool(ok)

    return False


# ----- 경로 안전화 -----
def _resolve_safe_path(base_dir: Path, rel: str) -> Path:
    """
    base_dir 하위의 파일만 허용. 디렉터리 탈출 방지.
    """
    base = base_dir.resolve()
    rel_clean = rel.lstrip("/\\")
    p = (base / rel_clean).resolve()
    try:
        # base 밖이면 ValueError 발생
        p.relative_to(base)
    except Exception:
        abort(400, description="잘못된 경로입니다.")
    if not p.is_file():
        current_app.logger.warning("UPLOAD MISS base=%s rel=%s full=%s", base, rel, p)
        abort(404, description="파일을 찾을 수 없습니다.")
    return p


# ----- Range 파싱 (첫 구간만 처리) -----
def _parse_range(range_header: str | None, size: int):
    if not range_header:
        return None
    m = re.match(r"bytes=(\d*)-(\d*)(?:,.*)?$", range_header.strip())
    if not m:
        return None
    start_s, end_s = m.groups()
    if start_s == "" and end_s == "":
        return None
    if start_s == "":
        # 뒤에서 length 바이트
        try:
            length = int(end_s)
        except Exception:
            return None
        if length <= 0:
            return None
        start = max(0, size - length)
        end = size - 1
    else:
        try:
            start = int(start_s)
        except Exception:
            return None
        end = int(end_s) if end_s else size - 1
    if start > end or start < 0 or start >= size:
        return ("invalid", None)
    if end >= size:
        end = size - 1
    return start, end


# ASCII 안전 파일명 만들기 (헤더용)
def _ascii_fallback(name: str) -> str:
    # 영문, 숫자, 점/밑줄/대시만 남기고 나머지는 _
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    return safe or "download"


# ----- 파일 스트리밍 (HTTP Range + 권한) -----
@bp.get("/<path:relpath>", endpoint="file")
@login_required
def file(relpath: str):
    if not _can_access_rel(relpath, g.user):
        abort(403)

    base_dir = _get_upload_root()
    p = _resolve_safe_path(base_dir, relpath)

    mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    size = p.stat().st_size

    as_attachment = (request.args.get("dl") or "").lower() in ("1", "true", "yes")
    disp_type = "attachment" if as_attachment else "inline"

    # 🔑 헤더에 한글이 들어가지 않도록 ASCII fallback + RFC5987 filename*
    fname = p.name
    fname_ascii = _ascii_fallback(fname)                # ASCII만
    fname_quoted = quote(fname)                         # UTF-8 percent-encode

    rng = _parse_range(request.headers.get("Range"), size)

    if rng == ("invalid", None):
        # RFC 7233: 범위가 유효하지 않을 때
        resp = Response(status=416)
        resp.headers["Content-Range"] = f"bytes */{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        return resp

    if isinstance(rng, tuple) and len(rng) == 2:
        start, end = rng
        length = end - start + 1

        def generate():
            with open(p, "rb") as f:
                f.seek(start)
                remaining = length
                chunk = 1024 * 1024
                while remaining > 0:
                    data = f.read(min(chunk, remaining))
                    if not data:
                        break
                    remaining -= len(data)
                    yield data

        resp = Response(generate(), status=206, mimetype=mime, direct_passthrough=True)
        resp.headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = str(length)
        resp.headers["Content-Disposition"] = (
            f"{disp_type}; filename=\"{fname_ascii}\"; filename*=UTF-8''{fname_quoted}"
        )
        return resp

    def generate_full():
        with open(p, "rb") as f:
            while True:
                data = f.read(1024 * 1024)
                if not data:
                    break
                yield data

    resp = Response(generate_full(), status=200, mimetype=mime, direct_passthrough=True)
    resp.headers["Accept-Ranges"] = "bytes"
    resp.headers["Content-Length"] = str(size)
    resp.headers["Content-Disposition"] = (
        f"{disp_type}; filename=\"{fname_ascii}\"; filename*=UTF-8''{fname_quoted}"
    )
    return resp


__all__ = ("bp",)