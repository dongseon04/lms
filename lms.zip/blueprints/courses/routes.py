# blueprints/courses/routes.py
from flask import Blueprint, render_template, request, g, abort, redirect, url_for
from sqlalchemy import func, or_
from sqlalchemy.orm import aliased, joinedload
from datetime import date, datetime, timedelta
from helpers.auth import login_required
from typing import List, Any
import os
from models import (
    db, User, Course, Enrollment,
    Assignment, Submission,
    Material, MaterialEvent,
    # ▼ 관리자 전용 공지/토론 조회에 필요
    Notice,               # 공지
    DiscussionThread,     # 토론 글
    DiscussionComment,    # 토론 댓글
    CourseAttachment,
)
bp = Blueprint("courses", __name__, url_prefix="/courses")

def _calc_end_from_start_weeks(start_date: date, weeks: int) -> date:
    """시작일 + 주차 → 종료일(포함일)"""
    return start_date + timedelta(days=7 * weeks - 1)

def _load_assignment_attachments(aid: int) -> List[Any]:
    """
    프로젝트마다 첨부 모델/스키마가 달라 발생하는 '안 뜸' 문제를 방지하기 위해
    가능한 스키마를 순차적으로 시도해서 첨부를 가져옵니다.
    반환: 첨부(객체) 리스트. (filename, size, created_at, id 속성 가정)
    """
    # 1) CourseAttachment(가장 흔한 케이스)
    try:
        from models import CourseAttachment  # 실제 경로로 조정
        rows = (
            db.session.query(CourseAttachment)
            .filter(getattr(CourseAttachment, "assignment_id") == aid)
            .order_by(getattr(CourseAttachment, "created_at").asc())
            .all()
        )
        if rows:
            return rows
    except Exception:
        pass

    # 2) AssignmentAttachment 라는 이름일 수도 있음
    try:
        from models import AssignmentAttachment
        rows = (
            db.session.query(AssignmentAttachment)
            .filter(getattr(AssignmentAttachment, "assignment_id") == aid)
            .order_by(getattr(AssignmentAttachment, "created_at").asc())
            .all()
        )
        if rows:
            return rows
    except Exception:
        pass

    # 3) CourseAttachment 에 assignment_id 가 없고, (course_id + parent_type/parent_id) 구조일 수도 있음
    try:
        from models import CourseAttachment  # 재사용
        cols = CourseAttachment.__table__.c
        conds = []
        if "assignment_id" in cols:
            # 위에서 이미 시도했음
            pass
        else:
            # parent_type/parent_id 패턴
            if "parent_type" in cols and "parent_id" in cols:
                conds.append(getattr(CourseAttachment, "parent_type") == "assignment")
                conds.append(getattr(CourseAttachment, "parent_id") == aid)
            # fallback: 혹시 assignmentId 같은 camelCase?
            if "assignmentId" in cols:
                conds.append(getattr(CourseAttachment, "assignmentId") == aid)

        if conds:
            rows = (
                db.session.query(CourseAttachment)
                .filter(*conds)
                .order_by(getattr(CourseAttachment, "created_at").asc() if "created_at" in cols else None)
                .all()
            )
            if rows:
                return rows
    except Exception:
        pass

    # 못 찾으면 빈 리스트
    return []

# ===== 공통: 코스 스태프 권한 =====
STAFF_ROLES = {"admin","administrator","관리자","professor","instructor","teacher","강사"}

def _is_course_staff(course: Course, user: User) -> bool:
    if not user:
        return False
    role = (getattr(user, "role", "") or "").strip().lower()
    if getattr(user, "is_admin", False) or role in STAFF_ROLES:
        return True
    # 코스 담당자(단일 담당)
    if getattr(course, "instructor_user_id", None) and user.id == course.instructor_user_id:
        return True
    # 공동 담당자 컬렉션이 있다면
    if hasattr(course, "instructors") and course.instructors:
        return any(getattr(ins, "id", None) == user.id for ins in course.instructors)
    return False

def _require_course_staff(course_id: int) -> Course:
    course = db.session.get(Course, course_id) or abort(404)
    if not _is_course_staff(course, g.user):
        abort(403, description="교수/강사 또는 관리자만 접근할 수 있습니다.")
    return course

# -------------------------
# (학생) 강좌 목록 (수강 중인 강좌)
# -------------------------
@bp.get("/", endpoint="home")
@login_required
def index():
    uid = g.user.id
    role = (getattr(g.user, "role", "") or "").strip().lower()

    # ── 관리자: 관리자 목록으로 이동
    if role in {"admin", "administrator"} or getattr(g.user, "is_admin", False):
        return redirect(url_for("courses.admin_list"))

    q_raw = (request.args.get("q") or "").strip()
    q = q_raw.lower()

    # ── 교수/강사 뷰: 내가 가르치는 강의(또는 담당) 목록 (pro/courses.html)
    if role in {"professor", "instructor", "teacher"}:
        base_q = db.session.query(Course.id, Course.title)

        # 스키마에 존재할 수 있는 다양한 담당자 컬럼 자동 탐지
        owner_fields = ("instructor_user_id", "owner_user_id", "teacher_id", "created_by")
        filters = []
        for f in owner_fields:
            col = getattr(Course, f, None)
            if col is not None:
                filters.append(col == uid)

        if filters:
            base_q = base_q.filter(or_(*filters))
        else:
            # 담당자 컬럼이 없다면 Enrollment 기반(역할 컬럼 있으면 강사 역할만)
            base_q = base_q.join(Enrollment, Enrollment.course_id == Course.id)
            if hasattr(Enrollment, "role"):
                base_q = base_q.filter(
                    Enrollment.user_id == uid,
                    Enrollment.role.in_(["instructor", "teacher", "ta"])  # 필요 시 역할명 추가
                )
            else:
                base_q = base_q.filter(Enrollment.user_id == uid)

        if q:
            base_q = base_q.filter(func.lower(Course.title).like(f"%{q}%"))

        base_q = base_q.order_by(Course.id.desc())
        rows = base_q.all()
        if not rows:
            return render_template("pro/courses.html", courses=[], q=q_raw)

        course_ids = [cid for cid, _ in rows]

        total_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Assignment.course_id, func.count(Assignment.id))
                .where(Assignment.course_id.in_(course_ids))
                .group_by(Assignment.course_id)
            ).all()
        }
        submitted_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Assignment.course_id, func.count(Submission.id))
                .join(Assignment, Assignment.id == Submission.assignment_id)
                .where(
                    Assignment.course_id.in_(course_ids),
                    Submission.submitted_at.isnot(None),
                )
                .group_by(Assignment.course_id)
            ).all()
        }
        roster_by_course = {
            cid: cnt
            for cid, cnt in db.session.execute(
                db.select(Enrollment.course_id, func.count(Enrollment.user_id))
                .where(Enrollment.course_id.in_(course_ids))
                .group_by(Enrollment.course_id)
            ).all()
        }

        cards = []
        for cid, title in rows:
            cards.append({
                "course": {"id": cid, "title": title},
                "assignments": int(total_by_course.get(cid, 0)),
                "submitted_all": int(submitted_by_course.get(cid, 0)),
                "enrolled": int(roster_by_course.get(cid, 0)),
            })
        return render_template("pro/courses.html", courses=cards, q=q_raw)

    # ── 학생 뷰: 수강 중인 강좌 목록 (courses.html) — 교수명/기간 포함
    prof = aliased(User)
    base_q = (
        db.session.query(
            Course.id, Course.title, Course.start_date, Course.end_date,
            Course.instructor_user_id, prof.name.label("instructor_name"),
        )
        .join(Enrollment, Enrollment.course_id == Course.id)
        .outerjoin(prof, prof.id == Course.instructor_user_id)
        .filter(Enrollment.user_id == uid)
    )
    if q:
        base_q = base_q.filter(func.lower(Course.title).like(f"%{q}%"))

    base_q = base_q.order_by(Course.id.desc())
    rows = base_q.all()
    if not rows:
        return render_template("courses.html", courses=[], q=q_raw)

    course_ids = [r.id for r in rows]

    total_by_course = {
        cid: cnt
        for cid, cnt in db.session.execute(
            db.select(Assignment.course_id, func.count(Assignment.id))
            .where(Assignment.course_id.in_(course_ids))
            .group_by(Assignment.course_id)
        ).all()
    }
    submitted_by_course = {
        cid: cnt
        for cid, cnt in db.session.execute(
            db.select(Assignment.course_id, func.count(Submission.id))
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .where(
                Assignment.course_id.in_(course_ids),
                Submission.user_id == uid,
                Submission.submitted_at.isnot(None),
            )
            .group_by(Assignment.course_id)
        ).all()
    }

    cards = []
    for r in rows:
        total = int(total_by_course.get(r.id, 0))
        submitted = int(submitted_by_course.get(r.id, 0))
        pct = int((submitted / total) * 100) if total else 0
        cards.append({
            "course": {
                "id": r.id,
                "title": r.title,
                "start_date": r.start_date,
                "end_date": r.end_date,
                "instructor_user_id": r.instructor_user_id,
            },
            "instructor_name": r.instructor_name,
            "total": total,
            "submitted": submitted,
            "progress": pct,
        })

    return render_template("courses.html", courses=cards, q=q_raw)



# =========================
# ===== Admin Routes ======
# =========================
def _is_admin() -> bool:
    role = (getattr(g.user, "role", "") or "").strip().lower()
    is_admin_flag = bool(getattr(g.user, "is_admin", False))
    role_id = getattr(g.user, "role_id", None)
    return bool(
        is_admin_flag
        or role in {"admin", "administrator", "관리자"}
        or role_id in {1}
    )

def _admin_required():
    if not _is_admin():
        abort(403, description="관리자 권한이 필요합니다.")

def _assign_students(course_id: int, student_ids: list[int]):
    current = {e.user_id for e in db.session.query(Enrollment).filter_by(course_id=course_id).all()}
    target = set(student_ids)
    to_add = target - current
    to_del = current - target
    if to_add:
        db.session.bulk_save_objects([Enrollment(user_id=sid, course_id=course_id) for sid in to_add])
    if to_del:
        Enrollment.query.filter(
            Enrollment.course_id == course_id,
            Enrollment.user_id.in_(list(to_del))
        ).delete(synchronize_session=False)

def _weeks_total(course: Course) -> int:
    if course.start_date and course.end_date:
        days = (course.end_date - course.start_date).days + 1
        return max(1, (days + 6) // 7)
    w = db.session.query(func.max(Material.week)).filter(Material.course_id == course.id).scalar()
    return int(w or 15)

def _compute_dates_from_weeks(weeks: int | None):
    if not weeks or weeks <= 0:
        return None, None
    start = date.today()
    end = start + timedelta(days=7 * weeks - 1)
    return start, end


# ----- 관리자: 전체 강좌 목록 -----
@bp.get("/admin", endpoint="admin_list")
@login_required
def admin_list():
    _admin_required()

    q_raw = (request.args.get("q") or "").strip()
    q = q_raw.lower()

    prof = aliased(User)
    base = (
        db.session.query(
            Course.id, Course.title, Course.start_date, Course.end_date,
            Course.instructor_user_id, Course.credit, prof.name.label("instructor_name")
        )
        .outerjoin(prof, prof.id == Course.instructor_user_id)
    )

    if q:
        base = base.filter(
            func.lower(Course.title).like(f"%{q}%")
            | func.lower(func.coalesce(prof.name, "")).like(f"%{q}%")
        )

    rows = base.order_by(Course.id.desc()).all()
    courses = [{
        "id": r.id,
        "title": r.title,
        "start_date": r.start_date,
        "end_date": r.end_date,
        "instructor_user_id": r.instructor_user_id,
        "credit": r.credit,
        "instructor_name": r.instructor_name,
    } for r in rows]

    return render_template("admin/courses.html", courses=courses, q=q_raw)


# ----- 관리자: 강좌 생성 -----
@bp.route("/admin/new", methods=["GET", "POST"], endpoint="admin_new")
@login_required
def admin_new():
    _admin_required()

    prof_roles = ["professor", "instructor", "teacher", "교수"]
    stud_roles = ["student", "학생"]
    professors = (
        User.query
        .filter(func.lower(func.coalesce(User.role, "")).in_([r.lower() for r in prof_roles]))
        .order_by(User.name.asc()).all()
    )
    students = (
        User.query
        .filter(func.lower(func.coalesce(User.role, "")).in_([r.lower() for r in stud_roles]))
        .order_by(User.name.asc()).all()
    )

    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        if not title:
            abort(400, description="강좌명은 필수입니다.")

        description = (request.form.get("description") or "").strip() or None
        instructor_user_id = request.form.get("instructor_user_id") or None
        credit = request.form.get("credit") or None

        # ✅ 시작일/주차 입력
        start_date_str = (request.form.get("start_date") or "").strip()
        weeks_val = (request.form.get("weeks") or "").strip()

        # ✅ 체크박스 다중 선택
        student_ids = [int(x) for x in request.form.getlist("student_ids")] if request.form.getlist("student_ids") else []

        instructor_user_id = int(instructor_user_id) if instructor_user_id else None
        credit = int(credit) if credit not in ("", None) else None

        start_date, end_date = None, None
        if start_date_str and weeks_val:
            try:
                start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
                weeks = int(weeks_val)
                if weeks <= 0:
                    raise ValueError()
                end_date = _calc_end_from_start_weeks(start_date, weeks)
            except ValueError:
                abort(400, description="시작일/주차 입력이 올바르지 않습니다.")

        course = Course(
            title=title,
            description=description,
            instructor_user_id=instructor_user_id,
            credit=credit,
            start_date=start_date,
            end_date=end_date,
        )
        db.session.add(course)
        db.session.flush()  # id 확보

        if student_ids:
            _assign_students(course.id, student_ids)

        db.session.commit()
        return redirect(url_for("courses.admin_detail", course_id=course.id))

    return render_template(
        "admin/course_form.html",
        course=None,
        professors=professors,
        students=students,
        assigned_ids=[],  # ← 리스트로
    )


# ----- 관리자: 강좌 수정 -----
@bp.route("/admin/<int:course_id>/edit", methods=["GET", "POST"], endpoint="admin_edit")
@login_required
def admin_edit(course_id: int):
    _admin_required()

    course = db.session.get(Course, course_id) or abort(404)

    prof_roles = ["professor", "instructor", "teacher", "교수"]
    stud_roles = ["student", "학생"]
    professors = (
        User.query
        .filter(func.lower(func.coalesce(User.role, "")).in_([r.lower() for r in prof_roles]))
        .order_by(User.name.asc()).all()
    )
    students = (
        User.query
        .filter(func.lower(func.coalesce(User.role, "")).in_([r.lower() for r in stud_roles]))
        .order_by(User.name.asc()).all()
    )
    assigned_ids = {e.user_id for e in Enrollment.query.filter_by(course_id=course.id).all()}

    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        if not title:
            abort(400, description="강좌명은 필수입니다.")
        course.title = title
        course.description = (request.form.get("description") or "").strip() or None

        instructor_user_id = request.form.get("instructor_user_id") or None
        credit = request.form.get("credit") or None
        start_date_str = (request.form.get("start_date") or "").strip()
        weeks_val = (request.form.get("weeks") or "").strip()

        course.instructor_user_id = int(instructor_user_id) if instructor_user_id else None
        course.credit = int(credit) if credit not in ("", None) else None

        if start_date_str and weeks_val:
            try:
                start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
                weeks = int(weeks_val)
                if weeks <= 0:
                    raise ValueError()
            except ValueError:
                abort(400, description="시작일/주차 입력이 올바르지 않습니다.")
            course.start_date = start_date
            course.end_date = _calc_end_from_start_weeks(start_date, weeks)

        # ✅ 학생 체크박스 동기화
        new_ids = [int(x) for x in request.form.getlist("student_ids")] if request.form.getlist("student_ids") else []
        _assign_students(course.id, new_ids)

        db.session.commit()
        return redirect(url_for("courses.admin_detail", course_id=course.id))

    return render_template(
        "admin/course_form.html",
        course=course,
        professors=professors,
        students=students,
        assigned_ids=assigned_ids,
    )


# ----- 관리자: 강좌 디테일 -----
# 필요: from models import Notice, DiscussionThread, DiscussionComment  ← 위쪽 import에 추가

@bp.get("/admin/<int:course_id>", endpoint="admin_detail")
@login_required
def admin_detail(course_id: int):
    _admin_required()
    tab = (request.args.get("tab") or "materials").strip().lower()
    if tab not in {"materials","assignments","notices","discussion","students"}:
        tab = "materials"

    course = db.session.get(Course, course_id) or abort(404)

    instr_name = None
    if course.instructor_user_id:
        instr = db.session.get(User, course.instructor_user_id)
        instr_name = instr.name if instr else None

    student_ids = [e.user_id for e in Enrollment.query.filter_by(course_id=course.id).all()]
    students = (
        User.query.filter(User.id.in_(student_ids)).order_by(User.name.asc()).all()
        if student_ids else []
    )

    def _fmt_duration(sec):
        if not sec: return None
        m, s = divmod(int(sec), 60)
        return f"{m}분" if s == 0 else f"{m}분 {s}초"

    def _fmt_size(bytes_):
        if not bytes_: return None
        mb = bytes_ / (1024 * 1024)
        return f"{mb:.1f}MB"

    # 주차 계산 유틸
    def _current_week(course: Course, weeks_total: int) -> int:
        today = date.today()
        if course.start_date:
            if today < course.start_date:
                return 1
            diff_days = (today - course.start_date).days
            w = diff_days // 7 + 1
            if course.end_date:
                w = min(w, weeks_total)
            return max(1, min(weeks_total, w))
        return 1

    def _current_week_range_sun() -> tuple[date, date]:
        today = date.today()
        start = today - timedelta(days=(today.weekday() + 1) % 7)  # 일~토
        end = start + timedelta(days=6)
        return start, end

    weeks_total = _weeks_total(course)
    cur_week = _current_week(course, weeks_total)
    cur_start, cur_end = _current_week_range_sun()

    # 자료 로드 (게시된 것만)
    m_rows = (
        db.session.query(Material)
        .filter(Material.course_id == course.id, Material.is_published.is_(True))
        .order_by(Material.created_at.asc())
        .all()
    )

    def _infer_week_from_date(d: date, course: Course, weeks_total: int) -> int:
        if not course.start_date or not d:
            return 1
        diff_days = (d - course.start_date).days
        w = diff_days // 7 + 1
        return max(1, min(weeks_total, w))

    by_week = {}
    for r in m_rows:
        explicit_w = getattr(r, "week", None)
        avail_dt = getattr(r, "available_at", None)
        created_dt = getattr(r, "created_at", None)

        if explicit_w and isinstance(explicit_w, int) and explicit_w > 0:
            w = explicit_w
        else:
            basis = avail_dt or created_dt
            if hasattr(basis, "date"):
                basis = basis.date()
            w = _infer_week_from_date(basis, course, weeks_total)

        by_week.setdefault(w, [])
        by_week[w].append({
            "id": r.id,
            "week": w,
            "title": r.title,
            "duration": (lambda sec: (lambda m,s: f"{m}분" if s==0 else f"{m}분 {s}초")(*divmod(int(sec),60)) if sec else None)(getattr(r, "duration_seconds", None)),
            "size": (lambda b: f"{b/(1024*1024):.1f}MB" if b else None)(getattr(r, "size_bytes", None)),
            "download": bool(r.kind == "file" and getattr(r, "is_downloadable", False)),
            "kind": r.kind,
            "play_url": url_for("materials.play", material_id=r.id) if r.kind != "file" else None,
            "download_url": url_for("materials.download", material_id=r.id) if r.kind == "file" else None,
        })

    # ✅ 이번주 자료
    cur_list = list(by_week.get(cur_week, []))
    if not cur_list and by_week:
        # 1) 현재 주차 이하에서 가장 큰 주차
        le_keys = [k for k in by_week.keys() if isinstance(k, int) and k <= cur_week]
        if le_keys:
            cur_list = list(by_week.get(max(le_keys), []))
        # 2) 그래도 없으면 가장 최근 주차(최대 키)
        if not cur_list:
            int_keys = [k for k in by_week.keys() if isinstance(k, int)]
            if int_keys:
                cur_list = list(by_week.get(max(int_keys), []))

    # ===== 과제 =====
    assignments = (
        db.session.query(Assignment)
        .filter_by(course_id=course.id)
        .order_by(Assignment.due_at.is_(None), Assignment.due_at.asc())
        .all()
    )

    # ===== 공지 & 토론 (탭 선택 시에만 로드) =====
    notices = None
    discussion = None

    if tab == "notices":
        notices = (
            db.session.query(Notice)
            .filter(Notice.course_id == course.id)
            .order_by(Notice.is_pinned.desc(), Notice.created_at.desc())
            .all()
        )

    if tab == "discussion":
        # 댓글 수를 함께 가져오도록 서브쿼리 사용 (SQLAlchemy 1.4/2.x 호환)
        comments_cnt_sq = (
            db.session.query(func.count(DiscussionComment.id))
            .filter(DiscussionComment.thread_id == DiscussionThread.id)
            .correlate(DiscussionThread)
            .scalar_subquery()
        )
        rows = (
            db.session.query(
                DiscussionThread.id,
                DiscussionThread.title,
                DiscussionThread.updated_at,
                comments_cnt_sq.label("comments_cnt"),
            )
            .filter(DiscussionThread.course_id == course.id)
            .order_by(DiscussionThread.updated_at.desc(), DiscussionThread.id.desc())
            .all()
        )
        discussion = [{
            "id": r.id,
            "title": r.title,
            "comments": int(r.comments_cnt or 0),
            "updated": (r.updated_at.strftime("%Y-%m-%d %H:%M") if r.updated_at else "")
        } for r in rows]

    return render_template(
        "admin/course_detail.html",
        course=course,
        instructor_name=instr_name,
        tab=tab,
        students=students,
        weeks_total=weeks_total,
        cur_week=cur_week,
        cur_start=cur_start,
        cur_end=cur_end,
        materials_by_week=by_week,
        materials_this_week=cur_list,
        assignments=assignments,
        # ▼ 추가
        notices=notices,
        discussion=discussion,
    )

# --- (관리자) 주차별 완료 현황 ---
@bp.get("/admin/<int:course_id>/week/<int:w>", endpoint="admin_week_status")
@login_required
def admin_week_status(course_id: int, w: int):
    course = _require_course_staff(course_id)

    course = db.session.get(Course, course_id) or abort(404)
    if w <= 0:
        abort(400, description="주차는 1 이상이어야 합니다.")

    vids = (
        db.session.query(Material.id)
        .filter(
            Material.course_id == course.id,
            Material.is_published.is_(True),
            Material.week == w,
            Material.kind.in_(["video", "youtube"]),
        ).all()
    )
    material_ids = [mid for (mid,) in vids]
    total_cnt = len(material_ids)

    stu_ids = [e.user_id for e in Enrollment.query.filter(Enrollment.course_id == course.id).all()]
    students = (
        db.session.query(User.id, User.name, User.email, User.username)
        .filter(User.id.in_(stu_ids)).order_by(User.name.asc()).all()
        if stu_ids else []
    )

    if total_cnt == 0:
        status_rows = [{
            "user_id": s.id, "name": s.name, "email": s.email or s.username,
            "done": 0, "total": 0, "state": "-", "is_present": False,
        } for s in students]
        return render_template("admin/week_status.html", course=course, week=w, rows=status_rows, total=0)

    ev_rows = (
        db.session.query(MaterialEvent.user_id, MaterialEvent.material_id, MaterialEvent.action)
        .filter(MaterialEvent.material_id.in_(material_ids), MaterialEvent.user_id.in_(stu_ids)).all()
        if stu_ids else []
    )

    completed_map = {(u, m) for (u, m, a) in ev_rows if a == "complete"}
    played_map    = {(u, m) for (u, m, a) in ev_rows if a in ("play", "progress", "complete")}

    status_rows = []
    for s in students:
        done = sum(1 for mid in material_ids if (s.id, mid) in completed_map)
        any_play = any((s.id, mid) in played_map for mid in material_ids)
        is_present = any_play or (done > 0)
        if done == total_cnt and total_cnt > 0:
            state = "완료"
        elif is_present:
            state = "진행"
        else:
            state = "미시작"

        status_rows.append({
            "user_id": s.id, "name": s.name, "email": s.email or s.username,
            "done": done, "total": total_cnt, "state": state, "is_present": is_present,
        })

    order = {"완료": 0, "진행": 1, "미시작": 2, "-": 3}
    status_rows.sort(key=lambda r: (0 if r["is_present"] else 1, order.get(r["state"], 9), r["name"]))

    back_url = (
        url_for("courses.admin_detail", course_id=course.id, tab="materials")
        if _is_admin()
        else url_for("course_detail.detail", course_id=course.id, tab="materials")
    )
    return render_template(
        "admin/week_status.html",
        course=course, week=w, rows=status_rows, total=total_cnt,
        back_url=back_url,   # ★ 추가
    )

@bp.get("/admin/materials/<int:material_id>/players", endpoint="admin_material_players")
@login_required
def admin_material_players(material_id: int):
    m = db.session.get(Material, material_id) or abort(404)
    course = _require_course_staff(m.course_id)

    # 수강 학생
    stu_ids = [e.user_id for e in Enrollment.query.filter(Enrollment.course_id == course.id).all()]
    students = (
        db.session.query(User.id, User.name, User.email, User.username)
        .filter(User.id.in_(stu_ids)).order_by(User.name.asc()).all()
        if stu_ids else []
    )

    # 해당 자료의 재생 이벤트
    ev_rows = (
        db.session.query(MaterialEvent.user_id, MaterialEvent.action, MaterialEvent.created_at)
        .filter(MaterialEvent.material_id == m.id, MaterialEvent.user_id.in_(stu_ids)).all()
        if stu_ids else []
    )

    last_action = {}
    completed = set()
    played = set()
    for uid, action, ts in ev_rows:
        # 마지막 이벤트 기록
        prev = last_action.get(uid)
        if not prev or (ts and prev[1] and ts > prev[1]):
            last_action[uid] = (action, ts)
        if action in ("play", "progress", "complete"):
            played.add(uid)
        if action == "complete":
            completed.add(uid)

    # ✅ 주차 UI와 동일하게 쓰기 위해 done/total 채워 넣기 (자료 단건이므로 total=1 고정)
    rows = []
    for s in students:
        act, ts = last_action.get(s.id, (None, None))
        is_present = (s.id in played) or (s.id in completed)
        done = 1 if s.id in completed else 0
        total = 1
        state = "완료" if done == 1 else ("진행" if is_present else "미시작")
        rows.append({
            "user_id": s.id,
            "name": s.name,
            "email": s.email or s.username,
            "done": done,
            "total": total,
            "state": state,
            "is_present": is_present,
            "last_action": act or "-",
            "last_at": ts,
        })

    order = {"완료": 0, "진행": 1, "미시작": 2}
    rows.sort(key=lambda r: (0 if r["is_present"] else 1, order.get(r["state"], 9), r["name"]))

    back_url = (
        url_for("courses.admin_detail", course_id=course.id, tab="materials")
        if _is_admin()
        else url_for("course_detail.detail", course_id=course.id, tab="materials")
    )
    # total: 템플릿에서 “이 주차 영상 자료 없음” 문구 제어에 쓰이니 자료 단건 페이지에선 1로 넘겨줘도 무방
    return render_template(
        "admin/material_players.html",
        course=course,
        material=m,
        rows=rows,
        total=1,
        back_url=back_url,
    )

# ----- (관리자) 공지 목록/상세 (조회 + 첨부 다운로드만) -----
@bp.get("/admin/<int:course_id>/notices", endpoint="admin_notices")
@login_required
def admin_notices(course_id: int):
    _admin_required()
    course = db.session.get(Course, course_id) or abort(404)
    rows = (
        db.session.query(Notice)
        .filter(Notice.course_id == course.id)
        .order_by(Notice.is_pinned.desc(), Notice.created_at.desc())
        .all()
    )
    return render_template("admin/notices.html", mode="list", course=course, rows=rows)

@bp.get("/admin/<int:course_id>/notices/<int:nid>", endpoint="admin_notice_view")
@login_required
def admin_notice_view(course_id: int, nid: int):
    _admin_required()
    course = db.session.get(Course, course_id) or abort(404)
    n = db.session.get(Notice, nid) or abort(404)
    if n.course_id != course.id:
        abort(404)

    # ✅ 공지의 다중 첨부 조회 (CourseAttachment)
    ca_list = (
        db.session.query(CourseAttachment)
        .filter(
            CourseAttachment.course_id == course.id,
            CourseAttachment.parent_kind == "notice",
            CourseAttachment.parent_id == n.id,
        )
        .order_by(CourseAttachment.created_at.asc())
        .all()
    )

    return render_template(
        "admin/notices.html",
        mode="view",
        n=n,
        course=course,
        ca_list=ca_list,  # ★ 템플릿으로 전달
        # 공지사항 탭으로 돌아가는 링크
        back_url=url_for("courses.admin_detail", course_id=course.id, tab="notices"),
    )

# ----- (관리자) 토론 상세 (읽기 전용) -----
def _build_comment_tree_simple(thread_id: int):
    """대댓글 트리 헬퍼: 중첩 고려 안 하거나 parent_id 기반 가벼운 트리 구성."""
    rows = (
        db.session.query(DiscussionComment)
        .filter(DiscussionComment.thread_id == thread_id)
        .order_by(DiscussionComment.parent_id.is_(None).desc(), DiscussionComment.created_at.asc())
        .all()
    )
    # 간단 트리: parent_id 기준으로 children 묶기
    by_id = {}
    roots = []
    for c in rows:
        node = {"c": c, "children": []}
        by_id[c.id] = node
    for c in rows:
        node = by_id[c.id]
        if getattr(c, "parent_id", None):
            parent = by_id.get(c.parent_id)
            if parent:
                parent["children"].append(node)
            else:
                roots.append(node)
        else:
            roots.append(node)
    return roots

@bp.get("/admin/<int:course_id>/discussion/<int:tid>", endpoint="admin_discussion_view")
@login_required
def admin_discussion_view(course_id: int, tid: int):
    _admin_required()
    course = db.session.get(Course, course_id) or abort(404)
    thread = db.session.get(DiscussionThread, tid) or abort(404)
    if thread.course_id != course.id:
        abort(404)

    tree = _build_comment_tree_simple(thread.id)
    total_comments = sum(1 for _ in db.session.query(DiscussionComment.id).filter_by(thread_id=thread.id))

    return render_template(
        "admin/discussion_view.html",
        thread=thread, tree=tree,
        total_comments=total_comments,
        back_url=url_for("courses.admin_detail", course_id=course.id, tab="discussion"),
    )


# ----- 관리자: 과제 제출자/파일 다운로드 목록 -----
@bp.get("/admin/<int:course_id>/assignment/<int:aid>/submissions", endpoint="admin_assignment_submissions")
@login_required
def admin_assignment_submissions(course_id: int, aid: int):
    _admin_required()

    course = db.session.get(Course, course_id) or abort(404)
    a = db.session.get(Assignment, aid) or abort(404)
    if a.course_id != course.id:
        abort(404)

    # ---- 과제 설명 / 단일 첨부(Blob/URL/Path) ----
    assignment_desc = getattr(a, "description", None) or getattr(a, "content", None) or ""

    has_blob = bool(getattr(a, "attachment_data", None))
    has_url  = bool(getattr(a, "file_url", None))
    has_path = bool(getattr(a, "file_path", None))
    assignment_has_attachment = has_blob or has_url or has_path

    # 표시용 파일명 (있으면)
    assignment_file_name = (
        getattr(a, "attachment_name", None)
        or (os.path.basename(a.file_url) if has_url else None)
        or (os.path.basename(a.file_path) if has_path else None)
    )

    # 단일 첨부 다운로드 URL (Blob/URL/Path 모두 이 엔드포인트로)
    assignment_download_url = (
        url_for("course_detail.assignments_download", aid=a.id)
        if assignment_has_attachment else None
    )

    # ---- 다중 첨부 (CourseAttachment) ----
    try:
        # 가장 정상적인 스키마(권장)
        ca_list = (
            db.session.query(CourseAttachment)
            .filter(
                CourseAttachment.course_id == course.id,
                CourseAttachment.parent_kind == "assignment",
                CourseAttachment.parent_id == a.id,
            )
            .order_by(CourseAttachment.created_at.asc())
            .all()
        )
    except Exception:
        # 프로젝트별 스키마가 다르면 폴백 헬퍼로
        ca_list = _load_assignment_attachments(a.id)

    # ---- 수강생 / 제출 목록 ----
    enrolled_users = (
        db.session.query(User)
        .join(Enrollment, Enrollment.user_id == User.id)
        .filter(Enrollment.course_id == course.id)
        .all()
    )

    submissions = (
        db.session.query(Submission)
        .options(joinedload(Submission.user))
        .filter(Submission.assignment_id == a.id)
        .order_by(Submission.submitted_at.is_(None), Submission.submitted_at.desc())
        .all()
    )

    submitted_user_ids = {s.user_id for s in submissions if s.user_id}
    not_submitted = [u for u in enrolled_users if u.id not in submitted_user_ids]

    submitted_cnt = len(submitted_user_ids)
    total_cnt = len(enrolled_users)
    pending_cnt = len(not_submitted)
    edit_mode = (request.args.get("edit") == "1")

    return render_template(
        "admin/assignment_submissions.html",
        course=course,
        assignment=a,
        assignment_desc=assignment_desc,
        # 단일 첨부 표시용
        assignment_has_attachment=assignment_has_attachment,
        assignment_file_name=assignment_file_name,
        assignment_download_url=assignment_download_url,
        # 다중 첨부 목록
        ca_list=ca_list or [],
        # 제출 현황
        submissions=submissions,
        not_submitted=not_submitted,
        submitted=submitted_cnt,
        total=total_cnt,
        pending=pending_cnt,
        edit_mode=edit_mode,
    )


@bp.get("/admin/submission/<int:sid>/download", endpoint="admin_submission_redirect")
@login_required
def admin_submission_redirect(sid: int):
    _admin_required()

    sub = db.session.get(Submission, sid) or abort(404)
    a = db.session.get(Assignment, sub.assignment_id) or abort(404)
    course = db.session.get(Course, a.course_id) or abort(404)

    # 우선순위: 직접 URL(외부/사내 저장소) → 내부 업로드 엔드포인트
    url = getattr(sub, "file_url", None) or getattr(sub, "storage_url", None)
    if url:
        return redirect(url)

    rel = getattr(sub, "file_path", None)
    if rel:
        # 내부 업로더가 제공하는 파일 서빙 라우트(프로젝트 표준)
        return redirect(url_for("uploads.file", relpath=rel, dl=1))

    abort(404, description="제출 파일을 찾을 수 없습니다.")

# ----- 관리자: 강좌 삭제 -----
@bp.post("/admin/<int:course_id>/delete", endpoint="admin_delete")
@login_required
def admin_delete(course_id: int):
    _admin_required()

    course = db.session.get(Course, course_id) or abort(404)

    confirm = (request.form.get("confirm") or "").strip()
    require_confirm = False
    if require_confirm and confirm != course.title:
        abort(400, description="삭제 확인 텍스트가 일치하지 않습니다.")

    from models import Notice, DiscussionThread, DiscussionComment

    material_ids = [mid for (mid,) in db.session.query(Material.id).filter_by(course_id=course.id).all()]
    assignment_ids = [aid for (aid,) in db.session.query(Assignment.id).filter_by(course_id=course.id).all()]
    thread_ids = [tid for (tid,) in db.session.query(DiscussionThread.id).filter_by(course_id=course.id).all()]

    if material_ids:
        db.session.query(MaterialEvent).filter(MaterialEvent.material_id.in_(material_ids)).delete(synchronize_session=False)
    if assignment_ids:
        db.session.query(Submission).filter(Submission.assignment_id.in_(assignment_ids)).delete(synchronize_session=False)
    if thread_ids:
        db.session.query(DiscussionComment).filter(DiscussionComment.thread_id.in_(thread_ids)).delete(synchronize_session=False)

    db.session.query(Material).filter(Material.id.in_(material_ids)).delete(synchronize_session=False)
    db.session.query(Assignment).filter(Assignment.id.in_(assignment_ids)).delete(synchronize_session=False)
    db.session.query(Notice).filter(Notice.course_id == course.id).delete(synchronize_session=False)
    db.session.query(DiscussionThread).filter(DiscussionThread.id.in_(thread_ids)).delete(synchronize_session=False)
    db.session.query(Enrollment).filter(Enrollment.course_id == course.id).delete(synchronize_session=False)

    db.session.delete(course)
    db.session.commit()
    return redirect(url_for("courses.admin_list"))