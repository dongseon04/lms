# blueprints/materials/routes.py
from __future__ import annotations
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from flask import Blueprint, abort, redirect, render_template, url_for, request
from helpers.auth import login_required
from models import db, Material, MaterialEvent, Enrollment

bp = Blueprint("materials", __name__, url_prefix="/materials")


def _can_access(material: Material, user) -> bool:
    # 관리자/교수는 통과, 학생은 수강 여부 체크
    if getattr(user, "role", None) in ("admin", "instructor"):
        return True
    ok = db.session.query(Enrollment.id).filter_by(
        user_id=user.id, course_id=material.course_id
    ).first()
    return bool(ok)


def _src_url(material: Material) -> str | None:
    # 외부/스트리밍 우선
    if material.storage_url:
        return material.storage_url
    # 로컬 파일이면 업로드 라우트로
    if material.file_path:
        return url_for("uploads.file", relpath=material.file_path)
    return None


# 유튜브 URL을 embed용으로 변환
def _youtube_embed(url: str) -> str | None:
    if not url:
        return None
    u = urlparse(url)
    host = (u.netloc or "").lower()
    path = (u.path or "").strip("/")

    vid = None
    if "youtube.com" in host:
        if path.startswith("watch"):
            vid = parse_qs(u.query).get("v", [None])[0]
        elif path.startswith("shorts/"):
            vid = path.split("/", 1)[1]
        elif path.startswith("embed/"):
            # 이미 embed 링크면 그대로 사용
            return url
    elif "youtu.be" in host:
        vid = path.split("/")[0]

    if not vid:
        return None

    # 시작 시각 지원: ?start= / ?t=
    q = parse_qs(u.query)
    start = None
    if "start" in q:
        start = q["start"][0]
    elif "t" in q:
        t = q["t"][0]
        try:
            if t.endswith("s"):
                t = t[:-1]
            if "m" in t:
                m, s = t.split("m", 1)
                start = str(int(m) * 60 + int(s or 0))
            else:
                start = str(int(t))
        except Exception:
            start = None

    base = f"https://www.youtube.com/embed/{vid}?rel=0&modestbranding=1&playsinline=1"
    if start:
        base += f"&start={start}"
    return base


@bp.get("/<int:material_id>/play")
@login_required
def play(material_id: int):
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)
    if m.kind == "file":
        abort(400, description="파일 자료는 재생 대상이 아닙니다.")

    # 로그: play
    db.session.add(MaterialEvent(user_id=g.user.id, material_id=m.id, action="play"))
    db.session.commit()

    src = _src_url(m) or abort(404, description="재생 소스를 찾을 수 없습니다.")
    embed = _youtube_embed(src)

    # ✅ 유튜브면 JS API 강제활성 + origin 부여
    if embed:
        u = urlparse(embed)
        q = parse_qs(u.query)
        q["enablejsapi"] = ["1"]
        q["origin"] = [request.host_url.rstrip("/")]
        embed = urlunparse(
            (u.scheme, u.netloc, u.path, u.params, urlencode(q, doseq=True), u.fragment)
        )

    back_url = url_for("course_detail.detail", course_id=m.course_id, tab="materials")
    return render_template(
        "material_play.html",
        title=m.title,
        src=src,
        embed=embed,
        material=m,
        back_url=back_url,
    )


@bp.post("/<int:material_id>/complete")
@login_required
def complete(material_id: int):
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    seconds = None
    if request.is_json:
        seconds = int(request.json.get("sec") or 0) or None
    else:
        seconds = int(request.form.get("sec") or 0) or None

    db.session.add(
        MaterialEvent(
            user_id=g.user.id,
            material_id=m.id,
            action="complete",
            seconds_watched=seconds,
        )
    )
    db.session.commit()
    return ("", 204)


@bp.get("/<int:material_id>/download")
@login_required
def download(material_id: int):
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)
    if not (m.kind == "file" and m.is_downloadable):
        abort(403, description="다운로드가 허용되지 않은 자료입니다.")

    # 로그: download
    db.session.add(MaterialEvent(user_id=g.user.id, material_id=m.id, action="download"))
    db.session.commit()

    if m.storage_url:
        return redirect(m.storage_url)
    if m.file_path:
        return redirect(url_for("uploads.file", relpath=m.file_path, dl=1))
    abort(404, description="다운로드 대상을 찾을 수 없습니다.")
