# blueprints/notices/routes.py
from __future__ import annotations
from flask import Blueprint, render_template, request, abort, url_for, g
from helpers.auth import login_required
from models import db, Notice, Enrollment, Course

bp = Blueprint("notices", __name__, url_prefix="/notices")

def _can_view(course_id: int, user) -> bool:
    # 관리자/교수는 통과
    if getattr(user, "role", None) in ("admin", "instructor"):
        return True
    # 수강생이면 해당 과목 수강 여부 검사
    ok = db.session.query(Enrollment.id).filter_by(user_id=user.id, course_id=course_id).first()
    return bool(ok)

@bp.get("/", endpoint="home")
@login_required
def home():
    """
    코스별 공지 목록.
    접근: /notices?course_id=<코스ID>
    """
    cid = request.args.get("course_id", type=int)
    if not cid:
        abort(400, description="course_id가 필요합니다.")
    course = db.session.get(Course, cid) or abort(404)

    if not _can_view(course.id, g.user):
        abort(403)

    rows = (
        db.session.query(Notice)
        .filter(Notice.course_id == course.id)
        .order_by(Notice.is_pinned.desc(), Notice.created_at.desc())
        .all()
    )
    # ✅ 단일 템플릿 사용: notices.html
    return render_template("notices.html", course=course, rows=rows, mode="list")

@bp.get("/<int:nid>", endpoint="view")
@login_required
def view(nid: int):
    """
    공지 상세
    """
    n = db.session.get(Notice, nid) or abort(404)
    if not _can_view(n.course_id, g.user):
        abort(403)

    # 뒤로가기 주소: ?back= 우선, 없으면 해당 강좌 공지 탭으로
    back_url = request.args.get("back") or url_for(
        "course_detail.detail", course_id=n.course_id, tab="notices"
    )
    # ✅ 단일 템플릿 사용: notices.html
    return render_template("notices.html", n=n, back_url=back_url, mode="view")
