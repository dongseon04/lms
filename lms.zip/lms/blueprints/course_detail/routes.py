# blueprints/course_detail/routes.py
from __future__ import annotations

import math
from collections import defaultdict
from datetime import datetime, date, timedelta, timezone

from flask import Blueprint, render_template, request, abort, g, url_for
from sqlalchemy import func

from helpers.auth import login_required
from models import (
    db,
    Course,
    Assignment,
    Submission,
    Enrollment,
    Material,
    MaterialEvent,
    Notice,
    DiscussionThread,
    DiscussionComment,
)

bp = Blueprint("course_detail", __name__, url_prefix="/course")

# 한국 표준시
KST = timezone(timedelta(hours=9))


def _ensure_enrolled(uid: int, course_id: int):
    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=course_id).first()
    if not ok:
        abort(403)


def _fmt_duration(sec: int | None) -> str | None:
    if not sec:
        return None
    m, s = divmod(int(sec), 60)
    return f"{m}분" if s == 0 else f"{m}분 {s}초"


def _fmt_size(bytes_: int | None) -> str | None:
    if not bytes_:
        return None
    mb = bytes_ / (1024 * 1024)
    return f"{mb:.1f}MB"


def _weeks_total(course: Course) -> int:
    """강좌 총 주차."""
    # 1) 강좌 기간이 있으면 기간으로 계산
    if course.start_date and course.end_date:
        days = (course.end_date - course.start_date).days + 1
        return max(1, math.ceil(days / 7))
    # 2) 아니면 자료의 최대 주차 또는 15주 기본
    w = db.session.query(func.max(Material.week)).filter(Material.course_id == course.id).scalar()
    return int(w or 15)


def current_week_range(tz=KST, week_start: str = "sun") -> tuple[date, date]:
    """현재 날짜 기준 이번주(일~토 or 월~일) 시작/끝 날짜 반환."""
    today = datetime.now(tz).date()
    if week_start == "sun":
        # 월(0)~일(6) → 일요일 시작으로 보정
        start = today - timedelta(days=(today.weekday() + 1) % 7)
    else:
        # 월요일 시작
        start = today - timedelta(days=today.weekday())
    end = start + timedelta(days=6)
    return start, end


def _week_range(course: Course, w: int) -> tuple[date | None, date | None]:
    """강좌 시작일 기준 w주차의 시작/끝 날짜(강좌에 start_date가 있을 때만)."""
    if not course.start_date:
        return None, None
    start = course.start_date + timedelta(days=7 * (w - 1))
    end = start + timedelta(days=6)
    return start, end


def _current_week(course: Course, *, weeks_total: int) -> int:
    """현재 날짜 기준 강좌의 '현재 주차' (start_date 기반, 범위 1..weeks_total)."""
    today = datetime.now(KST).date()
    if course.start_date:
        if today < course.start_date:
            return 1
        diff_days = (today - course.start_date).days
        w = diff_days // 7 + 1
        if course.end_date:
            # 강좌 종료 이후에는 마지막 주차로 고정
            w = min(w, weeks_total)
        return max(1, min(weeks_total, w))
    # 시작일이 없으면 1주차로
    return 1


@bp.get("/<int:course_id>", endpoint="detail")
@login_required
def detail(course_id: int):
    uid = g.user.id
    tab = (request.args.get("tab") or "materials").strip().lower()
    if tab not in {"materials", "assignments", "notices", "discussion"}:
        tab = "materials"

    course = db.session.get(Course, course_id)
    if not course:
        abort(404, description="강좌를 찾을 수 없습니다.")
    _ensure_enrolled(uid, course.id)

    # -----------------------------
    # 진행률(과제 기준)
    # -----------------------------
    total = db.session.query(Assignment).filter_by(course_id=course.id).count()
    submitted = (
        db.session.query(Submission)
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .filter(
            Submission.user_id == uid,
            Assignment.course_id == course.id,
            Submission.submitted_at.isnot(None),
        )
        .count()
    )
    progress_pct = int((submitted / total) * 100) if total else 0

    # 과제 + 내 제출맵
    assignments = (
        db.session.query(Assignment)
        .filter_by(course_id=course.id)
        .order_by(Assignment.due_at.is_(None), Assignment.due_at.asc())
        .all()
    )
    subs = (
        db.session.query(Submission)
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .filter(Submission.user_id == uid, Assignment.course_id == course.id)
        .all()
    )
    sub_map = {s.assignment_id: s for s in subs}

    # -----------------------------
    # 자료(주차별) + 내 이벤트
    # -----------------------------
    m_rows = (
        db.session.query(Material)
        .filter(Material.course_id == course.id, Material.is_published.is_(True))
        .order_by(Material.week.is_(None), Material.week.asc(), Material.created_at.desc())
        .all()
    )
    mat_ids = [m.id for m in m_rows]
    played: set[int] = set()
    completed: set[int] = set()
    if mat_ids:
        for mid, action in (
            db.session.query(MaterialEvent.material_id, MaterialEvent.action)
            .filter(MaterialEvent.user_id == uid, MaterialEvent.material_id.in_(mat_ids))
            .all()
        ):
            if action == "play":
                played.add(mid)
            elif action == "complete":
                completed.add(mid)

    # 주차 그룹
    by_week: dict[int, list[dict]] = defaultdict(list)
    for r in m_rows:
        acts_done = "complete" if r.id in completed else ("play" if r.id in played else None)
        status = "완료" if acts_done == "complete" else ("진행중" if acts_done == "play" else "대기")
        item = {
            "id": r.id,
            "week": r.week or 0,
            "title": r.title,
            "duration": _fmt_duration(r.duration_seconds),
            "size": _fmt_size(r.size_bytes),
            "download": bool(r.kind == "file" and r.is_downloadable),
            "status": status,
            "kind": r.kind,
            "play_url": url_for("materials.play", material_id=r.id) if r.kind != "file" else None,
            "download_url": url_for("materials.download", material_id=r.id) if r.kind == "file" else None,
        }
        by_week[r.week or 0].append(item)

    # -----------------------------
    # 주차 개수/현재 주차 & 이번주 날짜
    # -----------------------------
    weeks_total = _weeks_total(course)
    cur_week = _current_week(course, weeks_total=weeks_total)

    # 화면에 보여줄 "이번주" 날짜는 시스템 현재주(일~토)로 표시
    cur_start, cur_end = current_week_range(week_start="sun")

    # -----------------------------
    # 주차별 진행 요약(원형칩 상태)
    # -----------------------------
    week_status = []
    for w in range(1, weeks_total + 1):
        lst = by_week.get(w, [])
        total_cnt = len(lst)
        done_cnt = sum(1 for it in lst if it["status"] == "완료")
        if total_cnt == 0:
            state = "-"
        elif done_cnt == 0:
            state = "대기"
        elif done_cnt == total_cnt:
            state = "완료"
        else:
            state = "진행"
        week_status.append(
            {
                "week": w,
                "total": total_cnt,
                "done": done_cnt,
                "state": state,
                "href": url_for("course_detail.detail", course_id=course.id, tab="materials") + f"#w{w}",
            }
        )

    # -----------------------------
    # 공지
    # -----------------------------
    notices = (
        db.session.query(Notice)
        .filter(Notice.course_id == course.id)
        .order_by(Notice.is_pinned.desc(), Notice.created_at.desc())
        .all()
    )

    # -----------------------------
    # 토론 (스레드 목록 + 댓글수/업데이트시각)
    # -----------------------------
    threads = (
        db.session.query(DiscussionThread)
        .filter(DiscussionThread.course_id == course.id)
        .order_by(DiscussionThread.updated_at.desc())
        .all()
    )

    discussion = []
    for t in threads:
        cnt = db.session.query(func.count(DiscussionComment.id)).filter_by(thread_id=t.id).scalar()
        latest = (
            db.session.query(func.max(DiscussionComment.created_at))
            .filter(DiscussionComment.thread_id == t.id)
            .scalar()
        ) or t.updated_at
        discussion.append({
            "id": t.id,
            "title": t.title,
            "comments": int(cnt or 0),
            "updated": latest.strftime("%Y-%m-%d %H:%M"),
        })

    # -----------------------------
    # 렌더
    # -----------------------------
    return render_template(
        "course_detail.html",
        course=course,
        tab=tab,
        progress_pct=progress_pct,
        assignments=assignments,
        sub_map=sub_map,
        # 주차/진도/자료 컨텍스트
        cur_week=cur_week,
        cur_start=cur_start,
        cur_end=cur_end,
        weeks_total=weeks_total,
        week_status=week_status,
        materials_by_week=by_week,
        # 공지/토론
        notices=notices,
        discussion=discussion,
    )
