# config.py — 환경설정(보강판)
import os
from urllib.parse import quote_plus

class Config:
    # --- DB ---
    # 특수문자 있는 비밀번호는 DSN에 직접 쓰지 말고 안전하게 구성하는 방법(선택):
    # user = os.getenv("DB_USER", "wsuser")
    # pwd  = quote_plus(os.getenv("DB_PASS", "wsuser!"))  # !,@,: 등 인코딩
    # host = os.getenv("DB_HOST", "127.0.0.1")
    # port = os.getenv("DB_PORT", "3306")
    # name = os.getenv("DB_NAME", "lms_db")
    # SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{user}:{pwd}@{host}:{port}/{name}?charset=utf8mb4"

    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "SQLALCHEMY_DATABASE_URI",
        "mysql+pymysql://root:root1234@127.0.0.1:3306/lms_db?charset=utf8mb4",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # 연결 안정화(권장)
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 1800,   # 30분마다 재연결(“MySQL server has gone away” 예방)
        "pool_size": 5,
        "max_overflow": 10,
    }

    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "dev-secret")

    # --- 경로 ---
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    UPLOAD_ROOT = os.path.join(BASE_DIR, "uploads")
    MATERIALS_DIR = os.path.join(UPLOAD_ROOT, "materials")

    UPLOAD_DIR = UPLOAD_ROOT 

    # 최초 실행 시 폴더 없으면 만들어두는 게 안전 (app.py에서도 한 번 더 보장)
    os.makedirs(UPLOAD_ROOT, exist_ok=True)
    os.makedirs(MATERIALS_DIR, exist_ok=True)

    # --- 업로드 정책 ---
    # 파일류
    ALLOWED_EXTS = {
        "pdf","zip","doc","docx","ppt","pptx","xlsx","csv","ipynb","py","txt","md","rar",
        "jpg","jpeg","png","gif"
    }
    # 영상류 (재생/업로드용)
    ALLOWED_VIDEO_EXTS = {"mp4", "webm", "mov", "m4v"}
    # 최대 업로드 용량(예: 512MB) — 필요 시 조정
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_MB", "512")) * 1024 * 1024

    # 데모 사용자(미로그인 시 g.user 바인딩 대비)
    DEMO_USER_ID = int(os.environ.get("DEMO_USER_ID", 1))

    # --- 표시 포맷/품질 ---
    JSON_AS_ASCII = False
    TEMPLATES_AUTO_RELOAD = True              # 개발 편의
    SEND_FILE_MAX_AGE_DEFAULT = 3600          # 파일 캐시(1h) — 운영에서 CDN/NGINX 권장

    # --- 쿠키/세션(운영에선 Secure로) ---
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "0") == "1"

    # --- 날짜 포맷 ---
    DATE_ONLY = "%Y-%m-%d"
    DATE_HM = "%Y-%m-%d %H:%M"
    DATE_T = "%Y-%m-%dT%H:%M"
