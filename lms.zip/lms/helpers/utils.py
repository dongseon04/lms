# helpers/utils.py — 업로드/날짜파싱/Jinja 필터 (현행 구조)
from __future__ import annotations

import os
import time
from datetime import datetime, date
from typing import Optional

from flask import Flask, current_app, has_app_context
from werkzeug.utils import secure_filename

# ------------------------------------------------------------
# 내부 유틸
# ------------------------------------------------------------
def _allowed(filename: str) -> bool:
    """허용 확장자 체크 (app.config['ALLOWED_EXTS'])"""
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[-1].lower()
    exts = set()
    if has_app_context():
        exts = set(e.lower() for e in current_app.config.get("ALLOWED_EXTS", set()))
    return ext in exts

def _upload_root() -> str:
    """업로드 루트 (app.config['UPLOAD_ROOT'])"""
    if not has_app_context():
        raise RuntimeError("No Flask app context; UPLOAD_ROOT is unavailable.")
    root = current_app.config["UPLOAD_ROOT"]
    os.makedirs(root, exist_ok=True)
    return root

# ------------------------------------------------------------
# 날짜 파싱
# ------------------------------------------------------------
def parse_dt(s: Optional[str]) -> Optional[datetime]:
    """app 설정 포맷(DATE_T/DATE_HM/DATE_ONLY) 우선, 기본 포맷 보조"""
    if not s:
        return None

    fmts: list[str] = []
    if has_app_context():
        fmts.extend(
            [
                current_app.config.get("DATE_T"),
                current_app.config.get("DATE_HM"),
                current_app.config.get("DATE_ONLY"),
            ]
        )
    # fallback
    fmts.extend(
        [
            "%Y-%m-%dT%H:%M",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
        ]
    )

    for fmt in [f for f in fmts if f]:
        try:
            dt = datetime.strptime(s, fmt)
            # DATE_ONLY일 수 있으니 시/분 기본값 보정
            if fmt.endswith("%Y-%m-%d"):
                dt = dt.replace(hour=0, minute=0)
            return dt
        except Exception:
            continue
    return None

# ------------------------------------------------------------
# 업로드 저장 (현재 구조 전용)
#   - 저장 위치: UPLOAD_ROOT / <prefix?> / <timestamp>_<filename>
#   - 반환값   : UPLOAD_ROOT 기준 상대경로 (예: "assignments/3/u5/1700000000_xxx.pdf")
#                => 템플릿/뷰에서 url_for('uploads.file', relpath=리턴값, dl=1) 로 접근
# ------------------------------------------------------------
def _save_upload(file_storage, prefix: Optional[str] = None) -> Optional[str]:
    """
    file_storage: request.files[...] 항목
    prefix     : 하위 디렉토리 경로 (예: 'assignments/3/u5')
    """
    if not file_storage or not getattr(file_storage, "filename", None):
        return None
    if not _allowed(file_storage.filename):
        return None

    root = _upload_root()

    # 저장 디렉토리
    save_dir = root
    if prefix:
        save_dir = os.path.join(root, prefix)
    os.makedirs(save_dir, exist_ok=True)

    # 파일명
    orig = secure_filename(file_storage.filename)
    stamped = f"{int(time.time())}_{orig}"
    abs_path = os.path.join(save_dir, stamped)

    file_storage.save(abs_path)

    # UPLOAD_ROOT 기준 상대경로 반환
    rel_path = os.path.relpath(abs_path, root).replace("\\", "/")
    return rel_path

# 레거시 별칭(호환)
save_upload = _save_upload
_parse_dt = parse_dt

# ------------------------------------------------------------
# Jinja 필터
# ------------------------------------------------------------
def register_jinja_filters(app: Flask) -> None:
    @app.template_filter("timeago_kr")
    def timeago_kr(dt):
        if not dt:
            return ""
        now = datetime.utcnow()
        diff = now - dt
        s = int(diff.total_seconds())
        if s < 60:
            return f"{s}초 전" if s > 0 else "방금"
        m = s // 60
        if m < 60:
            return f"{m}분 전"
        h = m // 60
        if h < 24:
            return f"{h}시간 전"
        d = h // 24
        return f"{d}일 전"

    @app.template_filter("dt_kr")
    def dt_kr(v, fmt: str = "%Y-%m-%d %H:%M"):
        if v is None:
            return ""
        try:
            if isinstance(v, (datetime, date)):
                return v.strftime(fmt)
            return str(v)
        except Exception:
            return ""

    @app.template_filter("ymd_kr")
    def ymd_kr(v):
        return dt_kr(v, "%Y-%m-%d")

    @app.template_filter("ymd_hm_kr")
    def ymd_hm_kr(v):
        return dt_kr(v, "%Y-%m-%d %H:%M")
