# app.py — 앱 팩토리 + 블루프린트 등록
from flask import Flask, redirect, url_for, request, session
from config import Config
from extensions import db
from helpers.utils import register_jinja_filters
from helpers.context import register_context_hooks

# 블루프린트 import
from blueprints.auth.routes import bp as auth_bp
from blueprints.dashboard.routes import bp as dashboard_bp
from blueprints.courses.routes import bp as courses_bp
from blueprints.course_detail.routes import bp as course_detail_bp
from blueprints.mentoring.routes import bp as mentoring_bp
from blueprints.users.routes import bp as users_bp
from blueprints.analytics.routes import bp as analytics_bp
from blueprints.messages.routes import bp as messages_bp
from blueprints.schedule.routes import bp as schedule_bp
from blueprints.assignments.routes import bp as assignments_view_bp
from blueprints.grades.routes import bp as grades_bp
from blueprints.profile.routes import bp as profile_bp
from blueprints.settings.routes import bp as settings_bp
from blueprints.discussion.routes import bp as discussion_bp

# 재생/다운로드 & 업로드 서빙 블루프린트
from blueprints.materials.routes import bp as materials_bp           # /materials/<id>/play|download|complete
# (교수 업로드 화면을 쓰는 경우만)
# from blueprints.materials.admin_routes import bp as materials_admin_bp
from blueprints.uploads.routes import bp as uploads_bp               # /u/<path>
from blueprints.notices.routes import bp as notices_bp

def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(Config)

    # 확장 초기화
    db.init_app(app)

    # 업로드 폴더 보장
    import os
    os.makedirs(app.config["UPLOAD_ROOT"], exist_ok=True)
    os.makedirs(app.config["MATERIALS_DIR"], exist_ok=True)

    # Jinja 필터/컨텍스트
    register_jinja_filters(app)
    register_context_hooks(app)

    # 1) 로그인/인증 블루프린트 먼저
    app.register_blueprint(auth_bp)

    # 2) 자료/업로드 라우트
    app.register_blueprint(uploads_bp)     # /u/<path>
    app.register_blueprint(materials_bp)
    # app.register_blueprint(materials_admin_bp)  # (선택) 교수 업로드 화면

    # 3) 나머지 기능
    app.register_blueprint(dashboard_bp)          # "/" (대시보드)
    app.register_blueprint(courses_bp)
    app.register_blueprint(course_detail_bp)
    app.register_blueprint(mentoring_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(messages_bp)
    app.register_blueprint(schedule_bp)
    app.register_blueprint(assignments_view_bp)
    app.register_blueprint(grades_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(notices_bp)
    app.register_blueprint(discussion_bp)

    # 루트 접근 시: 로그인 여부에 따라 분기
    @app.route("/")
    def _root_redirect():
        if session.get("uid"):
            return redirect(url_for("dashboard.home"))
        return redirect(url_for("auth.home"))

    # 전역 가드: auth.* / static 제외 모두 로그인 필요
    @app.before_request
    def _require_login_globally():
        if request.endpoint == "static":
            return
        allowed = {
            "auth.home",
            "auth.login_post",
            "auth.logout_get",
            "auth.logout",
            "auth.init_demo",
        }
        ep = (request.endpoint or "").strip()
        if ep in allowed or ep.startswith("auth."):
            return
        if not session.get("uid"):
            nxt = request.full_path if request.query_string else request.path
            return redirect(url_for("auth.home", next=nxt))

    # 🔒 YouTube 임베드 허용 헤더(CSP) + X-Frame-Options 제거
    @app.after_request
    def _add_embed_headers(resp):
        if 'X-Frame-Options' in resp.headers:
            del resp.headers['X-Frame-Options']
        csp = (
            "default-src 'self'; "
            "frame-src 'self' https://www.youtube.com https://www.youtube-nocookie.com; "
            "img-src 'self' data: https://i.ytimg.com; "
            "script-src 'self' 'unsafe-inline' https://www.youtube.com https://www.gstatic.com; "
            "style-src 'self' 'unsafe-inline'; "
            "media-src 'self' blob: https://*; "
            "connect-src 'self'; "
        )
        resp.headers.setdefault("Content-Security-Policy", csp)
        return resp

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5004, use_reloader=False)
