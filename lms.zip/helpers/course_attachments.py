# helpers/course_attachments.py
import os, mimetypes
from hashlib import md5
from models import db, CourseAttachment

def save_many_course_attachments(files, *, course_id: int, parent_kind: str, parent_id: int | None):
    if not files:
        return 0
    saved = 0
    for fs in files:
        if not fs or not getattr(fs, "filename", ""):
            continue
        try:
            fs.stream.seek(0)
        except Exception:
            pass
        data = fs.read()
        if not data:
            continue
        att = CourseAttachment(
            course_id=course_id,
            parent_kind=parent_kind,       # 'assignment' | 'notice' | 'course'
            parent_id=parent_id,           # 과제ID/공지ID/None
            filename=os.path.basename(fs.filename),
            mime=fs.mimetype or mimetypes.guess_type(fs.filename)[0] or "application/octet-stream",
            size=len(data),
            md5=md5(data).hexdigest(),
            data=data,
        )
        db.session.add(att)
        saved += 1
    return saved

