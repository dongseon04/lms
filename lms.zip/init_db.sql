-- 0) 데이터베이스 및 세션 설정
CREATE DATABASE IF NOT EXISTS lms_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;
USE lms_db;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

/* ============================================================================
-- 1) 드롭(자식 → 부모 순서)
============================================================================ */
DROP TABLE IF EXISTS
  attendance_audits,
  attendance_records,
  attendance_detections,
  attendance_sessions,
  user_markers,
  project_task_files,
  project_tasks,
  projects,
  mentoring_reports,
  mentoring_team_members,
  mentoring_teams,
  discussion_comment_likes,
  discussion_comments,
  discussion_threads,
  notice_attachments,
  notices,
  material_events,
  material_blobs,
  materials,
  course_materials,
  competition_entries,
  competitions,
  submissions,
  assignments,
  enrollments,
  attachments,
  posts,
  boards,
  messages,
  user_settings,
  course_attachments,
  professor_invite_usages,
  professor_invites,
  courses,
  users;

SET FOREIGN_KEY_CHECKS = 1;

/* ============================================================================
-- 2) 스키마 생성
============================================================================ */

-- 2) 초대코드 테이블
CREATE TABLE IF NOT EXISTS professor_invites (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code        VARCHAR(64)  NOT NULL,  -- 실제 초대 코드(서버/환경변수와 일치)
  label       VARCHAR(120) NULL,
  is_active   TINYINT(1)   NOT NULL DEFAULT 1,
  max_uses    INT UNSIGNED NULL,      -- NULL = 무제한
  used_count  INT UNSIGNED NOT NULL DEFAULT 0,
  expires_at  DATETIME NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_prof_invite_code (code),
  KEY ix_prof_invite_active (is_active),
  KEY ix_prof_invite_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

/* 2-1. Users */
CREATE TABLE users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name           VARCHAR(100) NOT NULL,                 -- 이름
  email          VARCHAR(190) NOT NULL,                 -- 이메일
  role           ENUM('student','instructor','admin','guest')
                  NOT NULL DEFAULT 'student',
  username       VARCHAR(50)  NULL,                     -- 사용자 계정
  phone          VARCHAR(30)  NULL,                     -- 휴대폰 번호
  student_no     VARCHAR(50)  NULL,                     -- 학번/학년/졸업 여부
  school         VARCHAR(120) NULL,                     -- 학교
  github_url     VARCHAR(255) NULL,
  profile_image  VARCHAR(255) NULL,
  resume_file    VARCHAR(255) NULL,
  is_active      TINYINT(1)   NOT NULL DEFAULT 1,
  invited_via_id INT UNSIGNED NULL,                     -- 초대코드 FK
  department     VARCHAR(120) NULL,                     -- 학부/전공
  password_hash  VARCHAR(255) NULL,
  password       VARCHAR(255) NULL,
  created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  -- 추가 컬럼
  birth_date     DATE         NULL,                     -- 생년월일
  gender         VARCHAR(10)  NULL,                     -- 성별
  address        VARCHAR(255) NULL,                     -- 주소
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY ix_users_role           (role),
  KEY ix_users_is_active      (is_active),
  KEY ix_users_invited_via_id (invited_via_id),
  CONSTRAINT fk_users_invited_via
    FOREIGN KEY (invited_via_id)
    REFERENCES professor_invites(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


/* 2-2. Courses */
CREATE TABLE courses (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title              VARCHAR(200) NOT NULL,
  description        TEXT NULL,
  start_date         DATE NULL,
  end_date           DATE NULL,
  schedule_text      TEXT NULL,
  credit             TINYINT UNSIGNED NULL DEFAULT 0,
  instructor_user_id INT UNSIGNED NULL,
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_courses_start_date (start_date),
  KEY ix_courses_end_date   (end_date),
  KEY ix_courses_instructor_user_id (instructor_user_id),
  CONSTRAINT fk_courses_instructor
    FOREIGN KEY (instructor_user_id)
    REFERENCES users(id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


/* 2-3. Enrollments */
CREATE TABLE enrollments (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  course_id  INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_enroll_user   (user_id),
  KEY idx_enroll_course (course_id),
  CONSTRAINT fk_enroll_user
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
  CONSTRAINT fk_enroll_course
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-4. Assignments */
CREATE TABLE assignments (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id       INT UNSIGNED NOT NULL,
  title           VARCHAR(200) NOT NULL,
  due_at          DATETIME NULL,
  total_score     INT UNSIGNED NOT NULL DEFAULT 100,
  description     TEXT NULL,                 -- ← AFTER total_score
  attachment_data LONGBLOB NULL,             -- ← 추가됨
  attachment_name VARCHAR(255) NULL,         -- ← 추가됨
  attachment_mime VARCHAR(100) NULL,         -- ← 추가됨
  attachment_size BIGINT NULL,               -- ← 추가됨
  attachment_md5  CHAR(32) NULL,             -- ← 추가됨
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_assignments_course (course_id),
  KEY idx_assignments_due    (due_at),
  CONSTRAINT fk_assignments_course
    FOREIGN KEY (course_id) REFERENCES courses(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


/* 2-5. Submissions (트리거로 제출 규칙 강제) */
CREATE TABLE submissions (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  assignment_id INT UNSIGNED NOT NULL,
  user_id       INT UNSIGNED NOT NULL,
  score         INT NULL,
  submitted_at  DATETIME NULL,
  file_url      VARCHAR(255) NULL,
  comment       TEXT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NULL,
  graded_at     DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sub_user_assignment (user_id, assignment_id),
  KEY idx_sub_assign      (assignment_id),
  KEY idx_sub_user        (user_id),
  KEY ix_submissions_submitted_at (submitted_at),
  CONSTRAINT fk_sub_assign
    FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
  CONSTRAINT fk_sub_user
    FOREIGN KEY (user_id)       REFERENCES users(id)       ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-6. course_materials (레거시 코스별 자료) */
CREATE TABLE course_materials (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id         INT UNSIGNED NOT NULL,
  week              INT UNSIGNED NULL,
  title             VARCHAR(200) NOT NULL,
  kind              ENUM('video','file','link') NOT NULL DEFAULT 'video',
  storage_url       VARCHAR(500) NULL,
  file_path         VARCHAR(500) NULL,
  mime              VARCHAR(100) NULL,
  size_bytes        BIGINT UNSIGNED NULL,
  duration_seconds  INT UNSIGNED NULL,
  is_published      TINYINT(1) NOT NULL DEFAULT 1,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_cm_course (course_id),
  KEY idx_cm_week   (week),
  CONSTRAINT fk_cm_course
    FOREIGN KEY (course_id) REFERENCES courses(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-7. materials (앱 자료) */
CREATE TABLE materials (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id        INT UNSIGNED NOT NULL,
  owner_user_id    INT UNSIGNED NULL,
  title            VARCHAR(200) NOT NULL,
  week             INT UNSIGNED NULL,
  kind             ENUM('video','audio','file','link') NOT NULL DEFAULT 'video',
  storage_url      VARCHAR(500) NULL,
  file_path        VARCHAR(500) NULL,
  mime             VARCHAR(100) NULL,
  size_bytes       BIGINT UNSIGNED NULL,
  duration_seconds INT UNSIGNED NULL,
  is_downloadable  TINYINT(1) NOT NULL DEFAULT 0,
  is_published     TINYINT(1) NOT NULL DEFAULT 1,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_materials_course (course_id),
  KEY idx_materials_week   (week),
  KEY idx_materials_kind   (kind),
  CONSTRAINT fk_materials_course
    FOREIGN KEY (course_id) REFERENCES courses(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_materials_owner
    FOREIGN KEY (owner_user_id) REFERENCES users(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-8. material_events (재생/완료/다운로드 로그) */
CREATE TABLE material_events (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id         INT UNSIGNED NOT NULL,
  material_id     INT UNSIGNED NOT NULL,
  action          ENUM('play','complete','download') NOT NULL,
  seconds_watched INT UNSIGNED NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_me_user (user_id),
  KEY idx_me_material (material_id),
  KEY idx_me_user_material_action (user_id, material_id, action),
  CONSTRAINT fk_me_user
    FOREIGN KEY (user_id)     REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_me_material
    FOREIGN KEY (material_id) REFERENCES materials(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-9. material_blobs */
CREATE TABLE material_blobs (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  material_id  INT UNSIGNED NOT NULL UNIQUE,
  data         LONGBLOB NOT NULL,
  size_bytes   BIGINT NULL,
  mime_type    VARCHAR(100) DEFAULT 'video/mp4',
  checksum_md5 CHAR(32),
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_material_blobs_material
    FOREIGN KEY (material_id) REFERENCES materials(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-10. notices / notice_attachments */
CREATE TABLE notices (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id        INT UNSIGNED NOT NULL,
  author_user_id   INT UNSIGNED NULL,
  title            VARCHAR(200) NOT NULL,
  body             LONGTEXT NOT NULL,
  is_pinned        TINYINT(1) NOT NULL DEFAULT 0,
  attachment_data  LONGBLOB NULL,            -- ← 추가됨
  attachment_name  VARCHAR(255) NULL,        -- ← 추가됨
  attachment_mime  VARCHAR(100) NULL,        -- ← 추가됨
  attachment_size  BIGINT NULL,              -- ← 추가됨
  attachment_md5   CHAR(32) NULL,            -- ← 추가됨
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notices_course (course_id),
  CONSTRAINT fk_notices_course
    FOREIGN KEY (course_id) REFERENCES courses(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_notices_author
    FOREIGN KEY (author_user_id) REFERENCES users(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE notice_attachments (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  notice_id   INT UNSIGNED NOT NULL,
  file_path   VARCHAR(255)  NULL,
  storage_url VARCHAR(2048) NULL,
  filename    VARCHAR(255)  NOT NULL,
  size_bytes  BIGINT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notice_id (notice_id),
  CONSTRAINT fk_notice_attachments_notice
    FOREIGN KEY (notice_id) REFERENCES notices(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-11. Discussions (threads/comments/likes) */
CREATE TABLE discussion_threads (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id      INT UNSIGNED NOT NULL,
  author_user_id INT UNSIGNED NOT NULL,
  title          VARCHAR(200) NOT NULL,
  body           LONGTEXT NOT NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_threads_course (course_id),
  CONSTRAINT fk_threads_course
    FOREIGN KEY (course_id) REFERENCES courses(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_threads_author
    FOREIGN KEY (author_user_id) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE discussion_comments (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  thread_id  INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  parent_id  INT UNSIGNED NULL,
  body       LONGTEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_comments_thread (thread_id),
  KEY idx_comments_parent (parent_id),
  CONSTRAINT fk_comments_thread
    FOREIGN KEY (thread_id) REFERENCES discussion_threads(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_comments_parent
    FOREIGN KEY (parent_id) REFERENCES discussion_comments(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_comments_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE discussion_comment_likes (
  comment_id INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (comment_id, user_id),
  KEY ix_dcl_user (user_id),
  CONSTRAINT fk_dcl_comment
    FOREIGN KEY (comment_id) REFERENCES discussion_comments(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_dcl_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-12. Mentoring (teams/members/reports) */
CREATE TABLE mentoring_teams (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(120) NOT NULL,
  owner_user_id INT UNSIGNED NOT NULL,
  is_solo       TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_mteam_owner (owner_user_id),
  CONSTRAINT fk_mteam_owner
    FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE mentoring_team_members (
  id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  team_id   INT UNSIGNED NOT NULL,
  user_id   INT UNSIGNED NOT NULL,
  role      VARCHAR(40) DEFAULT 'member',
  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_team_user (team_id, user_id), -- 중복 방지(ALTER 제거, CREATE에 통합)
  KEY idx_tmem_team (team_id),
  KEY idx_tmem_user (user_id),
  CONSTRAINT fk_tmem_team FOREIGN KEY (team_id) REFERENCES mentoring_teams(id) ON DELETE CASCADE,
  CONSTRAINT fk_tmem_user FOREIGN KEY (user_id) REFERENCES users(id)        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE mentoring_reports (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  author_user_id INT UNSIGNED NOT NULL,
  team_id        INT UNSIGNED NULL,
  title          VARCHAR(200) NOT NULL,
  content        TEXT NULL,
  file_url       VARCHAR(255) NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_mrep_author (author_user_id),
  KEY idx_mrep_team   (team_id),
  CONSTRAINT fk_mrep_author FOREIGN KEY (author_user_id) REFERENCES users(id)           ON DELETE CASCADE,
  CONSTRAINT fk_mrep_team   FOREIGN KEY (team_id)        REFERENCES mentoring_teams(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-13. Projects/Tasks/TaskFiles */
CREATE TABLE projects (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title           VARCHAR(200) NOT NULL,
  description     TEXT NULL,
  team_id         INT UNSIGNED NULL,
  owner_user_id   INT UNSIGNED NULL,
  mentor_user_id  INT UNSIGNED NULL,
  status          VARCHAR(30) DEFAULT 'ongoing',
  github_repo_url VARCHAR(255) NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_proj_team   (team_id),
  KEY idx_proj_owner  (owner_user_id),
  KEY idx_proj_mentor (mentor_user_id),
  KEY ix_projects_status (status),
  CONSTRAINT fk_proj_team   FOREIGN KEY (team_id)        REFERENCES mentoring_teams(id) ON DELETE SET NULL,
  CONSTRAINT fk_proj_owner  FOREIGN KEY (owner_user_id)  REFERENCES users(id)           ON DELETE SET NULL,
  CONSTRAINT fk_proj_mentor FOREIGN KEY (mentor_user_id) REFERENCES users(id)           ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE project_tasks (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  project_id       INT UNSIGNED NOT NULL,
  title            VARCHAR(200) NOT NULL,
  due_at           DATETIME NULL,
  assignee_user_id INT UNSIGNED NULL,
  status           VARCHAR(20) DEFAULT 'todo',
  description      MEDIUMTEXT NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pt_project   (project_id),
  KEY idx_pt_assignee  (assignee_user_id),
  KEY ix_ptasks_due    (due_at),
  KEY ix_ptasks_status (status),
  CONSTRAINT fk_pt_project  FOREIGN KEY (project_id)       REFERENCES projects(id) ON DELETE CASCADE,
  CONSTRAINT fk_pt_assignee FOREIGN KEY (assignee_user_id) REFERENCES users(id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE project_task_files (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  task_id          INT UNSIGNED NOT NULL,
  file_url         VARCHAR(255) NOT NULL,
  filename         VARCHAR(255) NULL,
  size_bytes       BIGINT NULL,
  uploader_user_id INT UNSIGNED NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_ptf_task     (task_id),
  KEY idx_ptf_uploader (uploader_user_id),
  CONSTRAINT fk_ptf_task     FOREIGN KEY (task_id)          REFERENCES project_tasks(id) ON DELETE CASCADE,
  CONSTRAINT fk_ptf_uploader FOREIGN KEY (uploader_user_id) REFERENCES users(id)         ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-14. Competitions/Entries */
CREATE TABLE competitions (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title          VARCHAR(200) NOT NULL,
  host           VARCHAR(120) NULL,
  url            VARCHAR(255) NULL,
  apply_deadline DATETIME NULL,
  start_at       DATETIME NULL,
  end_at         DATETIME NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_competitions_deadline (apply_deadline),
  KEY ix_competitions_start    (start_at),
  KEY ix_competitions_end      (end_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE competition_entries (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  competition_id     INT UNSIGNED NOT NULL,
  team_id            INT UNSIGNED NULL,
  applicant_user_id  INT UNSIGNED NULL,
  project_id         INT UNSIGNED NULL,
  status             VARCHAR(20) DEFAULT 'draft',
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_centry_comp    (competition_id),
  KEY idx_centry_team    (team_id),
  KEY idx_centry_user    (applicant_user_id),
  KEY idx_centry_project (project_id),
  KEY ix_centries_status (status),
  CONSTRAINT fk_centry_comp    FOREIGN KEY (competition_id)    REFERENCES competitions(id)   ON DELETE CASCADE,
  CONSTRAINT fk_centry_team    FOREIGN KEY (team_id)           REFERENCES mentoring_teams(id) ON DELETE SET NULL,
  CONSTRAINT fk_centry_user    FOREIGN KEY (applicant_user_id) REFERENCES users(id)          ON DELETE SET NULL,
  CONSTRAINT fk_centry_project FOREIGN KEY (project_id)        REFERENCES projects(id)       ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-15. Messages / UserSettings */
CREATE TABLE messages (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender_id        INT UNSIGNED NOT NULL,
  receiver_id      INT UNSIGNED NOT NULL,
  title            VARCHAR(200) NOT NULL,
  body             TEXT NULL,
  read_at          DATETIME NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sender_deleted   TINYINT(1) NOT NULL DEFAULT 0,
  receiver_deleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_messages_sender (sender_id),
  KEY ix_messages_receiver (receiver_id),
  KEY ix_messages_created_at (created_at),
  KEY ix_messages_read_at (read_at),
  KEY ix_messages_sender_deleted (sender_id, sender_deleted),
  KEY ix_messages_receiver_deleted (receiver_id, receiver_deleted),
  CONSTRAINT fk_msg_sender   FOREIGN KEY (sender_id)   REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_settings (
  id                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id             INT UNSIGNED NOT NULL UNIQUE,
  language            VARCHAR(10)  NOT NULL DEFAULT 'ko',
  theme               VARCHAR(10)  NOT NULL DEFAULT 'light',
  timezone            VARCHAR(50)  NOT NULL DEFAULT 'Asia/Seoul',
  email_notifications TINYINT(1)   NOT NULL DEFAULT 1,
  push_notifications  TINYINT(1)   NOT NULL DEFAULT 0,
  created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME NULL,
  PRIMARY KEY (id),
  KEY ix_usersettings_user (user_id),
  CONSTRAINT fk_user_settings_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* 2-16. Boards/Posts/Attachments */
CREATE TABLE boards (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(32) NOT NULL UNIQUE,
  title VARCHAR(100) NOT NULL,
  description VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE posts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  board_id INT UNSIGNED NOT NULL,
  user_id  INT UNSIGNED NOT NULL,
  title VARCHAR(200) NOT NULL,
  body  MEDIUMTEXT NULL,
  is_pinned TINYINT(1) NOT NULL DEFAULT 0,
  is_locked TINYINT(1) NOT NULL DEFAULT 0,
  views INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_posts_board FOREIGN KEY (board_id) REFERENCES boards(id) ON DELETE CASCADE,
  CONSTRAINT fk_posts_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  INDEX idx_posts_board_created (board_id, created_at),
  INDEX idx_posts_board_pinned  (board_id, is_pinned, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE attachments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id INT UNSIGNED NOT NULL,
  kind ENUM('file','url') NOT NULL,
  storage_path  VARCHAR(255) NULL,
  original_name VARCHAR(255) NULL,
  content_type  VARCHAR(100) NULL,
  file_size     BIGINT NULL,
  url TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_attach_post FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  INDEX idx_attach_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

/* 1) 사용자-마커 매핑 */
CREATE TABLE IF NOT EXISTS user_markers (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id          INT UNSIGNED NOT NULL,
  marker_id        INT NOT NULL,
  marker_filename  VARCHAR(255) NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_user_marker (user_id, marker_id),
  UNIQUE KEY uq_marker_id (marker_id),
  CONSTRAINT fk_um_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

/* 2) 출석 세션 */
CREATE TABLE IF NOT EXISTS attendance_sessions (
  id                         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id                  INT UNSIGNED NOT NULL,
  title                      VARCHAR(120) NULL,
  session_code               CHAR(8) NOT NULL,
  opens_at                   DATETIME NOT NULL,
  closes_at                  DATETIME NOT NULL,
  created_by                 INT UNSIGNED NOT NULL,  -- 교수 user_id
  is_open                    TINYINT(1) NOT NULL DEFAULT 1,
  allow_student_self_tag     TINYINT(1) NOT NULL DEFAULT 1,
  created_at                 DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_session_code (session_code),
  KEY idx_session_course_time (course_id, opens_at, closes_at),
  CONSTRAINT fk_as_course  FOREIGN KEY (course_id)  REFERENCES courses(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_as_creator FOREIGN KEY (created_by) REFERENCES users(id)   ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

/* 3) 검출 큐 (워커/학생캠이 담는 원시 검출) 
   - MariaDB 10.2+ JSON 가능. 낮은 버전이면 JSON → TEXT로 변경하세요. */
CREATE TABLE IF NOT EXISTS attendance_detections (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id         INT UNSIGNED NOT NULL,
  marker_id          INT NOT NULL,
  detected_at        DATETIME NOT NULL,
  bbox_json          JSON NULL,
  raw_identity_json  JSON NULL,
  candidate_user_id  INT UNSIGNED NULL,
  source             ENUM('prof_cam','student_cam','upload') NOT NULL DEFAULT 'prof_cam',
  PRIMARY KEY (id),
  UNIQUE KEY uq_detect_once (session_id, marker_id),
  KEY idx_det_time (detected_at),
  CONSTRAINT fk_ad_session FOREIGN KEY (session_id)        REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  CONSTRAINT fk_ad_user    FOREIGN KEY (candidate_user_id) REFERENCES users(id)              ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

/* 4) 최종 출석 기록 */
CREATE TABLE IF NOT EXISTS attendance_records (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id  INT UNSIGNED NOT NULL,
  student_id  INT UNSIGNED NOT NULL,
  marker_id   INT NULL,
  status      ENUM('present','late','absent','excused') NOT NULL DEFAULT 'present',
  source      ENUM('auto','manual') NOT NULL DEFAULT 'auto',
  marked_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  note        VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_session_student (session_id, student_id),
  KEY idx_status (status),
  CONSTRAINT fk_ar_session FOREIGN KEY (session_id) REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  CONSTRAINT fk_ar_student FOREIGN KEY (student_id) REFERENCES users(id)               ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

/* 5) 감사로그(선택) */
CREATE TABLE IF NOT EXISTS attendance_audits (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  record_id   INT UNSIGNED NOT NULL,
  changed_by  INT UNSIGNED NOT NULL,
  old_status  VARCHAR(20) NULL,
  new_status  VARCHAR(20) NULL,
  changed_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  note        VARCHAR(255) NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_audit_record FOREIGN KEY (record_id) REFERENCES attendance_records(id) ON DELETE CASCADE,
  CONSTRAINT fk_audit_user   FOREIGN KEY (changed_by) REFERENCES users(id)             ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE IF NOT EXISTS course_attachments (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id    INT UNSIGNED NULL,  -- NULL 허용으로 변경
  parent_kind  VARCHAR(64) NOT NULL,  -- ENUM → VARCHAR(64)로 변경
  parent_id    INT UNSIGNED NULL,
  filename     VARCHAR(255) NOT NULL,
  mime         VARCHAR(100) NOT NULL DEFAULT 'application/octet-stream',
  size         BIGINT NULL,
  md5          CHAR(32) NULL,
  data         LONGBLOB NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_ca_scope (course_id, parent_kind, parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 3) 초대코드 사용 이력
CREATE TABLE IF NOT EXISTS professor_invite_usages (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  invite_id  INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  used_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_invite_user (invite_id, user_id),
  KEY ix_pi_used_user (user_id),
  CONSTRAINT fk_pi_usage_invite FOREIGN KEY (invite_id)
    REFERENCES professor_invites(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_pi_usage_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



/* ============================================================================
-- 3) 시드 데이터
============================================================================ */

/* 3-1. 사용자 */
INSERT INTO users (name, email, role, username, phone, password, github_url, school) VALUES
  ('홍학생', 'student@example.com',   'student',    'student',  '010-0000-0001', 'student123', NULL, '우송대학교'),
  ('김교수', 'prof@example.com',      'instructor', 'prof',     '010-0000-0002', 'prof123',    NULL, '우송대학교'),
  ('관리자', 'admin@example.com',     'admin',      'admin',    '010-0000-0003', 'admin123',   NULL, '우송대학교'),
  ('김미소', 'misosmile0306@naver.com',   'admin',    'admin2',  '010-2355-5103', 'max1004!!', NULL, '우송대학교'),
  ('김동선', 'es4135@naver.com',      'admin', 'admin1',     '010-4438-4135', 'ehdtjs2143!!',    NULL, '우송대학교'),
  ('황동하', 'dhhwang@wsu.ac.kr',     'instructor',      'admin',    '010-2512-6818', 'xhRl1004!@#',   NULL, '우송대학교'),
  ('김동현', 'dhkim977@naver.com',   'instructor',    'student',  '010-8630-8819', 'xhRl1004!@#', NULL, '우송대학교'),
  ('정웅표', 'luxuryme1421@nate.com',      'instructor', 'prof',     '010-8638-8978', 'xhRl1004!@#',    NULL, '우송대학교');
  
INSERT INTO courses (title, description, start_date, end_date, schedule_text, credit, instructor_user_id)
VALUES
('AI 기반 바이오 데이터 기초와 윤리',
 '데이터 수집, 전처리, 윤리, 데이터 저장, 공유, 개인정보 보호 등',
 '2025-10-13', '2025-11-20', '월~금 09:00~18:00 (총 20시간)', 20, NULL),

('바이오헬스 AI 실무 활용',
 '실무 데이터 처리, 머신러닝/딥러닝, 모델 배포, 인터페이스',
 '2025-10-13', '2025-11-20', '월~금 09:00~18:00 (총 64시간)', 64, NULL),

('AI 기반 의료 영상 이해와 활용기초',
 '의료 영상 (X-ray, CT, MRI, 초음파 등) 분석, 영상 처리 기초, 시각화',
 '2025-10-13', '2025-11-20', '월~금 09:00~18:00 (총 32시간)', 32, NULL),

('AIoT 웨어러블과 빅데이터',
 '웨어러블 기기, 생체신호 패치, 실시간 데이터 전송, IoT, 빅데이터 처리',
 '2025-10-13', '2025-11-20', '월~금 09:00~18:00 (총 48시간)', 48, NULL),

('AI 기반 헬스케어 디바이스 설계',
 '하드웨어 설계, 센서, 회로, 인체공학, 사용자 인터페이스, 신뢰성, 규격',
 '2025-10-13', '2025-11-20', '월~금 09:00~18:00 (총 48시간)', 48, NULL),

('AI 반려 로봇',
 '로봇 하드웨어, 제어, 상호작용, 인공지능, 감성 인터페이스, 윤리',
 '2025-10-13', '2025-11-20', '월~금 09:00~18:00 (총 48시간)', 48, NULL);

COMMIT;