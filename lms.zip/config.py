# config.py — Single Upload Root (static/uploads) + Backward-Compatible Aliases
import os
from urllib.parse import quote_plus

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    # ── DB ───────────────────────────────────────────────────────────────────
    SQLALCHEMY_DATABASE_URI = os.environ.get("SQLALCHEMY_DATABASE_URI")
    if not SQLALCHEMY_DATABASE_URI:
        DB_USER = os.getenv("DB_USER", "wsuser")
        DB_PASS = os.getenv("DB_PASS", "wsuser!")
        DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
        DB_PORT = os.getenv("DB_PORT", "3306")
        DB_NAME = os.getenv("DB_NAME", "lms_db")
        _pwd_enc = quote_plus(DB_PASS)
        SQLALCHEMY_DATABASE_URI = (
            f"mysql+pymysql://{DB_USER}:{_pwd_enc}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
        )

    LEGACY_DEFAULT_URI   = "mysql+pymysql://wsuser:wsuser!@127.0.0.1:3306/lms_db?charset=utf8mb4"
    ENHANCED_DEFAULT_URI = "mysql+pymysql://root:root1234@127.0.0.1:3306/lms_db?charset=utf8mb4"

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 1800,
        "pool_size": 5,
        "max_overflow": 10,
    }

    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "dev-secret")

    # ── 경로(단일 루트) ──────────────────────────────────────────────────────
    BASE_DIR = BASE_DIR
    STATIC_UPLOAD_ROOT = os.path.join(BASE_DIR, "static", "uploads")
    UPLOAD_ROOT = os.environ.get("UPLOAD_ROOT", STATIC_UPLOAD_ROOT)
    UPLOAD_DIR = UPLOAD_ROOT
    UPLOAD_ROOT_V1 = UPLOAD_ROOT
    UPLOAD_ROOT_V2 = UPLOAD_ROOT
    UPLOAD_ROOT_V2_ALIAS = UPLOAD_ROOT

    AVATAR_SUBDIR     = "avatars"
    RESUME_SUBDIR     = "resumes"
    MATERIALS_SUBDIR  = "materials"

    AVATAR_DIR    = os.path.join(UPLOAD_ROOT, AVATAR_SUBDIR)
    RESUME_DIR    = os.path.join(UPLOAD_ROOT, RESUME_SUBDIR)
    MATERIALS_DIR = os.path.join(UPLOAD_ROOT, MATERIALS_SUBDIR)

    # ── 업로드 정책 ──────────────────────────────────────────────────────────
    ALLOWED_IMAGE_EXTS = {"png", "jpg", "jpeg", "gif"}
    ALLOWED_DOC_EXTS   = {"pdf", "doc", "docx"}
    ALLOWED_VIDEO_EXTS = {"mp4", "webm", "mov", "m4v"}
    ALLOWED_EXTS = {
        "pdf", "zip", "doc", "docx", "ppt", "pptx", "xlsx", "csv",
        "ipynb", "py", "txt", "md", "rar",
        "jpg", "jpeg", "png", "gif",
        "mp4", "webm", "mov", "m4v",
    }
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_MB", "512")) * 1024 * 1024

    # ── 표시/템플릿/정적 파일 ───────────────────────────────────────────────
    JSON_AS_ASCII = False
    TEMPLATES_AUTO_RELOAD = True
    SEND_FILE_MAX_AGE_DEFAULT = 3600

    # ── 세션/쿠키 ───────────────────────────────────────────────────────────
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "0") == "1"

    # ── 데모/포맷 ───────────────────────────────────────────────────────────
    DEMO_USER_ID = int(os.environ.get("DEMO_USER_ID", 1))
    DATE_ONLY = "%Y-%m-%d"
    DATE_HM   = "%Y-%m-%d %H:%M"
    DATE_T    = "%Y-%m-%dT%H:%M"

    # ── ArUco / Attendance 설정 (엔진 import 금지) ─────────────────────────
    # 마커 신원 JSON 파일(상대경로면 BASE_DIR 기준)
    ARUCO_IDENTITIES_JSON = os.environ.get(
        "ARUCO_IDENTITIES_JSON",
        os.path.join(BASE_DIR, "data", "aruco_identities.json"),
    )
    # 생성된 마커 PNG 저장 폴더
    ARUCO_OUTPUT_DIR = os.environ.get(
        "ARUCO_OUTPUT_DIR",
        os.path.join(BASE_DIR, "static", "markers"),
    )
    # OpenCV 아루코 사전 이름
    ARUCO_DICT = os.environ.get("ARUCO_DICT", "DICT_4X4_50")

    # 출석 QR 기본 오픈 시간(분) – 라우트 기본값에서 사용
    ATTENDANCE_QR_SESSION_MINUTES = int(os.environ.get("ATTENDANCE_QR_SESSION_MINUTES", "10"))

# ── 필요 폴더 자동 생성 ─────────────────────────────────────────────────────
try:
    os.makedirs(Config.UPLOAD_ROOT, exist_ok=True)
    os.makedirs(Config.AVATAR_DIR, exist_ok=True)
    os.makedirs(Config.RESUME_DIR, exist_ok=True)
    os.makedirs(Config.MATERIALS_DIR, exist_ok=True)

    # ArUco 경로들
    os.makedirs(Config.ARUCO_OUTPUT_DIR, exist_ok=True)
    id_dir = os.path.dirname(Config.ARUCO_IDENTITIES_JSON) or Config.BASE_DIR
    os.makedirs(id_dir, exist_ok=True)
except Exception:
    pass
