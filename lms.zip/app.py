# app.py — 앱 팩토리 + 블루프린트 등록 (역할 정규화 + 대시보드 접근 가드 포함)
from flask import Flask, redirect, url_for, request, session
from config import Config
from extensions import db
from helpers.utils import register_jinja_filters
from helpers.context import register_context_hooks
from werkzeug.middleware.proxy_fix import ProxyFix

# 블루프린트 import (필요한 기능만)
from blueprints.auth.routes import bp as auth_bp
from blueprints.dashboard.routes import bp as dashboard_bp
from blueprints.courses.routes import bp as courses_bp
from blueprints.course_detail.routes import bp as course_detail_bp
from blueprints.mentoring.routes import bp as mentoring_bp
from blueprints.messages.routes import bp as messages_bp
from blueprints.board.routes import bp as board_bp
from blueprints.assignments.routes import bp as assignments_view_bp
from blueprints.profile.routes import bp as profile_bp
from blueprints.materials.routes import bp as materials_bp
from blueprints.uploads.routes import bp as uploads_bp
from blueprints.notices.routes import bp as notices_bp
from blueprints.discussion.routes import bp as discussion_bp
from blueprints.users.routes import bp as users_bp
from blueprints.attendance.routes import bp as attendance_bp


# 현재 사용자 조회용
from models import User

def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(Config)

    # 확장 초기화
    db.init_app(app)

    # Jinja 필터/컨텍스트 등록
    register_jinja_filters(app)
    register_context_hooks(app)

    # 1) 인증 블루프린트 먼저
    app.register_blueprint(auth_bp)

    app.register_blueprint(uploads_bp)
    app.register_blueprint(materials_bp)

    # 2) 기능 블루프린트
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(courses_bp)
    app.register_blueprint(course_detail_bp)
    app.register_blueprint(mentoring_bp)
    app.register_blueprint(messages_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(assignments_view_bp)
    app.register_blueprint(notices_bp)
    app.register_blueprint(discussion_bp)
    app.register_blueprint(board_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(attendance_bp)
    # --- 유틸: 세션 uid로 현재 사용자 조회 ---
    def _get_current_user() -> User | None:
        uid = session.get("uid")
        if not uid:
            return None
        return db.session.get(User, uid)

    # --- 유틸: 역할 정규화/판별 ---
    def _role_of(u: User | None) -> str:
        return (getattr(u, "role", "") or "").strip().lower()

    def _is_instructor(u: User | None) -> bool:
        # instructor 외 professor/prof/teacher 등 별칭도 허용
        return _role_of(u) in {"instructor", "professor", "prof", "teacher"}

    def _is_admin(u: User | None) -> bool:
        # admin/administrator 모두 허용
        return _role_of(u) in {"admin", "administrator"}

    # --- 루트 접근: 로그인 여부 + 역할에 따라 분기 ---
    @app.route("/")
    def _root_redirect():
        user = _get_current_user()
        if user:
            # ✅ 관리자 → 관리자 강좌 관리로
            if _is_admin(user):
                return redirect(url_for("courses.admin_list"))
            # ✅ 교수/강사 → 기존대로 강좌 홈(수강 중인 강좌)
            if _is_instructor(user):
                return redirect(url_for("courses.home"))
            # 학생/일반 사용자
            return redirect(url_for("dashboard.home"))
        return redirect(url_for("auth.home"))

    # --- 전역 가드: auth.*, static 제외 모두 로그인 필요 + 교수의 대시보드 접근 차단 ---
    @app.before_request
    def _require_login_globally():
        ep = (request.endpoint or "").strip()

        # 정적 파일 통과
        if ep == "static":
            return

        # 인증 관련 허용 엔드포인트
        allowed = {
            "auth.home",        # GET /login
            "auth.login_post",  # POST /login
            "auth.logout",      # (옛 엔드포인트명 가능성)
            "auth.logout_get",  # GET /logout
            "auth.logout_post", # POST /logout
            "auth.init_demo",   # 데모 초기화
        }

        # 인증 블루프린트 전반 허용
        if ep in allowed or ep.startswith("auth."):
            return

        user = _get_current_user()

        # 로그인 안 됐으면 로그인 페이지로
        if not user:
            nxt = request.full_path if request.query_string else request.path
            return redirect(url_for("auth.home", next=nxt))

        # ✅ 교수·관리자의 대시보드 접근을 전역에서 차단 (북마크/직접접속 포함)
        if ep.startswith("dashboard.") and (_is_instructor(user) or _is_admin(user)):
            return redirect(url_for("courses.home"))

    # 🔒 YouTube 임베드 허용 헤더(CSP) + X-Frame-Options 제거
    @app.after_request
    def _add_embed_headers(resp):
        if 'X-Frame-Options' in resp.headers:
            del resp.headers['X-Frame-Options']
        csp = (
            "default-src 'self'; "
            "frame-src 'self' https://www.youtube.com https://www.youtube-nocookie.com; "
            "img-src 'self' data: https://i.ytimg.com; "
            "script-src 'self' 'unsafe-inline' https://www.youtube.com https://www.gstatic.com; "
            "style-src 'self' 'unsafe-inline'; "
            "media-src 'self' blob: https://*; "
            "connect-src 'self'; "
        )
        resp.headers.setdefault("Content-Security-Policy", csp)
        return resp

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5004, use_reloader=False)