# blueprints/materials/routes.py
from __future__ import annotations
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import re
from hashlib import md5
import mimetypes
from pathlib import Path

from flask import (
    Blueprint, abort, redirect, render_template, url_for,
    request, Response, g
)
from helpers.auth import login_required
from models import db, Material, MaterialEvent, Enrollment, MaterialBlob

bp = Blueprint("materials", __name__, url_prefix="/materials")


# ------------------------------
# 권한
# ------------------------------
def _can_access(material: Material, user) -> bool:
    # 관리자/교수/강사는 통과, 학생은 수강 여부 체크
    if getattr(user, "role", None) in ("admin", "instructor", "professor"):
        return True
    ok = db.session.query(Enrollment.id).filter_by(
        user_id=user.id, course_id=material.course_id
    ).first()
    return bool(ok)


# ------------------------------
# 재생 소스 URL 결정
# ------------------------------
def _src_url(material: Material) -> str | None:
    # DB 저장본 우선
    b = getattr(material, "blob", None)
    if not b:
        b = db.session.query(MaterialBlob).filter_by(material_id=material.id).first()
    if b and getattr(b, "data", None):
        return url_for("materials.stream", material_id=material.id)

    # 외부 URL → 로컬 파일 순
    if getattr(material, "storage_url", None):
        return material.storage_url
    if getattr(material, "file_path", None):
        return url_for("uploads.file", relpath=material.file_path)
    return None


# ------------------------------
# 확장자 기반 MIME/타입 보정
# ------------------------------
def _guess_mime_by_ext(name_or_url: str | None) -> str | None:
    if not name_or_url:
        return None
    ext = Path(urlparse(name_or_url).path).suffix.lower()
    return {
        ".mp4":  "video/mp4",
        ".m4v":  "video/mp4",
        ".mov":  "video/quicktime",
        ".webm": "video/webm",
        ".ogv":  "video/ogg",
        ".mp3":  "audio/mpeg",
        ".m4a":  "audio/mp4",
        ".aac":  "audio/aac",
        ".wav":  "audio/wav",
        ".ogg":  "audio/ogg",
    }.get(ext)

def _looks_like_video(name_or_url: str | None) -> bool:
    if not name_or_url:
        return False
    ext = Path(urlparse(name_or_url).path).suffix.lower()
    return ext in {".mp4", ".m4v", ".mov", ".webm", ".ogv"}


# ------------------------------
# YouTube URL → embed 변환
# ------------------------------
def _youtube_embed(url: str) -> str | None:
    if not url:
        return None
    u = urlparse(url)
    host = (u.netloc or "").lower()
    path = (u.path or "").strip("/")

    vid = None
    if "youtube.com" in host:
        if path.startswith("watch"):
            vid = parse_qs(u.query).get("v", [None])[0]
        elif path.startswith("shorts/"):
            vid = path.split("/", 1)[1]
        elif path.startswith("embed/"):
            return url
    elif "youtu.be" in host:
        vid = path.split("/")[0]

    if not vid:
        return None

    q = parse_qs(u.query)
    start = None
    if "start" in q:
        start = q["start"][0]
    elif "t" in q:
        t = q["t"][0]
        try:
            if t.endswith("s"):
                t = t[:-1]
            if "m" in t:
                m, s = t.split("m", 1)
                start = str(int(m) * 60 + int(s or 0))
            else:
                start = str(int(t))
        except Exception:
            start = None

    base = f"https://www.youtube.com/embed/{vid}?rel=0&modestbranding=1&playsinline=1"
    if start:
        base += f"&start={start}"
    return base


# ------------------------------
# Range 파서
# ------------------------------
def _parse_range(range_header: str | None, size: int):
    if not range_header:
        return None
    m = re.match(r"bytes=(\d*)-(\d*)(?:,.*)?$", range_header.strip(), re.I)
    if not m:
        return None
    start_s, end_s = m.groups()
    if start_s == "" and end_s == "":
        return None
    if start_s == "":
        try:
            length = int(end_s)
        except Exception:
            return None
        if length <= 0:
            return None
        start = max(0, size - length)
        end = size - 1
    else:
        try:
            start = int(start_s)
        except Exception:
            return None
        end = int(end_s) if end_s else size - 1
    if start > end or start < 0 or start >= size:
        return ("invalid", None)
    if end >= size:
        end = size - 1
    return start, end


# ------------------------------
# 재생 페이지
# ------------------------------
@bp.get("/<int:material_id>/play")
@login_required
def play(material_id: int):
    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)
    if m.kind == "file":
        abort(400, description="파일 자료는 재생 대상이 아닙니다.")

    # 로그: play
    db.session.add(MaterialEvent(user_id=g.user.id, material_id=m.id, action="play"))
    db.session.commit()

    # 소스 URL 결정 (DB blob 최우선)
    src = _src_url(m) or abort(404, description="재생 소스를 찾을 수 없습니다.")
    embed = _youtube_embed(src)  # 유튜브면 iframe

    # 유튜브면 JS API 강제활성 + origin 부여
    if embed:
        u = urlparse(embed)
        q = parse_qs(u.query)
        q["enablejsapi"] = ["1"]
        q["origin"] = [request.host_url.rstrip("/")]
        embed = urlunparse((u.scheme, u.netloc, u.path, u.params, urlencode(q, doseq=True), u.fragment))

    back_url = url_for("course_detail.detail", course_id=m.course_id, tab="materials")

    # MIME 보정(Blob → 모델 → 확장자 → mimetypes → 기본값)
    filename_hint = m.file_path or m.storage_url or m.title or ""
    b = getattr(m, "blob", None)
    if not b:
        b = db.session.query(MaterialBlob).filter_by(material_id=m.id).first()

    mime = (b and b.mime_type) or getattr(m, "mime", None) \
           or _guess_mime_by_ext(filename_hint) \
           or mimetypes.guess_type(filename_hint)[0] \
           or "video/mp4"

    # 확장자로 봤을 때 비디오인데 audio/* 로 들어오면 video/* 로 교정
    if _looks_like_video(filename_hint) and (mime.startswith("audio/") or mime == "application/octet-stream"):
        mime = _guess_mime_by_ext(filename_hint) or "video/mp4"

    # 비디오/오디오 판정
    is_video = bool(embed) or (getattr(m, "kind", None) == "video") or mime.startswith("video/") or _looks_like_video(filename_hint)
    is_audio = not is_video

    return render_template(
        "material_play.html",
        title=m.title,
        src=src,
        embed=embed,
        material=m,
        mime=mime,
        is_audio=is_audio,
        is_video=is_video,
        back_url=back_url,
    )


# ------------------------------
# DB 스트리밍 (HTTP Range/HEAD/ETag 지원)
# ------------------------------
@bp.route("/<int:material_id>/stream", methods=["GET", "HEAD"])
@login_required
def stream(material_id: int):
    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    b = getattr(m, "blob", None)
    if not b or not b.data:
        abort(404, description="DB 저장 영상이 없습니다.")

    data = b.data  # bytes
    size = b.size_bytes or len(data)

    filename_hint = m.file_path or m.storage_url or m.title or ""
    mime = b.mime_type or _guess_mime_by_ext(filename_hint) or mimetypes.guess_type(filename_hint)[0] or "application/octet-stream"

    # 비디오로 보이는 파일인데 audio/* 로 저장되어 있으면 video/* 로 교정
    if (getattr(m, "kind", None) == "video" or _looks_like_video(filename_hint)) and (
        mime.startswith("audio/") or mime == "application/octet-stream"
    ):
        mime = _guess_mime_by_ext(filename_hint) or "video/mp4"

    # 캐시/검증용 ETag (약한 ETag)
    etag = f'W/"{(b.checksum_md5 or md5(data).hexdigest())}-{size}"'

    # 304 Not Modified
    inm = request.headers.get("If-None-Match")
    if inm and inm == etag:
        resp = Response(status=304)
        resp.headers["ETag"] = etag
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = "0"
        return resp

    # HEAD는 메타만
    if request.method == "HEAD":
        resp = Response(status=200, mimetype=mime)
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = str(size)
        resp.headers["ETag"] = etag
        resp.headers["Cache-Control"] = "private, max-age=3600"
        return resp

    # Range 처리
    rng = _parse_range(request.headers.get("Range"), size)
    if rng == ("invalid", None):
        # 416 Range Not Satisfiable
        resp = Response(status=416)
        resp.headers["Content-Range"] = f"bytes */{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["ETag"] = etag
        return resp

    if isinstance(rng, tuple) and len(rng) == 2:
        start, end = rng
        chunk = data[start:end + 1]
        resp = Response(chunk, 206, mimetype=mime, direct_passthrough=True)
        resp.headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = str(len(chunk))
        resp.headers["ETag"] = etag
        resp.headers["Cache-Control"] = "private, max-age=3600"
        return resp

    # Range 없으면 전체 전송
    resp = Response(data, 200, mimetype=mime, direct_passthrough=True)
    resp.headers["Accept-Ranges"] = "bytes"
    resp.headers["Content-Length"] = str(size)
    resp.headers["ETag"] = etag
    resp.headers["Cache-Control"] = "private, max-age=3600"
    return resp


# ------------------------------
# 진행률 하트비트
# ------------------------------
@bp.post("/<int:material_id>/progress")
@login_required
def progress(material_id: int):
    """재생 중간 진행률(초) 기록. ENUM 호환 위해 action='play'로 저장."""
    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    if request.is_json:
        sec = request.json.get("sec")
    else:
        sec = request.form.get("sec")
    try:
        seconds = int(sec) if sec is not None else None
    except Exception:
        seconds = None

    if not seconds or seconds <= 0:
        return ("", 204)

    db.session.add(
        MaterialEvent(
            user_id=g.user.id,
            material_id=m.id,
            action="play",
            seconds_watched=seconds,
        )
    )
    db.session.commit()
    return ("", 204)


# ------------------------------
# 완료 처리
# ------------------------------
@bp.post("/<int:material_id>/complete")
@login_required
def complete(material_id: int):
    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    if request.is_json:
        sec = request.json.get("sec")
    else:
        sec = request.form.get("sec")
    try:
        seconds = int(sec) if sec is not None else None
    except Exception:
        seconds = None

    db.session.add(
        MaterialEvent(
            user_id=g.user.id,
            material_id=m.id,
            action="complete",
            seconds_watched=seconds,
        )
    )
    db.session.commit()
    return ("", 204)


# ------------------------------
# 다운로드 (허용 시)
# ------------------------------
@bp.get("/<int:material_id>/download")
@login_required
def download(material_id: int):
    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)
    if not m.is_downloadable:
        abort(403, description="다운로드가 허용되지 않은 자료입니다.")

    db.session.add(MaterialEvent(user_id=g.user.id, material_id=m.id, action="download"))
    db.session.commit()

    # 1) 외부 URL
    if m.storage_url:
        return redirect(m.storage_url)
    # 2) 로컬 파일
    if m.file_path:
        return redirect(url_for("uploads.file", relpath=m.file_path, dl=1))
    # 3) DB blob
    b = getattr(m, "blob", None)
    if b and b.data:
        filename = (m.title or "video").replace("/", "_")
        ext = mimetypes.guess_extension(b.mime_type or "") or ".bin"
        resp = Response(b.data, 200, mimetype=b.mime_type or "application/octet-stream")
        resp.headers["Content-Length"] = str(b.size_bytes or len(b.data))
        resp.headers["Content-Disposition"] = f'attachment; filename="{filename}{ext}"'
        return resp

    abort(404, description="다운로드 대상을 찾을 수 없습니다.")


# ------------------------------
# DB 업로드 (교수/관리자 전용)
# ------------------------------
@bp.post("/<int:material_id>/blob")
@login_required
def upload_blob(material_id: int):
    m = db.session.get(Material, material_id) or abort(404)
    if getattr(g.user, "role", None) not in ("admin", "instructor", "professor"):
        abort(403)

    f = request.files.get("file")
    if not f or not f.filename:
        abort(400, description="파일이 필요합니다.")

    # ⚠️ 대용량 파일은 운영 환경에서 청크 업로드 권장
    blob_bytes = f.read()
    size = len(blob_bytes)

    mime = f.mimetype
    if not mime or mime == "application/octet-stream":
        mime = mimetypes.guess_type(f.filename)[0] or "application/octet-stream"

    checksum = md5(blob_bytes).hexdigest()

    b = db.session.query(MaterialBlob).filter_by(material_id=m.id).first()
    if b:
        b.data = blob_bytes
        b.size_bytes = size
        b.mime_type = mime
        b.checksum_md5 = checksum
    else:
        db.session.add(MaterialBlob(
            material_id=m.id,
            data=blob_bytes,
            size_bytes=size,
            mime_type=mime,
            checksum_md5=checksum,
        ))

    # 재생 가능 상태로 세팅
    if m.kind == "file":
        m.kind = "video"
    if not m.is_published:
        m.is_published = True

    db.session.commit()
    return redirect(url_for("materials.play", material_id=m.id))


__all__ = ("bp",)
