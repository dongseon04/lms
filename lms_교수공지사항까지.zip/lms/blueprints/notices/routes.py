# blueprints/notices/routes.py
from flask import Blueprint, render_template, request, abort, url_for, g, redirect
from helpers.auth import login_required
from models import db, Notice, Enrollment, Course, NoticeAttachment
from werkzeug.utils import secure_filename
from sqlalchemy.orm import joinedload
from pathlib import Path
from uuid import uuid4

bp = Blueprint("notices", __name__, url_prefix="/notices")

def _can_view(course_id: int, user) -> bool:
    if getattr(user, "role", None) in ("admin", "instructor"):
        return True
    ok = db.session.query(Enrollment.id).filter_by(user_id=user.id, course_id=course_id).first()
    return bool(ok)

@bp.get("/", endpoint="home")
@login_required
def home():
    cid = request.args.get("course_id", type=int)
    if not cid:
        abort(400, description="course_id가 필요합니다.")
    course = db.session.get(Course, cid) or abort(404)

    if not _can_view(course.id, g.user):
        abort(403)

    rows = (
        db.session.query(Notice)
        .filter(Notice.course_id == course.id)
        .order_by(Notice.is_pinned.desc(), Notice.created_at.desc())
        .all()
    )
    return render_template("notices.html", course=course, rows=rows, mode="list")

@bp.get("/<int:nid>", endpoint="view")
@login_required
def view(nid: int):
    n = (
        db.session.query(Notice)
        .options(joinedload(Notice.attachments))
        .filter(Notice.id == nid)
        .first()
    ) or abort(404)

    if not _can_view(n.course_id, g.user):
        abort(403)

    back_url = request.args.get("back") or url_for(
        "course_detail.detail", course_id=n.course_id, tab="notices"
    )
    return render_template("notices.html", n=n, back_url=back_url, mode="view")

ALLOWED_ATTACH_EXTS = {
    "pdf","hwp","hwpx","doc","docx","ppt","pptx","xls","xlsx",
    "zip","7z","rar","png","jpg","jpeg","gif","txt","csv"
}

def _save_notice_file(fs) -> tuple[str,int]:
    from flask import current_app
    base = Path(current_app.config.get("UPLOAD_NOTICE_DIR", "uploads/notices"))
    base.mkdir(parents=True, exist_ok=True)

    name = secure_filename(fs.filename or "file")
    rel = f"{uuid4().hex}_{name}"
    path = base / rel
    fs.save(path)
    return str(Path("notices")/rel), path.stat().st_size

@bp.post("/<int:nid>/attach")
@login_required
def attach_upload(nid: int):
    n = db.session.get(Notice, nid) or abort(404)
    if getattr(g.user, "role", None) not in ("admin", "instructor"):
        abort(403)

    f = request.files.get("file")
    if not f or not f.filename:
        abort(400, description="파일이 필요합니다.")
    ext = (f.filename.rsplit(".",1)[-1] or "").lower()
    if ext not in ALLOWED_ATTACH_EXTS:
        abort(400, description="허용되지 않는 파일 형식입니다.")

    relpath, size = _save_notice_file(f)
    att = NoticeAttachment(
        notice_id=n.id,
        file_path=relpath,
        filename=f.filename,
        size_bytes=size,
    )
    db.session.add(att)
    db.session.commit()

    return redirect(url_for("notices.view", nid=n.id))

@bp.get("/att/<int:att_id>/download")
@login_required
def attach_download(att_id: int):
    att = db.session.get(NoticeAttachment, att_id) or abort(404)
    n   = db.session.get(Notice, att.notice_id) or abort(404)

    if not _can_view(n.course_id, g.user):
        abort(403)

    if att.storage_url:
        return redirect(att.storage_url)
    if att.file_path:
        return redirect(url_for("uploads.file", relpath=att.file_path, dl=1))
    abort(404, description="다운로드 대상을 찾을 수 없습니다.")