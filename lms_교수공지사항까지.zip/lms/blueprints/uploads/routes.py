# blueprints/uploads/routes.py
from __future__ import annotations
import os
import mimetypes
import re
from urllib.parse import quote
from pathlib import Path
from flask import Blueprint, current_app, abort, request, Response, g
from helpers.auth import login_required
from models import db, Material, Enrollment, Notice, NoticeAttachment

bp = Blueprint("uploads", __name__, url_prefix="/u")


# ----- 접근 권한: 수강생/교수/관리자만 -----
def _can_access_rel(relpath: str, user) -> bool:
    if getattr(user, "role", None) in ("admin", "instructor"):
        return True

    m = db.session.query(Material).filter(Material.file_path == relpath).first()
    if m:
        ok = db.session.query(Enrollment.id).filter_by(user_id=user.id, course_id=m.course_id).first()
        return bool(ok)

    att = db.session.query(NoticeAttachment).filter(NoticeAttachment.file_path == relpath).first()
    if att:
        n = db.session.get(Notice, att.notice_id)
        if not n:
            return False
        ok = db.session.query(Enrollment.id).filter_by(user_id=user.id, course_id=n.course_id).first()
        return bool(ok)

    return False


# ----- 경로 안전화 -----
def _resolve_safe_path(base_dir: str, rel: str) -> Path:
    base = Path(base_dir).resolve()
    rel_clean = rel.lstrip("/\\")
    p = (base / rel_clean).resolve()
    if not str(p).startswith(str(base)):
        abort(400, description="잘못된 경로입니다.")
    if not p.is_file():
        current_app.logger.warning("UPLOAD MISS base=%s rel=%s full=%s", base, rel, p)
        abort(404, description="파일을 찾을 수 없습니다.")
    return p


# ----- Range 파싱 -----
def _parse_range(range_header: str | None, size: int):
    if not range_header:
        return None
    m = re.match(r"bytes=(\d*)-(\d*)", range_header.strip())
    if not m:
        return None
    start_s, end_s = m.groups()
    if start_s == "" and end_s == "":
        return None
    if start_s == "":
        length = int(end_s)
        if length <= 0:
            return None
        start = max(0, size - length)
        end = size - 1
    else:
        start = int(start_s)
        end = int(end_s) if end_s else size - 1
    if start > end or start < 0 or end >= size:
        return None
    return start, end


# ASCII 안전 파일명 만들기 (헤더용)
def _ascii_fallback(name: str) -> str:
    # 영문, 숫자, 점/밑줄/대시만 남기고 나머지는 _
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    return safe or "download"


# ----- 파일 스트리밍 (HTTP Range + 권한) -----
@bp.get("/<path:relpath>", endpoint="file")
@login_required
def file(relpath: str):
    if not _can_access_rel(relpath, g.user):
        abort(403)

    # 기본 루트: static/uploads  (상대면 앱 루트 기준 절대화)
    base_dir = current_app.config.get("UPLOAD_ROOT", "static/uploads")
    if not os.path.isabs(base_dir):
        base_dir = str(Path(current_app.root_path) / base_dir)

    p = _resolve_safe_path(base_dir, relpath)

    mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    size = p.stat().st_size

    as_attachment = (request.args.get("dl") or "").lower() in ("1", "true", "yes")
    disp_type = "attachment" if as_attachment else "inline"

    # 🔑 헤더에 한글이 들어가지 않도록 ASCII fallback + RFC5987 filename*
    fname = p.name
    fname_ascii = _ascii_fallback(fname)                # ASCII만
    fname_quoted = quote(fname)                         # UTF-8 percent-encode

    rng = _parse_range(request.headers.get("Range"), size)

    if rng:
        start, end = rng
        length = end - start + 1

        def generate():
            with open(p, "rb") as f:
                f.seek(start)
                remaining = length
                chunk = 1024 * 1024
                while remaining > 0:
                    data = f.read(min(chunk, remaining))
                    if not data:
                        break
                    remaining -= len(data)
                    yield data

        resp = Response(generate(), status=206, mimetype=mime, direct_passthrough=True)
        resp.headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = str(length)
        # ⬇️ ASCII-only filename + UTF-8 filename*
        resp.headers["Content-Disposition"] = (
            f"{disp_type}; filename=\"{fname_ascii}\"; filename*=UTF-8''{fname_quoted}"
        )
        return resp

    def generate_full():
        with open(p, "rb") as f:
            while True:
                data = f.read(1024 * 1024)
                if not data:
                    break
                yield data

    resp = Response(generate_full(), status=200, mimetype=mime, direct_passthrough=True)
    resp.headers["Accept-Ranges"] = "bytes"
    resp.headers["Content-Length"] = str(size)
    resp.headers["Content-Disposition"] = (
        f"{disp_type}; filename=\"{fname_ascii}\"; filename*=UTF-8''{fname_quoted}"
    )
    return resp


__all__ = ("bp",)
