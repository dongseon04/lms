from __future__ import annotations
import os
from urllib.parse import urlparse
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, send_file, current_app, make_response
from sqlalchemy import or_
from helpers.auth import login_required, roles_required
from helpers.utils import _save_upload, _parse_dt
from models import (
    db, User, MentoringTeam, MentoringTeamMember, MentoringReport,
    Project, ProjectTask, ProjectTaskFile, Competition, CompetitionEntry
)
from urllib.parse import urlparse, urljoin

bp = Blueprint("mentoring", __name__, url_prefix="/mentoring")

# ----------------------------------------------------------------------------- #
# 권한 & 유틸
# ----------------------------------------------------------------------------- #
@bp.app_template_global()
def is_instructor_or_admin() -> bool:
    return getattr(g.user, "role", None) in ("instructor", "admin")

def _is_author_or_admin(author_user_id: int) -> bool:
    return (g.user.id == author_user_id) or is_instructor_or_admin()

def _is_team_member(team_id: int | None) -> bool:
    if not team_id:
        return False
    return db.session.query(MentoringTeamMember).filter_by(
        team_id=team_id, user_id=g.user.id
    ).first() is not None

def _safe_redirect_url(target: str, fallback: str):
    if not target:
        return fallback
    base = urlparse(request.host_url)
    test = urlparse(urljoin(request.host_url, target))
    if test.scheme in ("http", "https") and test.netloc == base.netloc:
        return target
    return fallback

def _can_view_project(p: Project) -> bool:
    if is_instructor_or_admin(): return True
    if p.owner_user_id and p.owner_user_id == g.user.id: return True
    if p.team_id and _is_team_member(p.team_id): return True
    return False

def _can_manage_project(p: Project) -> bool:
    if is_instructor_or_admin(): return True
    if p.owner_user_id and p.owner_user_id == g.user.id: return True
    if p.team_id:
        t = MentoringTeam.query.get(p.team_id)
        if t and t.owner_user_id == g.user.id:
            return True
    return False

def _try_delete_local_upload(file_url: str | None):
    if not file_url:
        return
    try:
        parsed = urlparse(file_url)
        if parsed.scheme or parsed.netloc:
            return  # 외부 URL은 삭제하지 않음
        abs_path = os.path.abspath("." + file_url) if file_url.startswith("/") else os.path.abspath(file_url)
        if os.path.isfile(abs_path):
            os.remove(abs_path)
    except Exception:
        pass

def _local_abs_path_from_url(file_url: str) -> str | None:
    """/uploads/... 같은 로컬 경로를 실제 파일 절대경로로 변환"""
    parsed = urlparse(file_url)
    if parsed.scheme or parsed.netloc:
        return None
    return os.path.abspath("." + file_url) if file_url.startswith("/") else os.path.abspath(file_url)

# ----------------------------------------------------------------------------- #
# 홈
# ----------------------------------------------------------------------------- #
@bp.get("/", endpoint="home")
@login_required
def home():
    uid = g.user.id
    tab = (request.args.get("tab") or "reports").strip().lower()
    if tab not in {"reports", "teams", "projects", "competitions"}:
        tab = "reports"

    my_teams = (
        db.session.query(MentoringTeam)
        .join(MentoringTeamMember, MentoringTeamMember.team_id == MentoringTeam.id)
        .filter(MentoringTeamMember.user_id == uid)
        .distinct()
        .all()
    )
    teams_owned = db.session.query(MentoringTeam).filter_by(owner_user_id=uid).all()
    team_ids = [t.id for t in my_teams]

    my_reports = (
        db.session.query(MentoringReport)
        .filter_by(author_user_id=uid)
        .order_by(MentoringReport.created_at.desc())
        .all()
    )

    conds = [Project.owner_user_id == uid]
    if team_ids:
        conds.append(Project.team_id.in_(team_ids))
    my_projects = (
        db.session.query(Project)
        .filter(or_(*conds))
        .order_by(Project.created_at.desc())
        .all()
    )

    members_by_project: dict[int, list[User]] = {}
    for p in my_projects:
        users: list[User] = []
        if p.team_id:
            mems = db.session.query(MentoringTeamMember).filter_by(team_id=p.team_id).all()
            users = [m.user for m in mems if m.user]
        elif p.owner_user_id:
            u = User.query.get(p.owner_user_id)
            users = [u] if u else []
        members_by_project[p.id] = users

    comps = db.session.query(Competition).order_by(
        Competition.apply_deadline.is_(None), Competition.apply_deadline.asc()
    ).all()

    entry_conds = [CompetitionEntry.applicant_user_id == uid]
    if team_ids:
        entry_conds.append(CompetitionEntry.team_id.in_(team_ids))
    my_entries = (
        db.session.query(CompetitionEntry)
        .filter(or_(*entry_conds))
        .order_by(CompetitionEntry.created_at.desc())
        .all()
    )

    return render_template(
        "mentoring.html",
        tab=tab,
        my_reports=my_reports,
        my_teams=my_teams,
        teams_owned=teams_owned,
        my_projects=my_projects,
        members_by_project=members_by_project,
        comps=comps,
        my_entries=my_entries,
    )

# ----------------------------------------------------------------------------- #
# 1) 보고서
# ----------------------------------------------------------------------------- #
@bp.post("/reports/new")
@login_required
def report_new():
    uid = g.user.id
    title = (request.form.get("title") or "").strip()
    content = (request.form.get("content") or "").strip()
    team_id = request.form.get("team_id")
    team_id_int = int(team_id) if team_id and team_id.isdigit() else None

    file = request.files.get("file")
    file_url = _save_upload(file, prefix=f"report_u{uid}") if file else None

    if not title:
        flash("제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="reports"))

    r = MentoringReport(
        author_user_id=uid,
        team_id=team_id_int,
        title=title,
        content=content or None,
        file_url=file_url,
    )
    db.session.add(r)
    db.session.commit()
    flash("보고서가 등록되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="reports"))

@bp.get("/reports/<int:report_id>", endpoint="report_detail")
@login_required
def report_detail(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    if not (_is_author_or_admin(r.author_user_id) or (r.team_id and _is_team_member(r.team_id))):
        abort(403)
    back_to = request.args.get("back")
    return render_template("mentoring/report_detail.html", r=r, back_to=back_to)

@bp.post("/reports/<int:report_id>/delete", endpoint="report_delete")
@login_required
def report_delete(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    if not _is_author_or_admin(r.author_user_id):
        abort(403)
    _try_delete_local_upload(r.file_url)
    db.session.delete(r)
    db.session.commit()
    flash("보고서를 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="reports"))

@bp.post("/reports/<int:report_id>/attachment/delete", endpoint="report_attach_delete")
@login_required
def report_attach_delete(report_id: int):
    r = MentoringReport.query.get_or_404(report_id)
    if not _is_author_or_admin(r.author_user_id):
        abort(403)
    _try_delete_local_upload(r.file_url)
    r.file_url = None
    db.session.commit()
    flash("첨부를 삭제했습니다.", "success")
    return redirect(url_for("mentoring.report_detail", report_id=report_id, back=request.args.get("back") or "reports"))

# ----------------------------------------------------------------------------- #
# 2) 팀
# ----------------------------------------------------------------------------- #
@bp.post("/teams/new")
@login_required
def team_new():
    uid = g.user.id
    name = (request.form.get("name") or "").strip()
    is_solo = bool(request.form.get("is_solo"))
    custom_id = (request.form.get("team_id_custom") or "").strip()

    if not name:
        flash("팀 이름은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    team = MentoringTeam(name=name, owner_user_id=uid, is_solo=is_solo)
    if custom_id:
        if not custom_id.isdigit():
            flash("팀 ID는 숫자여야 합니다.", "error")
            return redirect(url_for("mentoring.home", tab="teams"))
        cid = int(custom_id)
        if MentoringTeam.query.get(cid):
            flash("이미 사용 중인 팀 ID입니다.", "error")
            return redirect(url_for("mentoring.home", tab="teams"))
        team.id = cid

    db.session.add(team)
    db.session.flush()
    db.session.add(MentoringTeamMember(team_id=team.id, user_id=uid, role="leader"))
    db.session.commit()
    flash(f"팀이 생성되었습니다. (팀 ID: {team.id})", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.post("/teams/join")
@login_required
def team_join():
    uid = g.user.id
    team_id = (request.form.get("team_id") or "").strip()
    team_name = (request.form.get("team_name") or "").strip()

    if not team_id.isdigit() or not team_name:
        flash("팀 ID/팀 이름을 모두 입력하세요.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    team_id_int = int(team_id)
    team = MentoringTeam.query.get(team_id_int)
    if not team or team.name != team_name:
        flash("팀 ID 혹은 팀 이름이 일치하지 않습니다.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    exists = MentoringTeamMember.query.filter_by(team_id=team_id_int, user_id=uid).first()
    if exists:
        flash("이미 해당 팀에 속해 있습니다.", "error")
        return redirect(url_for("mentoring.home", tab="teams"))

    db.session.add(MentoringTeamMember(team_id=team_id_int, user_id=uid, role="member"))
    db.session.commit()
    flash("팀에 참여했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.get("/teams/<int:team_id>", endpoint="team_detail")
@login_required
def team_detail(team_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    if not (is_instructor_or_admin() or _is_team_member(t.id) or t.owner_user_id == g.user.id):
        abort(403)
    members = (
        db.session.query(MentoringTeamMember)
        .filter_by(team_id=t.id)
        .join(User, User.id == MentoringTeamMember.user_id)
        .distinct(MentoringTeamMember.user_id)
        .order_by(MentoringTeamMember.joined_at.asc())
        .all()
    )
    back_to = request.args.get("back")
    return render_template("mentoring/team_detail.html", t=t, members=members, back_to=back_to)

@bp.post("/teams/<int:team_id>/leave", endpoint="team_leave")
@login_required
def team_leave(team_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    m = MentoringTeamMember.query.filter_by(team_id=team_id, user_id=g.user.id).first()
    if not m:
        abort(403)
    if t.owner_user_id == g.user.id:
        flash("팀장은 탈퇴할 수 없습니다. 권한을 이전한 뒤 탈퇴하세요.", "error")
        return redirect(url_for("mentoring.team_detail", team_id=team_id))
    db.session.delete(m)
    db.session.commit()
    flash("팀에서 탈퇴했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.get("/users/<int:user_id>", endpoint="user_profile_view")
@login_required
def user_profile_view(user_id: int):
    u = User.query.get_or_404(user_id)
    return render_template("mentoring/user_profile_view.html", u=u, editable=False)

@bp.post("/teams/<int:team_id>/delete", endpoint="team_delete")
@roles_required("admin", "instructor")
def team_delete(team_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    db.session.delete(t)
    db.session.commit()
    flash("팀을 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="teams"))

@bp.post("/teams/<int:team_id>/members/<int:user_id>/remove", endpoint="team_member_remove")
@login_required
def team_member_remove(team_id: int, user_id: int):
    t = MentoringTeam.query.get_or_404(team_id)
    if not (is_instructor_or_admin() or g.user.id == t.owner_user_id):
        abort(403)
    if user_id == t.owner_user_id:
        flash("팀장은 강퇴할 수 없습니다.", "error")
        return redirect(url_for("mentoring.team_detail", team_id=team_id))
    m = MentoringTeamMember.query.filter_by(team_id=team_id, user_id=user_id).first()
    if not m:
        flash("해당 사용자는 팀원이 아닙니다.", "error")
        return redirect(url_for("mentoring.team_detail", team_id=team_id))
    db.session.delete(m)
    db.session.commit()
    flash("팀원을 제거했습니다.", "success")
    return redirect(url_for("mentoring.team_detail", team_id=team_id))

# ----------------------------------------------------------------------------- #
# 3) 프로젝트/작업 (+ 파일 업로드)
# ----------------------------------------------------------------------------- #
@bp.post("/projects/new")
@login_required
def project_new():
    uid = g.user.id
    title = (request.form.get("title") or "").strip()
    description = (request.form.get("description") or "").strip()
    team_id = request.form.get("team_id")
    team_id_int = int(team_id) if team_id and team_id.isdigit() else None

    if not title:
        flash("프로젝트 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="projects"))

    p = Project(
        title=title,
        description=description or None,
        team_id=team_id_int,
        owner_user_id=uid if not team_id_int else None,
        github_repo_url=None,
    )
    db.session.add(p)
    db.session.commit()
    flash("프로젝트가 생성되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="projects"))

@bp.get("/projects/<int:project_id>", endpoint="project_detail")
@login_required
def project_detail(project_id: int):
    p = Project.query.get_or_404(project_id)
    if not _can_view_project(p):
        abort(403)
    back_to = request.args.get("back")
    if p.team_id:
        mems = MentoringTeamMember.query.filter_by(team_id=p.team_id).all()
        assignees = [m.user for m in mems if m.user]
    else:
        assignees = [User.query.get(p.owner_user_id)] if p.owner_user_id else []
    can_manage = _can_manage_project(p)
    return render_template("mentoring/project_detail.html", p=p, assignees=assignees, back_to=back_to, can_manage=can_manage)

@bp.post("/projects/<int:project_id>/delete", endpoint="project_delete")
@login_required
def project_delete(project_id: int):
    p = Project.query.get_or_404(project_id)
    if not _can_manage_project(p):
        abort(403)
    db.session.delete(p)
    db.session.commit()
    flash("프로젝트를 삭제했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="projects"))

@bp.post("/tasks/new", endpoint="task_new")
@login_required
def task_new():
    project_id = request.form.get("project_id")
    title = (request.form.get("title") or "").strip()
    description = (request.form.get("description") or "").strip()
    due_at = request.form.get("due_at")
    assignee_id = request.form.get("assignee_id")
    upfile = request.files.get("file")  # 👈 첨부 파일

    if not project_id or not project_id.isdigit() or not title:
        flash("프로젝트와 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="projects"))

    p = Project.query.get(int(project_id))
    if not p or not _can_manage_project(p):
        abort(403)

    dt = _parse_dt(due_at) if due_at else None
    if due_at and not dt:
        flash("마감 형식은 YYYY-MM-DD HH:MM 입니다.", "error")
        return redirect(url_for("mentoring.project_detail", project_id=p.id))

    assignee_id_int = int(assignee_id) if assignee_id and assignee_id.isdigit() else None

    t = ProjectTask(
        project_id=p.id,
        title=title,
        description=description or None,
        due_at=dt,
        assignee_user_id=assignee_id_int,
    )
    db.session.add(t)
    db.session.flush()  # t.id 확보

    # 파일이 있으면 첨부 레코드 생성
    if upfile and upfile.filename:
        file_url = _save_upload(upfile, prefix=f"task_{t.id}")
        size_bytes = None
        local_abs = _local_abs_path_from_url(file_url)
        if local_abs and os.path.isfile(local_abs):
            try:
                size_bytes = os.path.getsize(local_abs)
            except Exception:
                pass
        db.session.add(ProjectTaskFile(
            task_id=t.id,
            file_url=file_url,
            filename=upfile.filename,
            size_bytes=size_bytes,
            uploader_user_id=g.user.id
        ))

    db.session.commit()
    flash("작업이 추가되었습니다.", "success")
    return redirect(url_for("mentoring.project_detail", project_id=p.id))

@bp.get("/tasks/<int:task_id>", endpoint="task_detail")
@login_required
def task_detail(task_id: int):
    t = ProjectTask.query.get(task_id)
    if not t:
        # 🔴 뒤로가기 등으로 삭제된 작업 상세에 접근한 경우: 404 대신 프로젝트/작업 메인으로
        flash("존재하지 않거나 삭제된 작업입니다.", "error")
        # 템플릿에서 back='projects'를 붙여 링크하고 있으므로 그대로 활용
        return redirect(url_for("mentoring.home", tab="projects"))

    p = t.project
    if not _can_view_project(p):
        abort(403)
    back_to = request.args.get("back")
    can_manage = _can_manage_project(p)
    return render_template(
        "mentoring/task_detail.html", t=t, p=p, back_to=back_to, can_manage=can_manage
    )

@bp.post("/tasks/<int:task_id>/delete", endpoint="task_delete")
@login_required
def task_delete(task_id: int):
    t = ProjectTask.query.get_or_404(task_id)
    p = t.project
    if not _can_manage_project(p):
        abort(403)

    # 물리 첨부삭제
    for f in t.attachments:
        _try_delete_local_upload(f.file_url)

    db.session.delete(t)
    db.session.commit()

    # 다음 이동 위치 (프로젝트 상세, 표시용 플래그 src=task_del)
    next_url = request.form.get("next") or url_for(
        "mentoring.project_detail", project_id=p.id, back="projects", src="task_del"
    )

    # AJAX 요청이면 JSON 반환 (프론트에서 location.replace로 교체 이동)
    if request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.form.get("ajax") == "1":
        return {"ok": True, "redirect": next_url}

    # 일반 폼 제출은 그냥 리다이렉트
    return redirect(next_url)

# ----- 작업 첨부: 추가 / 삭제 / 다운로드 ------------------------------------- #
@bp.post("/tasks/<int:task_id>/files/add", endpoint="task_file_add")
@login_required
def task_file_add(task_id: int):
    t = ProjectTask.query.get_or_404(task_id)
    p = t.project
    if not _can_manage_project(p):
        abort(403)

    upfile = request.files.get("file")
    if not upfile or not upfile.filename:
        flash("업로드할 파일을 선택하세요.", "error")
        return redirect(url_for("mentoring.task_detail", task_id=t.id))

    file_url = _save_upload(upfile, prefix=f"task_{t.id}")
    size_bytes = None
    local_abs = _local_abs_path_from_url(file_url)
    if local_abs and os.path.isfile(local_abs):
        try:
            size_bytes = os.path.getsize(local_abs)
        except Exception:
            pass

    att = ProjectTaskFile(
        task_id=t.id,
        file_url=file_url,
        filename=upfile.filename,
        size_bytes=size_bytes,
        uploader_user_id=g.user.id
    )
    db.session.add(att)
    db.session.commit()
    flash("파일을 첨부했습니다.", "success")
    return redirect(url_for("mentoring.task_detail", task_id=t.id))

@bp.post("/tasks/files/<int:file_id>/delete", endpoint="task_file_delete")
@login_required
def task_file_delete(file_id: int):
    f = ProjectTaskFile.query.get_or_404(file_id)
    t = f.task
    p = t.project
    if not _can_manage_project(p):
        abort(403)
    _try_delete_local_upload(f.file_url)
    db.session.delete(f)
    db.session.commit()
    flash("첨부 파일을 삭제했습니다.", "success")
    return redirect(url_for("mentoring.task_detail", task_id=t.id))

@bp.get("/tasks/files/<int:file_id>/download", endpoint="task_file_download")
@login_required
def task_file_download(file_id: int):
    f = ProjectTaskFile.query.get_or_404(file_id)
    t = f.task
    p = t.project
    if not _can_view_project(p):
        abort(403)

    # 외부 URL이면 그대로 리디렉트
    parsed = urlparse(f.file_url)
    if parsed.scheme or parsed.netloc:
        return redirect(f.file_url)

    # 로컬 파일이면 다운로드로 전송
    abs_path = _local_abs_path_from_url(f.file_url)
    if not abs_path or not os.path.isfile(abs_path):
        abort(404)
    return send_file(abs_path, as_attachment=True, download_name=(f.filename or os.path.basename(abs_path)))

# ----------------------------------------------------------------------------- #
# 4) 공모전
# ----------------------------------------------------------------------------- #
@bp.post("/competitions/new", endpoint="comp_new")
@roles_required("admin", "instructor")
def comp_new():
    title = (request.form.get("title") or "").strip()
    host = (request.form.get("host") or "").strip()
    url_ = (request.form.get("url") or "").strip()
    deadline = request.form.get("apply_deadline")

    dt = _parse_dt(deadline) if deadline else None
    if deadline and not dt:
        flash("마감 형식은 YYYY-MM-DD HH:MM 입니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    if not title:
        flash("공모전 제목은 필수입니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    c = Competition(title=title, host=host or None, url=url_ or None, apply_deadline=dt)
    db.session.add(c)
    db.session.commit()
    flash("공모전이 등록되었습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

@bp.post("/competitions/apply", endpoint="comp_apply")
@login_required
def comp_apply():
    uid = g.user.id
    competition_id = request.form.get("competition_id")
    team_id = request.form.get("team_id")
    project_id = request.form.get("project_id")

    if not competition_id or not competition_id.isdigit():
        flash("공모전 ID가 올바르지 않습니다.", "error")
        return redirect(url_for("mentoring.home", tab="competitions"))

    entry = CompetitionEntry(
        competition_id=int(competition_id),
        team_id=int(team_id) if team_id and team_id.isdigit() else None,
        applicant_user_id=uid,
        project_id=int(project_id) if project_id and project_id.isdigit() else None,
        status="submitted",
    )
    db.session.add(entry)
    db.session.commit()
    flash("공모전에 신청했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))

@bp.get("/competitions/<int:competition_id>", endpoint="comp_detail_page")
@login_required
def comp_detail_page(competition_id: int):
    c = Competition.query.get_or_404(competition_id)
    back_to = request.args.get("back")
    return render_template("mentoring/competition_detail.html", c=c, back_to=back_to)

@bp.post("/competition_entries/<int:entry_id>/cancel", endpoint="comp_entry_cancel")
@login_required
def comp_entry_cancel(entry_id: int):
    e = CompetitionEntry.query.get_or_404(entry_id)
    if not (e.applicant_user_id == g.user.id or is_instructor_or_admin()):
        abort(403)
    db.session.delete(e)
    db.session.commit()
    flash("신청을 취소했습니다.", "success")
    return redirect(url_for("mentoring.home", tab="competitions"))