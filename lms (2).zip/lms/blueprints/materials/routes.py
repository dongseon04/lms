# blueprints/materials/routes.py
from __future__ import annotations
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import re
from hashlib import md5
import mimetypes

from flask import (
    Blueprint, abort, redirect, render_template, url_for,
    request, Response
)
from helpers.auth import login_required
from models import db, Material, MaterialEvent, Enrollment, MaterialBlob

bp = Blueprint("materials", __name__, url_prefix="/materials")


# ------------------------------
# 권한
# ------------------------------
def _can_access(material: Material, user) -> bool:
    # 관리자/교수는 통과, 학생은 수강 여부 체크
    if getattr(user, "role", None) in ("admin", "instructor"):
        return True
    ok = db.session.query(Enrollment.id).filter_by(
        user_id=user.id, course_id=material.course_id
    ).first()
    return bool(ok)


# ------------------------------
# 재생 소스 선택: DB(blob) → 외부URL → 로컬파일
# ------------------------------
def _src_url(material: Material) -> str | None:
    # 1) DB 저장본이 있으면 최우선 (디스크 파일 없어도 재생 가능)
    if getattr(material, "blob", None) and material.blob.data:
        return url_for("materials.stream", material_id=material.id)
    # 2) 외부 스트리밍/직접 URL
    if material.storage_url:
        return material.storage_url
    # 3) 로컬 업로드 파일
    if material.file_path:
        return url_for("uploads.file", relpath=material.file_path)
    return None


# ------------------------------
# YouTube URL → embed 변환
# ------------------------------
def _youtube_embed(url: str) -> str | None:
    if not url:
        return None
    u = urlparse(url)
    host = (u.netloc or "").lower()
    path = (u.path or "").strip("/")

    vid = None
    if "youtube.com" in host:
        if path.startswith("watch"):
            vid = parse_qs(u.query).get("v", [None])[0]
        elif path.startswith("shorts/"):
            vid = path.split("/", 1)[1]
        elif path.startswith("embed/"):
            # 이미 embed 링크면 그대로 사용
            return url
    elif "youtu.be" in host:
        vid = path.split("/")[0]

    if not vid:
        return None

    # 시작 시각 지원: ?start= / ?t=
    q = parse_qs(u.query)
    start = None
    if "start" in q:
        start = q["start"][0]
    elif "t" in q:
        t = q["t"][0]
        try:
            if t.endswith("s"):
                t = t[:-1]
            if "m" in t:
                m, s = t.split("m", 1)
                start = str(int(m) * 60 + int(s or 0))
            else:
                start = str(int(t))
        except Exception:
            start = None

    base = f"https://www.youtube.com/embed/{vid}?rel=0&modestbranding=1&playsinline=1"
    if start:
        base += f"&start={start}"
    return base


# ------------------------------
# Range 파서 (대소문자 무시, 첫 구간만 처리)
# ------------------------------
def _parse_range(range_header: str | None, size: int):
    if not range_header:
        return None
    m = re.match(r"bytes=(\d*)-(\d*)(?:,.*)?$", range_header.strip(), re.I)
    if not m:
        return None
    start_s, end_s = m.groups()
    if start_s == "" and end_s == "":
        return None
    if start_s == "":
        # 뒤에서 length 바이트
        try:
            length = int(end_s)
        except Exception:
            return None
        if length <= 0:
            return None
        start = max(0, size - length)
        end = size - 1
    else:
        try:
            start = int(start_s)
        except Exception:
            return None
        end = int(end_s) if end_s else size - 1
    if start > end or start < 0 or start >= size:
        # 요청 범위가 파일 끝을 넘어가면 416을 내보내도록 호출부에서 처리
        return ("invalid", None)
    if end >= size:
        end = size - 1
    return start, end


# ------------------------------
# 재생 페이지
# ------------------------------
@bp.get("/<int:material_id>/play")
@login_required
def play(material_id: int):
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)
    if m.kind == "file":
        abort(400, description="파일 자료는 재생 대상이 아닙니다.")

    # 로그: play
    db.session.add(MaterialEvent(user_id=g.user.id, material_id=m.id, action="play"))
    db.session.commit()

    src = _src_url(m) or abort(404, description="재생 소스를 찾을 수 없습니다.")
    embed = _youtube_embed(src)  # 내부 stream이면 None → HTML5 <video>로 재생

    # 유튜브면 JS API 강제활성 + origin 부여
    if embed:
        u = urlparse(embed)
        q = parse_qs(u.query)
        q["enablejsapi"] = ["1"]
        q["origin"] = [request.host_url.rstrip("/")]
        embed = urlunparse(
            (u.scheme, u.netloc, u.path, u.params, urlencode(q, doseq=True), u.fragment)
        )

    back_url = url_for("course_detail.detail", course_id=m.course_id, tab="materials")
    return render_template(
        "material_play.html",
        title=m.title,
        src=src,
        embed=embed,
        material=m,
        back_url=back_url,
    )


# ------------------------------
# DB 스트리밍 (HTTP Range/HEAD/ETag 지원)
# ------------------------------
@bp.route("/<int:material_id>/stream", methods=["GET", "HEAD"])
@login_required
def stream(material_id: int):
    """DB(LONGBLOB)에서 바로 시킹 가능한 스트리밍."""
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    b = getattr(m, "blob", None)
    if not b or not b.data:
        abort(404, description="DB 저장 영상이 없습니다.")

    data = b.data  # bytes
    size = b.size_bytes or len(data)
    mime = (b.mime_type or "application/octet-stream")

    # 캐시/검증용 ETag (약한 ETag)
    etag = f'W/"{(b.checksum_md5 or md5(data).hexdigest())}-{size}"'

    # 304 Not Modified
    inm = request.headers.get("If-None-Match")
    if inm and inm == etag:
        resp = Response(status=304)
        resp.headers["ETag"] = etag
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = "0"
        return resp

    # HEAD는 메타만
    if request.method == "HEAD":
        resp = Response(status=200, mimetype=mime)
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = str(size)
        resp.headers["ETag"] = etag
        resp.headers["Cache-Control"] = "private, max-age=3600"
        return resp

    # Range 처리
    rng = _parse_range(request.headers.get("Range"), size)
    if rng == ("invalid", None):
        # 416 Range Not Satisfiable
        resp = Response(status=416)
        resp.headers["Content-Range"] = f"bytes */{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["ETag"] = etag
        return resp

    if isinstance(rng, tuple) and len(rng) == 2:
        start, end = rng
        chunk = data[start:end + 1]
        resp = Response(chunk, 206, mimetype=mime, direct_passthrough=True)
        resp.headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        resp.headers["Accept-Ranges"] = "bytes"
        resp.headers["Content-Length"] = str(len(chunk))
        resp.headers["ETag"] = etag
        resp.headers["Cache-Control"] = "private, max-age=3600"
        return resp

    # Range 없으면 전체 전송
    resp = Response(data, 200, mimetype=mime, direct_passthrough=True)
    resp.headers["Accept-Ranges"] = "bytes"
    resp.headers["Content-Length"] = str(size)
    resp.headers["ETag"] = etag
    resp.headers["Cache-Control"] = "private, max-age=3600"
    return resp


# ------------------------------
# 진행률 하트비트
# ------------------------------
@bp.post("/<int:material_id>/progress")
@login_required
def progress(material_id: int):
    """재생 중간 진행률(초) 기록."""
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    if request.is_json:
        sec = request.json.get("sec")
    else:
        sec = request.form.get("sec")
    try:
        seconds = int(sec) if sec is not None else None
    except Exception:
        seconds = None

    if not seconds or seconds <= 0:
        return ("", 204)

    db.session.add(
        MaterialEvent(
            user_id=g.user.id,
            material_id=m.id,
            action="progress",
            seconds_watched=seconds,
        )
    )
    db.session.commit()
    return ("", 204)


# ------------------------------
# 완료 처리
# ------------------------------
@bp.post("/<int:material_id>/complete")
@login_required
def complete(material_id: int):
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)

    if request.is_json:
        sec = request.json.get("sec")
    else:
        sec = request.form.get("sec")
    try:
        seconds = int(sec) if sec is not None else None
    except Exception:
        seconds = None

    db.session.add(
        MaterialEvent(
            user_id=g.user.id,
            material_id=m.id,
            action="complete",
            seconds_watched=seconds,
        )
    )
    db.session.commit()
    return ("", 204)


# ------------------------------
# 다운로드 (허용 시)
# ------------------------------
@bp.get("/<int:material_id>/download")
@login_required
def download(material_id: int):
    """is_downloadable이면 저장 위치 무관하게 내려줌."""
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if not _can_access(m, g.user):
        abort(403)
    if not m.is_downloadable:
        abort(403, description="다운로드가 허용되지 않은 자료입니다.")

    # 로그
    db.session.add(MaterialEvent(user_id=g.user.id, material_id=m.id, action="download"))
    db.session.commit()

    # 1) 외부 URL
    if m.storage_url:
        return redirect(m.storage_url)
    # 2) 로컬 파일
    if m.file_path:
        return redirect(url_for("uploads.file", relpath=m.file_path, dl=1))
    # 3) DB blob
    b = getattr(m, "blob", None)
    if b and b.data:
        filename = (m.title or "video").replace("/", "_")
        # 확장자 추정
        ext = mimetypes.guess_extension(b.mime_type or "") or ".bin"
        resp = Response(b.data, 200, mimetype=b.mime_type or "application/octet-stream")
        resp.headers["Content-Length"] = str(b.size_bytes or len(b.data))
        resp.headers["Content-Disposition"] = f'attachment; filename="{filename}{ext}"'
        return resp

    abort(404, description="다운로드 대상을 찾을 수 없습니다.")


# ------------------------------
# DB 업로드 (교수/관리자 전용)
# ------------------------------
@bp.post("/<int:material_id>/blob")
@login_required
def upload_blob(material_id: int):
    from flask import g

    m = db.session.get(Material, material_id) or abort(404)
    if getattr(g.user, "role", None) not in ("admin", "instructor"):
        abort(403)

    f = request.files.get("file")
    if not f or not f.filename:
        abort(400, description="파일이 필요합니다.")

    # ⚠️ 대용량은 메모리 사용 많음 → 운영시 청크 방식 권장
    blob_bytes = f.read()
    size = len(blob_bytes)

    # MIME 추정 (브라우저가 못 주는 경우 대비)
    mime = f.mimetype
    if not mime or mime == "application/octet-stream":
        mime = mimetypes.guess_type(f.filename)[0] or "application/octet-stream"

    checksum = md5(blob_bytes).hexdigest()

    b = db.session.query(MaterialBlob).filter_by(material_id=m.id).first()
    if b:
        b.data = blob_bytes
        b.size_bytes = size
        b.mime_type = mime
        b.checksum_md5 = checksum
    else:
        db.session.add(MaterialBlob(
            material_id=m.id,
            data=blob_bytes,
            size_bytes=size,
            mime_type=mime,
            checksum_md5=checksum,
        ))

    # 재생 가능 상태로 정리
    if m.kind == "file":
        m.kind = "video"
    if not m.is_published:
        m.is_published = True

    db.session.commit()
    return redirect(url_for("materials.play", material_id=m.id))
