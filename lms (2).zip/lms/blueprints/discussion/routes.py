# blueprints/discussion/routes.py
from __future__ import annotations
from collections import defaultdict
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, g, jsonify
from sqlalchemy import func
from sqlalchemy.orm import joinedload

from helpers.auth import login_required
from models import (
    db,
    Course,
    Enrollment,
    DiscussionThread,
    DiscussionComment,
    DiscussionCommentLike,  # ✅ 추가
    User,
)

bp = Blueprint("discussion", __name__, url_prefix="/discussion")


def _ensure_enrolled(uid: int, course_id: int):
    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=course_id).first()
    if not ok:
        abort(403)


# 스레드 상세
@bp.get("/<int:tid>")
@login_required
def view(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    _ensure_enrolled(g.user.id, th.course_id)

    # ✅ 댓글 + 작성자 + 좋아요 로딩(N+1 방지)
    rows = (
        db.session.query(DiscussionComment)
        .options(
            joinedload(DiscussionComment.user),
            joinedload(DiscussionComment.likes),
        )
        .filter(DiscussionComment.thread_id == th.id)
        .order_by(DiscussionComment.created_at.asc())
        .all()
    )

    # 내가 좋아요한 댓글 id 집합
    comment_ids = [c.id for c in rows]
    liked_ids = set()
    if comment_ids:
        liked_rows = (
            db.session.query(DiscussionCommentLike.comment_id)
            .filter(
                DiscussionCommentLike.user_id == g.user.id,
                DiscussionCommentLike.comment_id.in_(comment_ids),
            )
            .all()
        )
        liked_ids = {cid for (cid,) in liked_rows}

    # 표시용 필드 세팅
    for c in rows:
        c._likes_count = len(c.likes)
        c._liked_by_me = c.id in liked_ids

    # 트리 빌드
    by_parent: dict[int | None, list[DiscussionComment]] = defaultdict(list)
    for c in rows:
        by_parent[c.parent_id].append(c)

    def build(parent_id=None):
        out = []
        for c in by_parent.get(parent_id, []):
            out.append({"c": c, "children": build(c.id)})
        return out

    tree = build(None)
    total_comments = len(rows)

    return render_template(
        "discussion_view.html",
        thread=th,
        tree=tree,
        total_comments=total_comments,
        back_url=url_for("course_detail.detail", course_id=th.course_id, tab="discussion"),
    )


# 댓글/대댓글 작성
@bp.post("/<int:tid>/comment")
@login_required
def comment(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    _ensure_enrolled(g.user.id, th.course_id)

    body = (request.form.get("body") or "").strip()
    parent_id = request.form.get("parent_id") or None
    parent_id = int(parent_id) if parent_id else None

    if not body:
        flash("내용을 입력하세요.", "error")
        return redirect(url_for("discussion.view", tid=tid) + "#write")

    if parent_id:
        p = db.session.get(DiscussionComment, parent_id)
        if not p or p.thread_id != tid:
            flash("잘못된 요청입니다.", "error")
            return redirect(url_for("discussion.view", tid=tid))

    c = DiscussionComment(thread_id=tid, user_id=g.user.id, parent_id=parent_id, body=body)
    db.session.add(c)
    db.session.commit()
    return redirect(url_for("discussion.view", tid=tid) + f"#c{c.id}")


# ✅ 댓글 좋아요 토글
@bp.post("/<int:tid>/comment/<int:cid>/like")
@login_required
def like_comment(tid: int, cid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    _ensure_enrolled(g.user.id, th.course_id)

    c = db.session.get(DiscussionComment, cid) or abort(404)
    if c.thread_id != tid:
        abort(400)

    existed = DiscussionCommentLike.query.filter_by(comment_id=cid, user_id=g.user.id).first()
    if existed:
        db.session.delete(existed)
        db.session.commit()
        liked = False
    else:
        db.session.add(DiscussionCommentLike(comment_id=cid, user_id=g.user.id))
        db.session.commit()
        liked = True

    count = (
        db.session.query(func.count(DiscussionCommentLike.user_id))
        .filter(DiscussionCommentLike.comment_id == cid)
        .scalar()
        or 0
    )
    return jsonify({"ok": True, "liked": liked, "count": int(count)})
