from __future__ import annotations
import os, time
from typing import Optional
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, current_app, g
from werkzeug.utils import secure_filename
from helpers.auth import login_required
from extensions import db
from models import User

bp = Blueprint("profile", __name__, url_prefix="/profile")

# ---- 권한 ----
def _can_edit(target: User) -> bool:
    u = g.user
    return bool(u and target and (u.id == target.id or u.role == "admin"))

def _can_view(target: User) -> bool:
    u = g.user
    return bool(u and target and (u.id == target.id or u.role in ("admin", "instructor")))

def _role_of(u: User | None) -> str:
    return (getattr(u, "role", "") or "").strip().lower()

def _is_student(u: User | None) -> bool:
    return _role_of(u) == "student"

# ---- 파일 유틸 ----
def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

def _ext_ok(filename: str, allow: set[str]) -> bool:
    if "." not in filename:
        return False
    return filename.rsplit(".", 1)[-1].lower() in allow

def _save_file(file_storage, subdir: str, allow_exts: set[str]) -> Optional[str]:
    if not file_storage or not getattr(file_storage, "filename", ""):
        return None
    fn = secure_filename(file_storage.filename)
    if not _ext_ok(fn, allow_exts):
        return None
    root = current_app.config.get("UPLOAD_ROOT")
    _ensure_dir(os.path.join(root, subdir))
    ext = fn.rsplit(".", 1)[-1].lower()
    new_name = f"{int(time.time()*1000)}_{g.user.id}.{ext}"
    abs_path = os.path.join(root, subdir, new_name)
    file_storage.save(abs_path)
    # 웹 경로로 저장
    return f"/static/uploads/{subdir}/{new_name}"

def _delete_webfile_if_exists(web_path: Optional[str]) -> None:
    """'/static/uploads/...' 형태의 경로를 실제 파일로 변환해 삭제 시도"""
    if not web_path:
        return
    prefix = "/static/uploads/"
    if not web_path.startswith(prefix):
        return
    rel = web_path[len(prefix):].lstrip("/")
    abs_path = os.path.join(current_app.config["UPLOAD_ROOT"], rel)
    try:
        if os.path.exists(abs_path):
            os.remove(abs_path)
    except Exception:
        pass

# ---- 라우트 ----

@bp.get("/", endpoint="home")
@login_required
def home():
    return redirect(url_for("profile.view", user_id=g.user.id))

@bp.get("/<int:user_id>", endpoint="view")
@login_required
def view(user_id: int):
    u = db.session.get(User, user_id)
    if not u or not _can_view(u):
        abort(403)
    show_resume = _is_student(u)  # 학생만 이력서 섹션 노출
    return render_template("profile.html", u=u, editable=_can_edit(u), show_resume=show_resume)

# 텍스트 업데이트 (+ school)
@bp.post("/<int:user_id>/update", endpoint="update")
@login_required
def update(user_id: int):
    target = db.session.get(User, user_id)
    if not target: abort(404)
    if not _can_edit(target): abort(403)

    target.email      = (request.form.get("email") or "").strip() or target.email
    target.phone      = (request.form.get("phone") or "").strip() or None
    target.student_no = (request.form.get("student_no") or "").strip() or None
    target.school     = (request.form.get("school") or "").strip() or None
    target.github_url = (request.form.get("github_url") or "").strip() or None

    db.session.commit()
    flash("프로필을 업데이트했습니다.", "success")
    return redirect(url_for("profile.view", user_id=user_id))

# 아바타 업로드
@bp.post("/<int:user_id>/avatar", endpoint="avatar_upload")
@login_required
def avatar_upload(user_id: int):
    target = db.session.get(User, user_id)
    if not target: abort(404)
    if not _can_edit(target): abort(403)

    f = request.files.get("avatar")
    if not f or not f.filename:
        flash("업로드할 이미지가 없습니다.", "error")
        return redirect(url_for("profile.view", user_id=user_id))

    rel = _save_file(
        f,
        current_app.config.get("AVATAR_SUBDIR", "avatars"),
        current_app.config.get("ALLOWED_IMAGE_EXTS", {"png","jpg","jpeg","gif"})
    )
    if not rel:
        flash("지원하지 않는 이미지 형식입니다. (png, jpg, jpeg, gif)", "error")
        return redirect(url_for("profile.view", user_id=user_id))

    _delete_webfile_if_exists(target.profile_image)
    target.profile_image = rel
    db.session.commit()
    flash("프로필 사진을 변경했습니다.", "success")
    return redirect(url_for("profile.view", user_id=user_id))

# 아바타 삭제
@bp.post("/<int:user_id>/avatar/delete", endpoint="avatar_delete")
@login_required
def avatar_delete(user_id: int):
    target = db.session.get(User, user_id)
    if not target: abort(404)
    if not _can_edit(target): abort(403)

    _delete_webfile_if_exists(target.profile_image)
    target.profile_image = None
    db.session.commit()
    flash("프로필 사진을 삭제했습니다.", "success")
    return redirect(url_for("profile.view", user_id=user_id))

# 이력서 업로드 (학생만)
@bp.post("/<int:user_id>/resume", endpoint="resume_upload")
@login_required
def resume_upload(user_id: int):
    target = db.session.get(User, user_id)
    if not target: abort(404)
    if not _can_edit(target): abort(403)
    if not _is_student(target):  # 학생만 허용
        abort(403)

    f = request.files.get("resume")
    if not f or not f.filename:
        flash("업로드할 파일이 없습니다.", "error")
        return redirect(url_for("profile.view", user_id=user_id))

    if not _ext_ok(f.filename, current_app.config.get("ALLOWED_DOC_EXTS", {"pdf","doc","docx"})):
        flash("이력서는 pdf/doc/docx만 허용됩니다.", "error")
        return redirect(url_for("profile.view", user_id=user_id))

    rel = _save_file(
        f,
        current_app.config.get("RESUME_SUBDIR", "resumes"),
        current_app.config.get("ALLOWED_DOC_EXTS", {"pdf","doc","docx"})
    )
    if not rel:
        flash("이력서 업로드에 실패했습니다.", "error")
        return redirect(url_for("profile.view", user_id=user_id))

    _delete_webfile_if_exists(target.resume_file)
    target.resume_file = rel
    db.session.commit()
    flash("이력서를 업로드했습니다.", "success")
    return redirect(url_for("profile.view", user_id=user_id))

# 이력서 삭제 (학생만)
@bp.post("/<int:user_id>/resume/delete", endpoint="resume_delete")
@login_required
def resume_delete(user_id: int):
    target = db.session.get(User, user_id)
    if not target: abort(404)
    if not _can_edit(target): abort(403)
    if not _is_student(target):  # 학생만 허용
        abort(403)

    _delete_webfile_if_exists(target.resume_file)
    target.resume_file = None
    db.session.commit()
    flash("이력서를 삭제했습니다.", "success")
    return redirect(url_for("profile.view", user_id=user_id))