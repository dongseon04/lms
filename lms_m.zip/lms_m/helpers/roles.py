# helpers/roles.py
from __future__ import annotations
from typing import Optional, TYPE_CHECKING, Iterable
from flask import g, abort
from extensions import db

if TYPE_CHECKING:
    from models import Course, User, Enrollment

# ────────────────────────────────────────────────────────────────
# 내부 유틸
# ────────────────────────────────────────────────────────────────
def _current_user() -> Optional["User"]:
    return getattr(g, "user", None)

def _norm_role(user: Optional["User"]) -> str:
    return ((getattr(user, "role", "") or "").strip().lower()) if user else ""

def _is_admin_like(user: Optional["User"]) -> bool:
    # is_admin 플래그, 문자열 역할, role_id(예: 1=관리자)까지 폭넓게 허용
    if not user:
        return False
    role = _norm_role(user)
    return bool(
        getattr(user, "is_admin", False)
        or role in {"admin", "administrator", "관리자"}
        or getattr(user, "role_id", None) in {1}
    )

# 스키마 차이를 흡수하기 위한 후보 컬럼 목록 (값이 있는 것만 사용)
_OWNER_CANDIDATES: tuple[str, ...] = (
    "instructor_user_id",
    "owner_user_id",
    "professor_user_id",
    "teacher_id",
    "created_by",
)

_INSTRUCTOR_ENROLLMENT_ROLES: tuple[str, ...] = (
    "instructor", "teacher", "ta", "professor"
)

# ────────────────────────────────────────────────────────────────
# 공개 API
# ────────────────────────────────────────────────────────────────
def is_prof_like(user: Optional["User"] = None) -> bool:
    """교수/강사/관리자 판정 (문자열 역할 + is_admin)"""
    u = user or _current_user()
    if not u:
        return False
    if _is_admin_like(u):
        return True
    return _norm_role(u) in {"professor", "instructor", "teacher"}

def get_course_owner_ids(course: "Course") -> list[int]:
    """코스의 소유/담당자로 보이는 모든 사용자 id를 반환(값이 있는 필드만)."""
    ids: list[int] = []
    for name in _OWNER_CANDIDATES:
        if hasattr(course, name):
            val = getattr(course, name)
            if isinstance(val, int) and val > 0:
                ids.append(val)
    # 중복 제거
    return list(dict.fromkeys(ids))

def is_course_owner_or_admin(course: "Course", user: Optional["User"] = None) -> bool:
    """관리자 또는 course의 소유/담당자 여부."""
    u = user or _current_user()
    if not u:
        return False
    if _is_admin_like(u):
        return True
    return getattr(u, "id", None) in get_course_owner_ids(course)

def is_course_staff_or_admin(course: "Course", user: Optional["User"] = None) -> bool:
    """
    관리자 or 소유/담당자 or (Enrollment.role 이 강사/조교 계열) 이면 True
    - 과제/자료 삭제, 업로드 등 고권한에 사용
    """
    u = user or _current_user()
    if not u:
        return False
    if is_course_owner_or_admin(course, u):
        return True

    # Enrollment 기반의 강사/조교 인정
    from models import Enrollment  # 지연 import
    if hasattr(Enrollment, "role"):
        row = (
            db.session.query(Enrollment.id)
            .filter(
                Enrollment.course_id == course.id,
                Enrollment.user_id == u.id,
                Enrollment.role.in_(_INSTRUCTOR_ENROLLMENT_ROLES),
            )
            .first()
        )
        if row:
            return True
    return False

def ensure_course_owner_or_403(course_id: int) -> "Course":
    """관리자/소유자(담당자)만 통과."""
    from models import Course
    course = db.session.get(Course, course_id)
    if not course:
        abort(404)
    if not is_course_owner_or_admin(course, _current_user()):
        abort(403)
    return course

def ensure_staff_or_403(course_id: int) -> "Course":
    """
    관리자/소유자/강사(Enrollment.role 포함)만 통과.
    - 자료/공지/토론 관리 등에서 사용하기 좋음.
    """
    from models import Course
    course = db.session.get(Course, course_id)
    if not course:
        abort(404)
    if not is_course_staff_or_admin(course, _current_user()):
        abort(403)
    return course

def ensure_enrolled_or_403(course_id: int, user_id: Optional[int] = None) -> None:
    """
    수강생이거나(Enrollment) 혹은 관리자/교수진이면 통과.
    - “보기/재생/다운로드” 같은 학생/교수 공용 액션에 사용.
    """
    from models import Enrollment, Course
    user = _current_user()
    uid = user_id or getattr(user, "id", None)
    if not uid:
        abort(403)

    # 관리자/교수진은 바로 통과
    course = db.session.get(Course, course_id)
    if course and is_course_staff_or_admin(course, user):
        return

    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=course_id).first()
    if not ok:
        abort(403)
