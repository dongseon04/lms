# helpers/storage.py
from __future__ import annotations
from pathlib import Path
from flask import current_app

def get_upload_root() -> Path:
    cfg = current_app.config.get("UPLOAD_ROOT")
    if cfg:
        p = Path(cfg)
        root = p if p.is_absolute() else (Path(current_app.root_path) / p)
    else:
        root = Path(current_app.root_path) / "static" / "uploads"
    root = root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root

def save_under_uploads(relpath: str, file_storage) -> str:
    """
    relpath: 'materials/abc.mp4' 처럼 항상 상대경로.
    file_storage: Flask의 FileStorage
    반환: 저장한 상대경로 (DB에는 이 값을 저장)
    """
    relpath = relpath.lstrip("/\\")
    base = get_upload_root()
    target = (base / relpath).resolve()
    # base 밖으로 못 나가게 보호
    target.relative_to(base)
    target.parent.mkdir(parents=True, exist_ok=True)
    file_storage.save(str(target))
    return relpath